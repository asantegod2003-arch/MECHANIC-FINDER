---
name: Mobile navigation
description: The user's explicit preference for phone-sized layouts and immediately visible menus.
---

The user wants “everything to fit on a mobile phone screen like in normal app” and “the menus should be displayed upon first arrival.”

**Why:** The user explicitly requested this behavior rather than menus hidden behind a mobile menu button.

**How to apply:** Preserve immediately visible main navigation and the appropriate account actions for visitors, customers, and mechanics when changing the app. Keep content within phone width, with normal vertical scrolling and readable controls rather than scaling down desktop layouts.
