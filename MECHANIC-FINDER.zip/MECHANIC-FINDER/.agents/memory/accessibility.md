---
name: Voice-based accessibility
description: Why this app needs voice communication rather than text-only chat.
---

Some of the app’s users cannot read and write. The user requested a recording button so those users can communicate with customers or mechanics.

**Why:** Text-only exchanges exclude part of the intended audience; this is a product requirement, not just a visual preference.

**How to apply:** Preserve voice recording and playback for both roles. Use recognizable microphone, stop and play controls with accessible names, not text instructions alone.
