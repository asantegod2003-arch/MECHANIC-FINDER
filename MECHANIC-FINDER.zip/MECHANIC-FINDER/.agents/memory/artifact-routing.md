---
name: Managed artifact routing
description: Legacy port mappings may reappear during multi-artifact setup.
---

Artifact/bootstrap or configuration activity can reintroduce old `[[ports]]`
blocks into root `.replit`, even after a validated replacement removed them.
Do not assume a previous cleanup remains in place or that these blocks identify
the active service. The exact reconciliation trigger has not been established.

**Why:** This was observed repeatedly while adding managed artifacts; the
website's real port and API routing came from artifact manifests, not the old
root port numbers.

**How to apply:** Use the existing managed artifact workflows and validate actual
shared-proxy routes after setup. Do not start duplicate legacy workflows or
hardcode old ports to match the reappearing blocks. If a routing change is
needed, use validated configuration replacement and check the proxy afterward.
