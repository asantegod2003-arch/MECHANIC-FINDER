---
name: Request-specific GPS snapshots
description: The customer wants map pins tied to request and acceptance events, not later profile GPS.
---

Show the customer GPS captured at request submission and mechanic GPS captured at acceptance for that specific repair request. Keep those positions fixed; do not replace them with later presence/profile locations.

**Why:** The user reported incorrect map positions and explicitly asked for “exactly where their locations were captured on request and acceptance.”

**How to apply:** Keep nearby-search presence separate from these saved positions. If adding live travel tracking, display it separately rather than silently moving the request/acceptance pins. Device-reported GPS accuracy is not a guarantee of exact physical location, and missing historical captures cannot be reconstructed.
