---
name: Email credential route
description: Why recovery email uses an explicitly supplied project Secret rather than the saved Resend connector.
---

Use the explicitly supplied project Secret for Resend recovery email, not an automatic fallback to the saved connector.

**Why:** The saved connector rejected authentication, did not support an inline reconnect, and the user could not find its key-entry setting. The user then supplied a new key through the secure Secrets form for direct app use. Preserve this intentional credential choice until the user requests a change.

**How to apply:** Use normal application-side authentication with the private Secret; never inspect or log its value. Sending-only keys are sufficient for recovery mail. A restricted_api_key error from a domain-list request does not mean such a key is malformed or unable to send; ask the user for the sender setup instead of demanding broader permissions.

For future connector work, the guide's Python package replit-connectors was unavailable in this project's registry, whereas the official Node connector SDK installed successfully. Confirm package availability before adopting the Python example.
