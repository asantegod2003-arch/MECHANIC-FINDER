---
name: Production migration ownership
description: Why Django migrations must not run at startup against this app's Replit-managed production database.
---

Let Replit Publish own production schema changes. Run Django migrations against development only, not in the production startup or build command.

**Why:** Publishing applied the new tables and columns to production without updating Django's migration history. Running `manage.py migrate` at startup then attempted to create tables that already existed, causing a crash loop before Gunicorn could start. Read-only inspection confirmed the schema changes existed while migration history remained behind.

**How to apply:** Keep development schema current using Django migrations, then publish through Replit's schema-diff flow. Do not mistake stale production migration history for a missing schema, add startup DDL, or broadly fake migrations. Check the database skill before changing production migration behavior.
