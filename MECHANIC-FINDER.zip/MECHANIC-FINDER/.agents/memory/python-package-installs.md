---
name: Python package installs
description: A Replit Python package install/uninstall can leave duplicate pins in requirements.txt.
---

After using the Replit Python package installer, inspect `requirements.txt` for duplicate entries, including after uninstalling a temporary generation-only package.

**Why:** The install/uninstall helper appended requested package pins alongside existing pins in this workspace, leaving duplicates despite successful dependency resolution.

**How to apply:** Keep the project requirements file deduplicated after package-management operations; do not assume the helper preserves the file's original entries exactly.
