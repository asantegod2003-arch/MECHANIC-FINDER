---
name: Nearby mechanics before requests
description: The customer's desired timing for discovering nearby mechanics.
---

Customers should be able to see nearby mechanics on arrival after signing in or signing up, before submitting a repair request.

**Why:** The user explicitly asked for nearest mechanics to appear before a customer sends a request, mentioning a roughly 1 km distance or another appropriate range.

**How to apply:** Do not make proximity discovery depend on an existing repair request. If a customer cannot provide a current location or no nearby mechanic is available, preserve a useful area-based browsing path rather than inventing positions.
