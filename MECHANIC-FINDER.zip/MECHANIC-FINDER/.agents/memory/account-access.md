---
name: Account access expectations
description: Re-login after ten minutes outside the app, with an idle fallback and support for existing account entry methods.
---

Require login again after ten continuous minutes outside the app in another app or tab. Shorter switches and ordinary navigation between pages inside the app should not sign users out. Keep the 3-hour server idle timeout as an additional fallback; background polling and GPS updates are not activity.

**Why:** The user refined their earlier immediate-switch logout requirement: “when the user switch tab outside for like 10mins . he has to login again.”

**How to apply:** Count continuous time away, resetting after a return under ten minutes, and check elapsed time on return even when background timers were suspended. Once expired, keep private content locked until sign-out is confirmed, including offline cases. Stop microphone/live sharing on departure. Browser lifecycle reporting is best-effort, so retain the server idle safeguard.

Allow email-and-password signup without requiring a chosen username, while retaining username-based access for existing accounts.

**Why:** The user asked to allow users to sign up with email too, not to replace existing accounts or switch authentication providers.

**How to apply:** Keep both account entry methods working. Email verification or social sign-in is separate work, not implied by email signup.

Treat missing app profiles as recoverable account setup, not incorrect credentials. Infer the role only from unambiguous existing job/chat/verification history; otherwise ask the authenticated owner to choose. Recovered mechanics start offline.

**Why:** Credentials and job/chat history can survive while a role profile is missing. Guessing a role can send the owner to the wrong dashboard, while automatically announcing a restored mechanic as available can mislead customers.

**How to apply:** Preserve the user account, password, and history. Do not overwrite valid roles or grant verification/admin privileges during recovery. Keep resource-specific privacy checks intact rather than replacing their 403/404 responses with setup redirects.

Keep existing conversations accessible to their original participants even when a profile is missing or an account's current role differs from its historical role. Enforce customer/mechanic pairing when starting a new conversation, not when reopening existing history.

**Why:** The user reported that old messages were blocked by the customer/mechanic role error after the profile failure. A missing counterpart profile must not require that person to log in before the other participant can read their messages.

**How to apply:** Apply participant-based authorization consistently to inboxes, dashboards, text/voice history, replies, and polling. Preserve both histories if a pair has reverse-oriented legacy conversations; do not expose them to third parties or rewrite account roles merely to open a chat.
