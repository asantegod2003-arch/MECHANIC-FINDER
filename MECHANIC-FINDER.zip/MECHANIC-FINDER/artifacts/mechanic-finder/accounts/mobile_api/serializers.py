from django.db.models import Avg
from django.utils import timezone

from rescue.models import RepairReview
from rescue.views import _coordinates
from ..profile_access import resolve_app_profile


def person(user):
    return {"id": user.pk, "name": user.get_full_name() or user.username, "username": user.username}


def account(user):
    profile = resolve_app_profile(user)
    return {
        **person(user), "email": user.email,
        "role": profile.role if profile else None, "needs_setup": profile is None,
        "available": profile.available if profile else False,
        "service_area": profile.service_area if profile else "",
        "repair_specialties": profile.repair_specialties if profile else "",
        "verified": profile.is_verified if profile else False,
        "latitude": profile.latitude if profile else None,
        "longitude": profile.longitude if profile else None,
    }


def point(latitude, longitude, captured_at=None, accuracy=None):
    if _coordinates(latitude, longitude) is None:
        return None
    return {
        "latitude": latitude, "longitude": longitude,
        "captured_at": captured_at.isoformat() if captured_at else None,
        "accuracy": accuracy,
    }


def review(item):
    return {
        "rating": item.rating, "comment": item.comment,
        "customer_name": item.job.customer.get_full_name() or item.job.customer.username,
        "created_at": item.created_at.isoformat(),
    }


def mechanic(user):
    reviews = RepairReview.objects.filter(job__mechanic=user, job__status="completed")
    return {
        **person(user), "available": user.profile.available,
        "service_area": user.profile.service_area,
        "repair_specialties": user.profile.repair_specialties,
        "verified": user.profile.is_verified,
        "average_rating": reviews.aggregate(value=Avg("rating"))["value"],
        "review_count": reviews.count(),
    }


def job(item):
    latest_review = RepairReview.objects.filter(job=item).select_related("job__customer").first()
    # Match the website's 60-second live-location lease. A device can disappear
    # without delivering its stop request; the stored consent flag alone must
    # never expose a stale precise point or report sharing as still active.
    live_position = None
    if item.live_tracking_enabled and item.status == "on_the_way" and item.live_location_updated_at:
        age = (timezone.now() - item.live_location_updated_at).total_seconds()
        if 0 <= age <= 60:
            live_position = point(
                item.live_latitude, item.live_longitude,
                item.live_location_updated_at, item.live_accuracy,
            )
    return {
        "id": item.pk, "customer": person(item.customer),
        "mechanic": person(item.mechanic) if item.mechanic_id else None,
        "vehicle_problem": item.vehicle_problem, "location": item.location,
        "phone_number": item.phone_number, "status": item.status,
        "created_at": item.created_at.isoformat(),
        "customer_position": point(
            item.customer_latitude, item.customer_longitude,
            item.customer_location_captured_at, item.customer_location_accuracy,
        ),
        "mechanic_position": point(
            item.mechanic_latitude, item.mechanic_longitude,
            item.mechanic_location_captured_at, item.mechanic_location_accuracy,
        ) if item.mechanic_id else None,
        "live_position": live_position,
        "live_tracking_enabled": live_position is not None,
        "estimates": [{
            "id": quote.pk, "description": quote.description, "amount": str(quote.amount),
            "currency": quote.currency, "status": quote.status,
            "created_at": quote.created_at.isoformat(),
        } for quote in item.estimates.all()],
        "review": review(latest_review) if latest_review else None,
    }


def message(item):
    return {
        "id": item.pk, "sender_id": item.sender_id,
        "sender_name": item.sender.get_full_name() or item.sender.username,
        "body": item.body, "created_at": item.created_at.isoformat(),
        "audio_url": f"/api/mobile/voice/{item.pk}/" if item.audio_object_key else None,
        "audio_duration": item.audio_duration if item.audio_object_key else None,
    }


def verification(item):
    fields = ("business_name", "contact_number", "service_area", "experience", "credential_reference")
    return {
        **{field: getattr(item, field, "") for field in fields},
        "status": item.status if item else "not_submitted",
        "public_feedback": item.public_feedback if item else "",
    }
