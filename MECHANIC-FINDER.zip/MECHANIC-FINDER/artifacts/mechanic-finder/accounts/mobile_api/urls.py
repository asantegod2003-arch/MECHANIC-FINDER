from django.urls import path
from . import chat, requests as repairs, views

app_name = "mobile_api"

urlpatterns = [
    path("login/", views.login, name="login"),
    path("signup/", views.signup, name="signup"),
    path("me/", views.me, name="me"),
    path("setup/", views.setup, name="setup"),
    path("logout/", views.logout, name="logout"),
    path("activity/", views.activity, name="activity"),
    path("mechanics/", views.directory, name="directory"),
    path("mechanics/nearby/", views.nearby_mechanics, name="nearby_mechanics"),
    path("mechanics/<int:mechanic_id>/", views.mechanic_detail, name="mechanic"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("profile/", views.profile, name="profile"),
    path("requests/", repairs.create_request, name="create_request"),
    path("requests/<int:request_id>/", repairs.request_detail, name="request"),
    path("requests/<int:request_id>/action/", repairs.job_action, name="job_action"),
    path("requests/<int:request_id>/journey/", repairs.journey, name="journey"),
    path("requests/<int:request_id>/estimates/", repairs.create_estimate, name="estimate"),
    path("estimates/<int:estimate_id>/decision/", repairs.decide_estimate, name="decision"),
    path("requests/<int:request_id>/review/", repairs.save_review, name="review"),
    path("conversations/", chat.conversations, name="conversations"),
    path("chat/<int:other_id>/", chat.chat, name="chat"),
    path("voice/<int:message_id>/", chat.voice, name="voice"),
    path("notifications/", views.notifications, name="notifications"),
    path("verification/", views.verification, name="verification"),
    path("deletion-request/", views.deletion_request, name="deletion_request"),
]
