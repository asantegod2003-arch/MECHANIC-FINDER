"""Revocable opaque native sessions using Django's existing session storage.

Native sessions deliberately contain no Django cookie-authentication keys. A
website cookie cannot authenticate this API, and a mobile token cannot become
a signed-in website cookie. Password changes and disabled users revoke access.
"""
from functools import wraps
import json
import re
import time

from django.conf import settings
from django.contrib.auth.models import User
from django.contrib.sessions.backends.db import SessionStore
from django.core.exceptions import ValidationError
from django.http import Http404, JsonResponse
from django.utils.crypto import constant_time_compare
from django.views.decorators.csrf import csrf_exempt

IDLE_SECONDS = 3 * 60 * 60
AWAY_SECONDS = 10 * 60


class ApiFailure(Exception):
    def __init__(self, message, status=400, errors=None):
        self.message, self.status, self.errors = message, status, errors


def result(data, status=200):
    return JsonResponse(data, safe=not isinstance(data, list), status=status)


def fail_form(form):
    raise ApiFailure("Please check the highlighted details.", errors={
        key: [str(message) for message in messages]
        for key, messages in form.errors.items()
    })


def issue_session(user):
    session = SessionStore()
    session.update({
        "mobile_user_id": user.pk,
        "mobile_auth_hash": user.get_session_auth_hash(),
        "mobile_last_active": time.time(),
    })
    session.set_expiry(IDLE_SECONDS)
    session.create()
    return session.session_key


def authenticate_token(request):
    authorization = request.headers.get("Authorization", "")
    if not re.fullmatch(r"Bearer [a-z0-9]{32}", authorization):
        raise ApiFailure("Please log in to continue.", 401)
    session = SessionStore(session_key=authorization[7:])
    user_id = session.get("mobile_user_id")
    # A syntactically valid token might be a website session key. Reject it
    # without deleting that unrelated session or changing its cookie login.
    if not user_id:
        raise ApiFailure("Please log in to continue.", 401)
    user = User.objects.filter(pk=user_id, is_active=True).first() if user_id else None
    now = time.time()
    last_active = session.get("mobile_last_active", 0)
    away_at = session.get("mobile_away_at")
    if (
        not user
        or not constant_time_compare(
            session.get("mobile_auth_hash", ""), user.get_session_auth_hash()
        )
        or now - last_active >= IDLE_SECONDS
        or (away_at is not None and now - away_at >= AWAY_SECONDS)
    ):
        session.delete()
        raise ApiFailure("Your session expired. Please log in again.", 401)
    request.user = user
    request.mobile_session = session


def touch(request):
    session = request.mobile_session
    session["mobile_last_active"] = time.time()
    session.set_expiry(IDLE_SECONDS)
    session.save()


def payload(request):
    if request.method not in ("POST", "PATCH"):
        return {}
    if request.content_type == "multipart/form-data":
        return request.POST
    # Generated bodyless operations (notably logout) correctly send no JSON
    # header or payload. They are still bearer-authenticated before this point.
    if not request.body:
        return {}
    if request.content_type != "application/json":
        raise ApiFailure("Send this request as JSON.", 415)
    if len(request.body) > 32 * 1024:
        raise ApiFailure("This request is too large.", 413)
    try:
        data = json.loads(request.body, parse_constant=lambda _: None)
    except (ValueError, UnicodeDecodeError):
        raise ApiFailure("This request could not be read. Please try again.")
    if not isinstance(data, dict) or any(
        isinstance(value, (dict, list)) for value in data.values()
    ):
        raise ApiFailure("Send a valid set of form details.")
    return data


def api(*methods, public=False):
    """CSRF exemption applies only to these bearer-only native endpoints.

    Original website forms retain Django CSRF protection. GET polling does not
    extend a session. Foreground GPS streaming also must not count as activity.
    """
    def decorate(view):
        @csrf_exempt
        @wraps(view)
        def wrapped(request, *args, **kwargs):
            try:
                if request.method not in methods:
                    raise ApiFailure("This action is not supported.", 405)
                if not public:
                    authenticate_token(request)
                request.mobile_data = payload(request)
                response = view(request, *args, **kwargs)
                if (
                    not public and response.status_code < 300
                    and request.method in ("POST", "PATCH")
                    and view.__name__ not in ("logout", "activity", "journey", "profile", "nearby_mechanics")
                ):
                    touch(request)
                return response
            except ApiFailure as error:
                data = {"message": error.message}
                if error.errors:
                    data["errors"] = error.errors
                response = result(data, error.status)
                if error.status == 401:
                    response["WWW-Authenticate"] = "Bearer"
                return response
            except Http404:
                return result({"message": "This item is unavailable or does not belong to your account."}, 404)
            except ValidationError as error:
                return result({"message": " ".join(error.messages)}, 400)
        return wrapped
    return decorate


class MobileApiMiddleware:
    """Narrow, non-credentialed CORS for the Expo web preview and API errors."""
    prefix = "/api/mobile/"

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not request.path.startswith(self.prefix):
            return self.get_response(request)
        import os
        from django.utils.cache import patch_vary_headers
        origin = request.headers.get("Origin")
        allowed = set(getattr(settings, "MOBILE_WEB_ORIGINS", []))
        allowed.add(request.build_absolute_uri("/").rstrip("/"))
        if settings.DEBUG:
            expo_domain = os.environ.get("REPLIT_EXPO_DEV_DOMAIN", "").strip()
            if expo_domain:
                allowed.add("https://" + expo_domain.removeprefix("https://").rstrip("/"))
        if origin and origin not in allowed:
            response = result({"message": "This browser origin is not allowed."}, 403)
        elif request.method == "OPTIONS":
            response = result({}, 200)
            response["Access-Control-Allow-Methods"] = "GET, POST, PATCH, OPTIONS"
            response["Access-Control-Allow-Headers"] = "Authorization, Content-Type, Range"
            response["Access-Control-Max-Age"] = "600"
        else:
            response = self.get_response(request)
        if origin in allowed:
            response["Access-Control-Allow-Origin"] = origin
        response["Access-Control-Expose-Headers"] = "Content-Range, Accept-Ranges"
        response["Cache-Control"] = "private, no-store"
        response["X-Content-Type-Options"] = "nosniff"
        patch_vary_headers(response, ["Origin", "Authorization"])
        return response
