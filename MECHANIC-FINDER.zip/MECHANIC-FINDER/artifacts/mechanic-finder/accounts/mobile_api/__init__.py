"""Native API adapters for the existing Django product, not a second backend."""
