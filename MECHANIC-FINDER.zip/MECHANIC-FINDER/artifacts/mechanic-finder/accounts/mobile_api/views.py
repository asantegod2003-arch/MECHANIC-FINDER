"""JSON adapters around existing accounts, profiles, notifications and forms."""
import time
from datetime import timedelta

from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.db import IntegrityError, transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404
from django.utils import timezone

from rescue.models import RepairReview, RescueRequest
from rescue.views import _coordinates
from ..forms import AccountRoleForm, PublicMechanicProfileForm, SignUpForm
from ..models import MechanicVerification, Notification, Profile
from ..notifications import NEARBY_REQUEST_RADIUS_KM, _distance_km, create_notification
from ..profile_access import resolve_app_profile
from ..recovery import _allow
from ..trust_forms import VerificationForm
from . import serializers as s
from .auth import ApiFailure, api, fail_form, issue_session, result, touch


def require_role(user, role):
    profile = resolve_app_profile(user)
    if profile is None:
        raise ApiFailure("Choose your account type in Account to continue.", 403)
    if profile.role != role:
        raise ApiFailure(f"This action is only available to a {role}.", 403)
    return profile


@api("POST", public=True)
def login(request):
    data = request.mobile_data
    identifier, password = data.get("username"), data.get("password")
    if not isinstance(identifier, str) or not isinstance(password, str):
        raise ApiFailure("Enter your username or email address and password.")
    identifier = identifier.strip()[:254]
    if not (
        _allow("mobile-login-ip", request.META.get("REMOTE_ADDR", "unknown"), 200)
        and _allow("mobile-login-identity", identifier, 30)
    ):
        raise ApiFailure("Too many login attempts. Please try again later.", 429)
    matches = list(User.objects.filter(
        Q(username__iexact=identifier) | Q(email__iexact=identifier)
    ).order_by("pk")[:2]) if identifier else []
    user = authenticate(request, username=matches[0].username, password=password) if len(matches) == 1 else None
    if len(matches) != 1:
        User().set_password(password)
    if not user:
        raise ApiFailure("Incorrect username, email address or password. Please check your details.", 400)
    return result({"token": issue_session(user), "user": s.account(user)})


@api("POST", public=True)
def signup(request):
    data = request.mobile_data
    # Commit the rate counter even when validation or creation later rolls back.
    if not _allow("mobile-signup-ip", request.META.get("REMOTE_ADDR", "unknown"), 100):
        raise ApiFailure("Too many account creation attempts. Please try again later.", 429)
    with transaction.atomic():
        # Hold per-identifier locks until creation commits, serializing native
        # email-only signups without changing existing legacy account records.
        for identifier in sorted({str(data.get("username", "")).strip(), str(data.get("email", "")).strip()} - {""}):
            if not _allow("mobile-signup-identity", identifier, 10):
                raise ApiFailure("Too many account creation attempts. Please try again later.", 429)
        form = SignUpForm(data)
        if not form.is_valid():
            fail_form(form)
        try:
            with transaction.atomic():
                user = form.save(commit=False)
                user.set_password(form.cleaned_data["password"])
                user.save()
                Profile.objects.create(user=user, role=form.cleaned_data["role"])
                create_notification(
                    user, "Welcome to Mechanic Finder",
                    "Your account is ready. You can now find help or accept nearby jobs.", "/",
                )
        except IntegrityError:
            raise ApiFailure("This account could not be created. Check whether the username or email is already in use.", 409)
        session = {"token": issue_session(user), "user": s.account(user)}
    return result(session, 201)


@api("GET")
def me(request):
    return result(s.account(request.user))


@api("POST")
@transaction.atomic
def setup(request):
    User.objects.select_for_update().get(pk=request.user.pk)
    existing = resolve_app_profile(request.user)
    if existing:
        if request.mobile_data.get("role") != existing.role:
            raise ApiFailure("Your account already has a role. Existing profiles cannot be overwritten here.", 409)
        return result(s.account(request.user))
    # Invalid-but-present profiles must be reviewed, not silently overwritten.
    if Profile.objects.filter(user=request.user).exists():
        raise ApiFailure("An administrator must review this account profile.", 409)
    form = AccountRoleForm(request.mobile_data)
    if not form.is_valid():
        fail_form(form)
    request.user.profile = Profile.objects.create(
        user=request.user, role=form.cleaned_data["role"], available=False,
    )
    return result(s.account(request.user))


@api("POST")
def logout(request):
    request.mobile_session.delete()
    return result({"message": "You have been logged out."})


@api("POST")
def activity(request):
    state = request.mobile_data.get("state")
    if state == "away":
        # Duplicate background callbacks must not move the original departure.
        if request.mobile_session.get("mobile_away_at") is None:
            request.mobile_session["mobile_away_at"] = time.time()
            request.mobile_session.save()
    elif state == "active":
        request.mobile_session.pop("mobile_away_at", None)
        touch(request)
    else:
        raise ApiFailure("Choose active or away.")
    return result({"message": "Session state updated."})


@api("GET", public=True)
def directory(request):
    mechanics = User.objects.filter(is_active=True, profile__role="mechanic").select_related(
        "profile", "verification_application"
    ).order_by("first_name", "username")
    query = request.GET.get("q", "").strip()[:200]
    if query:
        mechanics = mechanics.filter(
            Q(first_name__icontains=query) | Q(last_name__icontains=query)
            | Q(username__icontains=query) | Q(profile__service_area__icontains=query)
            | Q(profile__repair_specialties__icontains=query)
        )
    for param, field in (("area", "service_area"), ("specialty", "repair_specialties")):
        value = request.GET.get(param, "").strip()[:200]
        if value:
            mechanics = mechanics.filter(**{f"profile__{field}__icontains": value})
    return result([s.mechanic(user) for user in mechanics])


@api("POST")
def nearby_mechanics(request):
    require_role(request.user, "customer")
    data = request.mobile_data
    if any(type(data.get(key)) not in (int, float) for key in ("latitude", "longitude")):
        raise ApiFailure("Share your current location to find nearby mechanics.")
    position = _coordinates(data["latitude"], data["longitude"])
    if not position:
        raise ApiFailure("Your device did not provide a valid location. Try again.")
    # Coordinates are sent in the request body, never in a logged URL, and are
    # not saved as a customer's request/acceptance pin by this lookup.
    if not _allow("mobile-nearby-customer", str(request.user.pk), 60):
        raise ApiFailure("Too many nearby searches. Please try again later.", 429)
    now = timezone.now()
    mechanics = User.objects.filter(
        is_active=True, profile__role="mechanic", profile__available=True,
        profile__latitude__isnull=False, profile__longitude__isnull=False,
        profile__location_updated_at__gte=now - timedelta(minutes=10),
        profile__location_updated_at__lte=now,
    ).select_related("profile", "verification_application")
    matches = []
    for mechanic in mechanics:
        mechanic_position = _coordinates(mechanic.profile.latitude, mechanic.profile.longitude)
        if not mechanic_position:
            continue
        distance = _distance_km(
            position["lat"], position["lng"], mechanic_position["lat"], mechanic_position["lng"],
        )
        if distance > NEARBY_REQUEST_RADIUS_KM:
            continue
        label = (
            "Within 1 km" if distance < 1 else
            "1–5 km away" if distance <= 5 else
            "5–10 km away" if distance <= 10 else "10–25 km away"
        )
        matches.append((distance, mechanic.pk, {"mechanic": s.mechanic(mechanic), "distance_label": label}))
    matches.sort(key=lambda item: (item[0], item[1]))
    return result([item[2] for item in matches])


@api("GET", public=True)
def mechanic_detail(request, mechanic_id):
    user = get_object_or_404(
        User.objects.select_related("profile", "verification_application"),
        pk=mechanic_id, is_active=True, profile__role="mechanic",
    )
    reviews = RepairReview.objects.filter(job__mechanic=user, job__status="completed").select_related("job__customer")
    application = getattr(user, "verification_application", None)
    return result({
        **s.mechanic(user), "reviews": [s.review(item) for item in reviews[:50]],
        "business_name": application.business_name if user.profile.is_verified and application else "",
    })


@api("GET")
def dashboard(request):
    profile = resolve_app_profile(request.user)
    if profile is None:
        raise ApiFailure("Choose your account type in Account to restore the dashboard.", 403)
    own = RescueRequest.objects.filter(
        Q(customer=request.user) | Q(mechanic=request.user)
    ).select_related("customer", "mechanic").order_by("-created_at")
    pending = RescueRequest.objects.filter(status="pending").exclude(
        customer=request.user,
    ).select_related("customer", "mechanic").order_by("-created_at") if profile.role == "mechanic" and profile.available else []
    return result({
        "user": s.account(request.user), "requests": [s.job(item) for item in own],
        "nearby": [s.job(item) for item in pending],
    })


@api("PATCH")
@transaction.atomic
def profile(request):
    profile = require_role(request.user, "mechanic")
    profile = Profile.objects.select_for_update().get(pk=profile.pk)
    data = request.mobile_data
    if "available" in data:
        if not isinstance(data["available"], bool):
            raise ApiFailure("Availability must be on or off.")
        profile.available = data["available"]
    if "service_area" in data or "repair_specialties" in data:
        form = PublicMechanicProfileForm({
            "service_area": data.get("service_area", profile.service_area),
            "repair_specialties": data.get("repair_specialties", profile.repair_specialties),
        }, instance=profile)
        if not form.is_valid():
            fail_form(form)
        profile = form.save(commit=False)
    if "latitude" in data or "longitude" in data:
        position = _coordinates(data.get("latitude"), data.get("longitude"))
        if not position:
            raise ApiFailure("Capture a valid GPS position again.")
        profile.latitude, profile.longitude = position["lat"], position["lng"]
        profile.location_updated_at = timezone.now()
    profile.save()
    request.user.profile = profile
    if set(data) - {"latitude", "longitude"}:
        touch(request)
    return result(s.account(request.user))


@api("GET", "POST")
def notifications(request):
    own = Notification.objects.filter(recipient=request.user)
    if request.method == "POST":
        if "id" in request.mobile_data:
            if type(request.mobile_data["id"]) is not int:
                raise ApiFailure("Choose a valid notification.")
            own = own.filter(pk=request.mobile_data["id"])
        own.filter(read_at__isnull=True).update(read_at=timezone.now())
        return result({"message": "Notifications marked read."})
    return result([{
        "id": item.pk, "title": item.title, "message": item.message, "url": item.url,
        "created_at": item.created_at.isoformat(), "is_read": item.is_read,
    } for item in own[:100]])


@api("GET", "POST")
@transaction.atomic
def verification(request):
    require_role(request.user, "mechanic")
    User.objects.select_for_update().get(pk=request.user.pk)
    application = MechanicVerification.objects.select_for_update().filter(user=request.user).first()
    if request.method == "POST":
        if application and application.status == "verified":
            raise ApiFailure("Your verification is already approved. Contact an administrator to change reviewed details.", 409)
        form = VerificationForm(request.mobile_data, instance=application)
        if not form.is_valid():
            fail_form(form)
        application = form.save(commit=False)
        application.user, application.status = request.user, "pending"
        application.identity_checked = application.contact_checked = application.qualifications_checked = False
        application.reviewed_by = application.reviewed_at = None
        application.save()
    return result(s.verification(application))


@api("POST")
@transaction.atomic
def deletion_request(request):
    data = request.mobile_data
    if data.get("confirm") is not True or not isinstance(data.get("password"), str):
        raise ApiFailure("Confirm that you want to request account deletion and enter your password.")
    if not request.user.check_password(data["password"]):
        raise ApiFailure("The password is incorrect. No deletion request was made.")
    title = "Account deletion requested"
    own = Notification.objects.filter(recipient=request.user, title=title, url="/notifications/").first()
    if not own:
        administrators = list(User.objects.filter(is_active=True, is_staff=True))
        if not administrators:
            raise ApiFailure("Account deletion support is temporarily unavailable. No request was recorded.", 503)
        own = create_notification(
            request.user, title,
            "Your deletion request is recorded. An administrator must process it; your account and data have not yet been deleted.",
            "/notifications/",
        )
        for administrator in administrators:
            create_notification(
                administrator, title,
                f"Account {request.user.pk} requested deletion. Review the account and retained repair/chat records before processing. Request reference: {own.pk}.",
                f"/admin/auth/user/{request.user.pk}/change/",
            )
    return result({
        "message": f"Deletion request #{own.pk} has been recorded for an administrator. Your account remains active until it is processed; no data has been erased yet.",
    })
