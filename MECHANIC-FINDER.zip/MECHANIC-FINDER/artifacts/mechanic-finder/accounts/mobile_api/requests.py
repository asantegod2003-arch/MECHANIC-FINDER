"""Native rescue/repair operations with the website's ownership and state rules."""
import math

from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404
from django.utils import timezone

from rescue.forms import RescueRequestForm
from rescue.models import RepairEstimate, RepairReview, RescueRequest
from rescue.repair_forms import EstimateForm, ReviewForm
from rescue.views import _coordinates
from ..notifications import create_notification, notify_nearby_mechanics
from ..profile_access import resolve_app_profile
from . import serializers as s
from .auth import ApiFailure, api, fail_form, result
from .views import require_role


def notify(user, title, body, job):
    create_notification(user, title, body, f"/rescue/tracking/{job.pk}/")


def position(data, require_accuracy=False):
    point = _coordinates(data.get("latitude"), data.get("longitude"))
    accuracy = data.get("accuracy")
    try:
        accuracy = float(accuracy) if accuracy not in (None, "") else None
        if accuracy is not None and (not math.isfinite(accuracy) or accuracy < 0):
            raise ValueError
    except (TypeError, ValueError):
        point = None
    if not point or (require_accuracy and accuracy is None):
        raise ApiFailure("Capture a valid precise GPS position and try again. No location was guessed.")
    return point, accuracy


@api("POST")
@transaction.atomic
def create_request(request):
    require_role(request.user, "customer")
    form = RescueRequestForm(request.mobile_data)
    if not form.is_valid():
        fail_form(form)
    job = form.save(commit=False)
    job.customer, job.customer_location_captured_at = request.user, timezone.now()
    job.save()
    notify_nearby_mechanics(job)
    return result(s.job(job), 201)


@api("GET")
def request_detail(request, request_id):
    permissions = Q(customer=request.user) | Q(mechanic=request.user)
    profile = resolve_app_profile(request.user)
    if profile and profile.role == "mechanic" and profile.available:
        permissions |= Q(status="pending")
    job = get_object_or_404(
        RescueRequest.objects.select_related("customer", "mechanic").filter(permissions), pk=request_id,
    )
    return result(s.job(job))


@api("POST")
@transaction.atomic
def job_action(request, request_id):
    data, user = request.mobile_data, request.user
    action = data.get("action")
    # Do not join the nullable mechanic FK under FOR UPDATE (PostgreSQL cannot
    # lock the nullable side of an outer join). Lock the job row itself.
    job = get_object_or_404(RescueRequest.objects.select_for_update(), pk=request_id)
    if action == "accept":
        profile = require_role(user, "mechanic")
        if not profile.available:
            raise ApiFailure("Go online before accepting jobs.", 409)
        if job.status != "pending" or job.mechanic_id is not None:
            raise ApiFailure("This request is no longer available. Refresh the request list.", 409)
        if job.customer_id == user.pk:
            raise ApiFailure("You cannot accept your own rescue request.", 403)
        point, accuracy = position(data)
        job.mechanic, job.status = user, "accepted"
        job.mechanic_latitude, job.mechanic_longitude = point["lat"], point["lng"]
        job.mechanic_location_accuracy, job.mechanic_location_captured_at = accuracy, timezone.now()
        notify(job.customer, "Your rescue request was accepted", f"{user.get_full_name() or user.username} accepted your request.", job)
    elif action == "cancel":
        if job.customer_id != user.pk:
            raise ApiFailure("Only this request's customer can cancel it.", 403)
        if job.status != "pending":
            raise ApiFailure("Only a pending request can be cancelled.", 409)
        job.status, job.live_tracking_enabled = "cancelled", False
    elif action in ("start", "arrive", "complete"):
        require_role(user, "mechanic")
        if job.mechanic_id != user.pk:
            raise ApiFailure("This repair is not assigned to your account.", 403)
        expected, target = {
            "start": ("accepted", "on_the_way"),
            "arrive": ("on_the_way", "arrived"),
            "complete": ("arrived", "completed"),
        }[action]
        if job.status != expected:
            raise ApiFailure("The repair status has changed. Refresh before trying again.", 409)
        if action == "complete":
            latest = job.estimates.first()
            if not latest or latest.status != "accepted":
                raise ApiFailure("The customer must approve the latest repair estimate before completion.", 409)
        job.status = target
        if action != "start":
            job.live_tracking_enabled = False
        if action in ("start", "complete"):
            notify(
                job.customer, "Your mechanic is on the way" if action == "start" else "Repair completed",
                "Open the repair for journey updates." if action == "start" else "You can now leave a review for this completed repair.",
                job,
            )
    else:
        raise ApiFailure("Choose a valid repair action.")
    job.save()
    return result(s.job(job))


@api("POST")
@transaction.atomic
def journey(request, request_id):
    job = get_object_or_404(RescueRequest.objects.select_for_update(), pk=request_id, mechanic=request.user)
    data = request.mobile_data
    if data.get("enabled") is False:
        job.live_tracking_enabled = False
        job.save(update_fields=["live_tracking_enabled"])
    elif data.get("enabled") is True:
        if job.status != "on_the_way":
            raise ApiFailure("Location sharing is available only while you are on the way.", 409)
        point, accuracy = position(data, require_accuracy=True)
        job.live_latitude, job.live_longitude = point["lat"], point["lng"]
        job.live_accuracy, job.live_location_updated_at = accuracy, timezone.now()
        job.live_tracking_enabled = True
        job.save(update_fields=[
            "live_latitude", "live_longitude", "live_accuracy", "live_location_updated_at", "live_tracking_enabled",
        ])
    else:
        raise ApiFailure("Choose whether to enable location sharing.")
    return result(s.job(job))


@api("POST")
@transaction.atomic
def create_estimate(request, request_id):
    job = get_object_or_404(RescueRequest.objects.select_for_update(), pk=request_id, mechanic=request.user)
    if job.status not in ("accepted", "on_the_way", "arrived"):
        raise ApiFailure("Estimates can only be sent for an active accepted repair.", 409)
    form = EstimateForm(request.mobile_data)
    if not form.is_valid():
        fail_form(form)
    job.estimates.filter(status="proposed").update(status="superseded")
    quote = form.save(commit=False)
    quote.job = job
    quote.save()
    notify(job.customer, "Repair estimate ready", f"Your mechanic proposed GHS {quote.amount}. Open the repair to approve or decline.", job)
    return result(s.job(job))


@api("POST")
@transaction.atomic
def decide_estimate(request, estimate_id):
    quote = get_object_or_404(RepairEstimate.objects.select_related("job"), pk=estimate_id, job__customer=request.user)
    job = RescueRequest.objects.select_for_update().get(pk=quote.job_id)
    quote.refresh_from_db()
    decision = request.mobile_data.get("decision")
    if (
        decision not in ("accept", "decline") or quote.status != "proposed"
        or job.estimates.first().pk != quote.pk or job.status in ("completed", "cancelled")
    ):
        raise ApiFailure("This estimate can no longer be changed. Review the latest proposal.", 409)
    quote.status = "accepted" if decision == "accept" else "declined"
    quote.decided_at = timezone.now()
    quote.save(update_fields=["status", "decided_at"])
    notify(job.mechanic, "Customer responded to your estimate", f"The customer {quote.status} GHS {quote.amount}.", job)
    return result(s.job(job))


@api("POST")
@transaction.atomic
def save_review(request, request_id):
    job = get_object_or_404(RescueRequest.objects.select_for_update(), pk=request_id, customer=request.user)
    if job.status != "completed" or not job.mechanic_id:
        raise ApiFailure("Only completed repairs can be reviewed.", 409)
    existing = RepairReview.objects.filter(job=job).first()
    form = ReviewForm(request.mobile_data, instance=existing)
    if not form.is_valid():
        fail_form(form)
    review = form.save(commit=False)
    review.job = job
    review.save()
    return result(s.job(job))
