"""Native contract/security tests use Django's disposable test database."""
import time
from datetime import timedelta
from unittest.mock import patch

from django.contrib.auth.models import User
from django.contrib.sessions.backends.db import SessionStore
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import IntegrityError
from django.test import Client, TestCase, override_settings
from django.utils import timezone

from rescue.models import RescueRequest
from accounts.models import ChatMessage, ChatThread, MechanicVerification, Notification, Profile, RecoveryRateLimit
from .auth import issue_session

ROOT = "/api/mobile/"
PASSWORD = "Strong-Example-Password-628!"


@override_settings(PASSWORD_HASHERS=["django.contrib.auth.hashers.MD5PasswordHasher"])
class NativeApiTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.customer = User.objects.create_user(
            "native-customer", email="driver@example.test", password=PASSWORD, first_name="Driver",
        )
        cls.mechanic = User.objects.create_user("native-mechanic", password=PASSWORD, first_name="Mechanic")
        cls.outsider = User.objects.create_user("outsider", password=PASSWORD)
        Profile.objects.create(user=cls.customer, role="customer")
        Profile.objects.create(user=cls.mechanic, role="mechanic", available=True)
        Profile.objects.create(user=cls.outsider, role="customer")

    def setUp(self):
        self.client = Client(enforce_csrf_checks=True)
        self.tokens = {user.pk: issue_session(user) for user in (self.customer, self.mechanic, self.outsider)}

    def headers(self, user):
        return {"HTTP_AUTHORIZATION": "Bearer " + self.tokens[user.pk]}

    def get(self, path, user=None, **kwargs):
        return self.client.get(ROOT + path, **(self.headers(user) if user else {}), **kwargs)

    def post(self, path, data=None, user=None):
        return self.client.post(
            ROOT + path, data or {}, content_type="application/json",
            **(self.headers(user) if user else {}),
        )

    def create_job(self):
        response = self.post("requests/", {
            "vehicle_problem": "Flat tyre", "location": "Accra landmark",
            "phone_number": "0200000000", "customer_latitude": 5.6037,
            "customer_longitude": -0.1870, "customer_location_accuracy": 8,
        }, self.customer)
        self.assertEqual(response.status_code, 201, response.content)
        return response.json()["id"]

    def accept(self, job_id):
        return self.post(f"requests/{job_id}/action/", {
            "action": "accept", "latitude": 5.6123, "longitude": -0.2012, "accuracy": 6,
        }, self.mechanic)

    def test_existing_identity_email_login_and_no_cookie(self):
        response = self.post("login/", {"username": "DRIVER@example.test", "password": PASSWORD})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["user"]["id"], self.customer.pk)
        self.assertNotIn("sessionid", response.cookies)
        self.assertNotEqual(response.json()["token"], self.tokens[self.customer.pk])

    def test_bad_and_ambiguous_credentials_never_select_arbitrary_user(self):
        self.assertEqual(self.post("login/", {"username": self.customer.username, "password": "wrong"}).status_code, 400)
        User.objects.create_user("duplicate", email=self.customer.email, password=PASSWORD)
        self.assertEqual(self.post("login/", {"username": self.customer.email, "password": PASSWORD}).status_code, 400)

    def test_email_only_signup_atomic_profile_and_welcome(self):
        before = User.objects.count()
        response = self.post("signup/", {
            "first_name": "New", "last_name": "Driver", "email": "new@example.test",
            "password": PASSWORD, "confirm_password": PASSWORD, "role": "customer",
        })
        self.assertEqual(response.status_code, 201, response.content)
        self.assertEqual(User.objects.count(), before + 1)
        user = User.objects.get(pk=response.json()["user"]["id"])
        self.assertEqual(user.profile.role, "customer")
        self.assertTrue(user.check_password(PASSWORD))
        self.assertEqual(user.app_notifications.count(), 1)
        self.assertNotIn("sessionid", response.cookies)

    def test_signup_validation_preserves_accounts_and_identifies_fields(self):
        before = User.objects.count()
        response = self.post("signup/", {
            "username": self.customer.username, "email": self.customer.email,
            "password": PASSWORD, "confirm_password": "different", "role": "customer",
        })
        self.assertEqual(response.status_code, 400)
        self.assertTrue({"username", "email", "confirm_password"}.issubset(response.json()["errors"]))
        self.assertEqual(User.objects.count(), before)

    def test_signup_rolls_back_when_profile_cannot_be_created(self):
        before = User.objects.count()
        with patch("accounts.mobile_api.views.Profile.objects.create", side_effect=IntegrityError):
            response = self.post("signup/", {
                "username": "rollback-new", "password": PASSWORD,
                "confirm_password": PASSWORD, "role": "mechanic",
            })
        self.assertEqual(response.status_code, 409)
        self.assertEqual(User.objects.count(), before)

    def test_invalid_signup_still_consumes_rate_limit_attempt(self):
        self.assertEqual(self.post("signup/", {}).status_code, 400)
        self.assertTrue(RecoveryRateLimit.objects.filter(count=1).exists())

    def test_website_cookie_is_not_native_authorization(self):
        self.client.force_login(self.customer)
        self.assertEqual(self.get("me/").status_code, 401)
        cookie_session = self.client.cookies["sessionid"].value
        response = self.client.get(ROOT + "me/", HTTP_AUTHORIZATION="Bearer " + cookie_session)
        self.assertEqual(response.status_code, 401)
        self.assertTrue(SessionStore(cookie_session).exists(cookie_session))

    def test_native_token_is_not_a_website_login_cookie(self):
        self.client.cookies["sessionid"] = self.tokens[self.customer.pk]
        response = self.client.get("/customer/dashboard/")
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login/", response.url)

    def test_logout_revokes_only_this_device_and_password_change_revokes_others(self):
        another = issue_session(self.customer)
        self.assertEqual(self.post("logout/", user=self.customer).status_code, 200)
        self.assertEqual(self.get("me/", self.customer).status_code, 401)
        self.tokens[self.customer.pk] = another
        self.assertEqual(self.get("me/", self.customer).status_code, 200)
        self.customer.set_password("Changed-password-728!")
        self.customer.save(update_fields=["password"])
        self.assertEqual(self.get("me/", self.customer).status_code, 401)

    def test_disabled_account_token_rejected(self):
        self.customer.is_active = False
        self.customer.save(update_fields=["is_active"])
        self.assertEqual(self.get("me/", self.customer).status_code, 401)

    def test_generated_bodyless_logout_revokes_the_session(self):
        response = self.client.generic("POST", ROOT + "logout/", data=b"", **self.headers(self.customer))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.get("me/", self.customer).status_code, 401)

    def test_ten_minutes_away_cannot_be_reset_by_foreground_heartbeat(self):
        session = SessionStore(self.tokens[self.customer.pk])
        session["mobile_away_at"] = time.time() - 600
        session.save()
        self.assertEqual(self.post("activity/", {"state": "active"}, self.customer).status_code, 401)
        self.assertEqual(self.get("conversations/", self.customer).status_code, 401)

    def test_short_switch_and_duplicate_away_keep_original_departure(self):
        self.assertEqual(self.post("activity/", {"state": "away"}, self.customer).status_code, 200)
        session = SessionStore(self.tokens[self.customer.pk])
        original = session["mobile_away_at"] - 500
        session["mobile_away_at"] = original
        session.save()
        self.assertEqual(self.post("activity/", {"state": "away"}, self.customer).status_code, 200)
        self.assertEqual(SessionStore(self.tokens[self.customer.pk])["mobile_away_at"], original)
        self.assertEqual(self.post("activity/", {"state": "active"}, self.customer).status_code, 200)
        self.assertIsNone(SessionStore(self.tokens[self.customer.pk]).get("mobile_away_at"))
        self.assertEqual(self.get("me/", self.customer).status_code, 200)

    def test_polling_does_not_extend_idle_session(self):
        session = SessionStore(self.tokens[self.customer.pk])
        original = time.time() - 10700
        session["mobile_last_active"] = original
        session.save()
        for path in ("me/", "conversations/", "notifications/", "dashboard/"):
            self.assertEqual(self.get(path, self.customer).status_code, 200)
        self.assertEqual(SessionStore(self.tokens[self.customer.pk])["mobile_last_active"], original)
        session = SessionStore(self.tokens[self.customer.pk])
        session["mobile_last_active"] = time.time() - 10800
        session.save()
        self.assertEqual(self.get("me/", self.customer).status_code, 401)

    def test_missing_profile_login_and_owner_setup_do_not_overwrite_valid_role(self):
        Profile.objects.filter(user=self.customer).delete()
        response = self.get("me/", self.customer)
        self.assertTrue(response.json()["needs_setup"])
        self.assertIsNone(response.json()["role"])
        response = self.post("setup/", {"role": "mechanic"}, self.customer)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json()["available"])
        self.assertEqual(self.post("setup/", {"role": "customer"}, self.customer).status_code, 409)

    def test_public_directory_has_no_precise_gps_or_private_verification_evidence(self):
        Profile.objects.filter(user=self.mechanic).update(
            latitude=5.6234567, longitude=-0.2345678, service_area="Tema", repair_specialties="Brakes",
        )
        MechanicVerification.objects.create(
            user=self.mechanic, business_name="Workshop", contact_number="private-phone",
            service_area="Tema", experience="Training", credential_reference="private-reference",
            review_notes="private-checks", public_feedback="Public feedback", status="verified",
        )
        response = self.get("mechanics/?area=Tema&specialty=Brakes")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()), 1)
        self.assertTrue(response.json()[0]["verified"])
        detail = self.get(f"mechanics/{self.mechanic.pk}/").json()
        for secret in ("latitude", "longitude", "private-reference", "private-checks", "private-phone"):
            self.assertNotIn(secret, str(detail))
        self.assertEqual(self.get("mechanics/?q=nonexistent").json(), [])

    def test_nearby_search_requires_customer_gps_and_returns_nearest_online_without_exact_positions(self):
        origin = {"latitude": 5.6037, "longitude": -0.187}
        Profile.objects.filter(user=self.mechanic).update(
            latitude=5.604, longitude=-0.187, location_updated_at=timezone.now(),
        )
        other = User.objects.create_user("nearby-second-mechanic", password=PASSWORD)
        Profile.objects.create(
            user=other, role="mechanic", available=True,
            latitude=5.65, longitude=-0.187, location_updated_at=timezone.now(),
        )
        response = self.post("mechanics/nearby/", origin, self.customer)
        self.assertEqual(response.status_code, 200)
        results = response.json()
        self.assertEqual([item["mechanic"]["id"] for item in results], [self.mechanic.pk, other.pk])
        self.assertEqual([item["distance_label"] for item in results], ["Within 1 km", "5–10 km away"])
        for item in results:
            self.assertNotIn("latitude", str(item))
            self.assertNotIn("longitude", str(item))
            self.assertNotIn("location_updated_at", str(item))
        self.assertIsNone(RescueRequest.objects.first())

    def test_nearby_search_does_not_guess_from_stale_or_offline_mechanic_presence(self):
        origin = {"latitude": 5.6037, "longitude": -0.187}
        p = Profile.objects.filter(user=self.mechanic)
        p.update(latitude=5.6037, longitude=-0.187, location_updated_at=timezone.now() - timedelta(minutes=11))
        self.assertEqual(self.post("mechanics/nearby/", origin, self.customer).json(), [])
        p.update(location_updated_at=timezone.now(), available=False)
        self.assertEqual(self.post("mechanics/nearby/", origin, self.customer).json(), [])
        p.update(available=True, latitude=6.2, longitude=-0.187)
        self.assertEqual(self.post("mechanics/nearby/", origin, self.customer).json(), [])
        p.update(latitude=5.6037, location_updated_at=None)
        self.assertEqual(self.post("mechanics/nearby/", origin, self.customer).json(), [])

    def test_nearby_search_requires_authenticated_customer_and_valid_location(self):
        origin = {"latitude": 5.6037, "longitude": -0.187}
        self.assertEqual(self.post("mechanics/nearby/", origin).status_code, 401)
        self.assertEqual(self.post("mechanics/nearby/", origin, self.mechanic).status_code, 403)
        for invalid in ({}, {"latitude": None, "longitude": 1}, {"latitude": True, "longitude": 1},
                        {"latitude": 91, "longitude": 1}, {"latitude": "5.6", "longitude": -0.1},
                        {"latitude": 5.6, "longitude": float("nan")}):
            with self.subTest(invalid=invalid):
                response = self.post("mechanics/nearby/", invalid, self.customer)
                self.assertEqual(response.status_code, 400)

    def test_nearby_refresh_does_not_renew_the_idle_session(self):
        before = SessionStore(session_key=self.tokens[self.customer.pk])["mobile_last_active"]
        response = self.post("mechanics/nearby/", {"latitude": 5.6037, "longitude": -0.187}, self.customer)
        self.assertEqual(response.status_code, 200)
        after = SessionStore(session_key=self.tokens[self.customer.pk])["mobile_last_active"]
        self.assertEqual(after, before)

    def test_request_requires_real_valid_gps_and_customer_role(self):
        self.assertEqual(self.post("requests/", {"vehicle_problem": "Flat"}, self.customer).status_code, 400)
        self.assertEqual(RescueRequest.objects.count(), 0)
        self.assertEqual(self.post("requests/", {}, self.mechanic).status_code, 403)

    def test_acceptance_gps_and_participant_privacy(self):
        job_id = self.create_job()
        self.assertEqual(self.get(f"requests/{job_id}/", self.outsider).status_code, 404)
        self.assertEqual(self.post(f"requests/{job_id}/action/", {"action": "accept"}, self.mechanic).status_code, 400)
        self.assertEqual(RescueRequest.objects.get(pk=job_id).status, "pending")
        response = self.accept(job_id)
        self.assertEqual(response.status_code, 200, response.content)
        self.assertEqual(response.json()["mechanic_position"]["latitude"], 5.6123)
        self.assertEqual(self.accept(job_id).status_code, 409)
        self.assertEqual(self.get(f"requests/{job_id}/", self.outsider).status_code, 404)
        self.assertTrue(self.customer.app_notifications.filter(title__contains="accepted").exists())

    def test_offline_mechanic_queue_hidden_and_cannot_accept(self):
        job_id = self.create_job()
        response = self.client.patch(ROOT + "profile/", {"available": False}, content_type="application/json", **self.headers(self.mechanic))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.get("dashboard/", self.mechanic).json()["nearby"], [])
        self.assertEqual(self.accept(job_id).status_code, 409)

    def test_journey_and_presence_never_change_captured_pins(self):
        job_id = self.create_job()
        accepted = self.accept(job_id).json()
        before_customer, before_mechanic = accepted["customer_position"], accepted["mechanic_position"]
        self.post(f"requests/{job_id}/action/", {"action": "start"}, self.mechanic)
        response = self.post(f"requests/{job_id}/journey/", {
            "enabled": True, "latitude": 6.1, "longitude": -1.2, "accuracy": 12,
        }, self.mechanic)
        self.assertEqual(response.status_code, 200, response.content)
        self.client.patch(ROOT + "profile/", {"latitude": 8.1, "longitude": -2.1}, content_type="application/json", **self.headers(self.mechanic))
        current = self.get(f"requests/{job_id}/", self.customer).json()
        self.assertEqual(current["customer_position"], before_customer)
        self.assertEqual(current["mechanic_position"], before_mechanic)
        self.assertEqual(current["live_position"]["latitude"], 6.1)
        self.assertEqual(self.post(f"requests/{job_id}/journey/", {"enabled": False}, self.mechanic).json()["live_position"], None)

    def test_live_journey_expires_even_when_device_never_sends_stop(self):
        job_id = self.create_job()
        captures = self.accept(job_id).json()
        self.post(f"requests/{job_id}/action/", {"action": "start"}, self.mechanic)
        self.post(f"requests/{job_id}/journey/", {
            "enabled": True, "latitude": 6.1, "longitude": -1.2, "accuracy": 12,
        }, self.mechanic)
        captured_at = RescueRequest.objects.get(pk=job_id).live_location_updated_at
        # No stop request is sent. Exercise every response path after time
        # passes, including the inclusive boundary and invalid future stamps.
        for seconds, visible in [(60, True), (60.001, False), (120, False), (-1, False)]:
            with self.subTest(seconds=seconds), patch(
                "accounts.mobile_api.serializers.timezone.now",
                return_value=captured_at + timedelta(seconds=seconds),
            ):
                detail = self.get(f"requests/{job_id}/", self.customer).json()
                history = self.get("dashboard/", self.customer).json()["requests"]
                entry = next(item for item in history if item["id"] == job_id)
                for result in (detail, entry):
                    self.assertEqual(result["live_tracking_enabled"], visible)
                    self.assertEqual(result["live_position"] is not None, visible)
                    self.assertEqual(result["customer_position"], captures["customer_position"])
                    self.assertEqual(result["mechanic_position"], captures["mechanic_position"])

    def test_live_journey_requires_timestamp_and_travelling_status(self):
        job_id = self.create_job()
        self.accept(job_id)
        for status, stamp in [("on_the_way", None), ("accepted", timezone.now()), ("completed", timezone.now())]:
            with self.subTest(status=status, stamp=stamp):
                RescueRequest.objects.filter(pk=job_id).update(
                    status=status, live_tracking_enabled=True, live_latitude=6.1,
                    live_longitude=-1.2, live_location_updated_at=stamp,
                )
                result = self.get(f"requests/{job_id}/", self.customer).json()
                self.assertIsNone(result["live_position"])
                self.assertFalse(result["live_tracking_enabled"])

    def test_complete_repair_requires_customer_approved_latest_estimate_and_review_owner(self):
        job_id = self.create_job()
        self.accept(job_id)
        self.post(f"requests/{job_id}/action/", {"action": "start"}, self.mechanic)
        self.post(f"requests/{job_id}/action/", {"action": "arrive"}, self.mechanic)
        self.assertEqual(self.post(f"requests/{job_id}/action/", {"action": "complete"}, self.mechanic).status_code, 409)
        response = self.post(f"requests/{job_id}/estimates/", {"description": "Replace tyre", "amount": "150.00"}, self.mechanic)
        self.assertEqual(response.status_code, 200, response.content)
        quote_id = response.json()["estimates"][0]["id"]
        self.assertEqual(self.post(f"estimates/{quote_id}/decision/", {"decision": "accept"}, self.outsider).status_code, 404)
        self.assertEqual(self.post(f"estimates/{quote_id}/decision/", {"decision": "accept"}, self.customer).status_code, 200)
        self.assertEqual(self.post(f"requests/{job_id}/action/", {"action": "complete"}, self.mechanic).json()["status"], "completed")
        self.assertEqual(self.post(f"requests/{job_id}/review/", {"rating": 5, "comment": "Helpful"}, self.mechanic).status_code, 404)
        self.assertEqual(self.post(f"requests/{job_id}/review/", {"rating": 5, "comment": "Helpful"}, self.customer).json()["review"]["rating"], 5)

    def test_history_and_both_sides_messages_survive_changed_or_missing_profiles(self):
        thread = ChatThread.objects.create(customer=self.customer, mechanic=self.mechanic)
        old = ChatMessage.objects.create(thread=thread, sender=self.mechanic, body="Old repair conversation")
        Profile.objects.filter(user=self.customer).delete()
        Profile.objects.filter(user=self.mechanic).update(role="customer")
        inbox = self.get("conversations/", self.customer)
        self.assertEqual(inbox.json()[0]["latest_message"]["id"], old.pk)
        messages = self.get(f"chat/{self.mechanic.pk}/", self.customer)
        self.assertEqual(messages.json()[0]["body"], old.body)
        response = self.post(f"chat/{self.customer.pk}/", {"body": "Still here"}, self.mechanic)
        self.assertEqual(response.status_code, 201, response.content)
        self.assertEqual(self.get("conversations/", self.outsider).json(), [])
        self.assertEqual(self.get(f"chat/{self.customer.pk}/", self.outsider).status_code, 403)

    def test_invalid_new_pair_and_empty_message_create_no_thread(self):
        self.assertEqual(self.post(f"chat/{self.outsider.pk}/", {"body": "Hello"}, self.customer).status_code, 403)
        self.assertEqual(self.post(f"chat/{self.mechanic.pk}/", {}, self.customer).status_code, 400)
        self.assertEqual(ChatThread.objects.count(), 0)

    def test_voice_upload_private_playback_and_nonparticipant_denied(self):
        recording = SimpleUploadedFile("recording.m4a", b"actual-audio-validated-by-shared-validator", content_type="audio/mp4")
        with patch("accounts.mobile_api.chat.validate_audio", return_value=(b"audio", "audio/mp4", 3, "m4a")), patch(
            "accounts.mobile_api.chat.store_voice", return_value="private-voice/development/example.m4a",
        ):
            response = self.client.post(
                ROOT + f"chat/{self.mechanic.pk}/", {"audio": recording, "audio_duration": "3"},
                **self.headers(self.customer),
            )
        self.assertEqual(response.status_code, 201, response.content)
        url = response.json()["audio_url"]
        self.assertEqual(response.json()["body"], "")
        self.assertEqual(self.client.get(url, **self.headers(self.outsider)).status_code, 404)
        self.assertEqual(self.client.get(url).status_code, 401)
        with patch("accounts.chat_views.read_voice", return_value=b"abcdef"):
            audio = self.client.get(url, HTTP_RANGE="bytes=1-3", **self.headers(self.mechanic))
        self.assertEqual(audio.status_code, 206)
        self.assertEqual(audio.content, b"bcd")
        self.assertEqual(audio["Cache-Control"], "private, no-store")

    def test_bad_recording_is_rejected_without_creating_message(self):
        recording = SimpleUploadedFile("bad.m4a", b"not audio", content_type="audio/mp4")
        response = self.client.post(
            ROOT + f"chat/{self.mechanic.pk}/", {"audio": recording, "audio_duration": "2"},
            **self.headers(self.customer),
        )
        self.assertEqual(response.status_code, 400)
        self.assertEqual(ChatMessage.objects.count(), 0)

    def test_verification_cannot_self_approve_or_read_private_admin_notes(self):
        response = self.post("verification/", {
            "business_name": "Workshop", "contact_number": "0200000000",
            "service_area": "Accra", "experience": "Repair training",
            "credential_reference": "Training provider reference", "status": "verified",
        }, self.mechanic)
        self.assertEqual(response.status_code, 200, response.content)
        self.assertEqual(response.json()["status"], "pending")
        MechanicVerification.objects.filter(user=self.mechanic).update(review_notes="private review")
        self.assertNotIn("review_notes", self.get("verification/", self.mechanic).json())
        self.assertEqual(self.get("verification/", self.customer).status_code, 403)

    def test_deletion_request_requires_password_and_does_not_pretend_to_delete(self):
        User.objects.create_user("native-admin", password=PASSWORD, is_staff=True)
        self.assertEqual(self.post("deletion-request/", {"confirm": True, "password": "wrong"}, self.customer).status_code, 400)
        response = self.post("deletion-request/", {"confirm": True, "password": PASSWORD}, self.customer)
        self.assertEqual(response.status_code, 200)
        self.assertIn("no data has been erased", response.json()["message"])
        self.assertTrue(User.objects.get(pk=self.customer.pk).is_active)
        self.post("deletion-request/", {"confirm": True, "password": PASSWORD}, self.customer)
        self.assertEqual(Notification.objects.filter(recipient=self.customer, title="Account deletion requested").count(), 1)

    @override_settings(MOBILE_WEB_ORIGINS=["https://native.example.test"])
    def test_cors_preflight_is_narrow_and_preserves_website_csrf(self):
        preflight = self.client.options(ROOT + "me/", HTTP_ORIGIN="https://native.example.test")
        self.assertEqual(preflight.status_code, 200)
        self.assertEqual(preflight["Access-Control-Allow-Origin"], "https://native.example.test")
        self.assertNotIn("Access-Control-Allow-Credentials", preflight)
        self.assertEqual(self.client.options(ROOT + "me/", HTTP_ORIGIN="https://untrusted.example.test").status_code, 403)
        self.assertEqual(self.client.post("/login/", {"username": self.customer.username, "password": PASSWORD}).status_code, 403)
