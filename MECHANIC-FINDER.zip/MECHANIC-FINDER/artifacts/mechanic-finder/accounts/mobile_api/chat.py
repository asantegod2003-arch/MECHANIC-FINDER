"""Private native conversations, using exactly the existing participant records."""
import logging

from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils import timezone

from ..chat_views import voice_message_audio
from ..conversations import conversation_summaries, threads_for
from ..models import ChatMessage, ChatThread, Notification
from ..notifications import create_notification
from ..views import _chat_participants
from ..voice_storage import remove_voice, store_voice, validate_audio
from . import serializers as s
from .auth import ApiFailure, api, result

logger = logging.getLogger(__name__)


@api("GET")
def conversations(request):
    return result([{
        "other_person": s.person(item["other_person"]),
        "latest_message": s.message(item["latest_message"]) if item["latest_message"] else None,
        "updated_at": item["thread"].updated_at.isoformat(),
    } for item in conversation_summaries(request.user)])


@api("GET", "POST")
def chat(request, other_id):
    customer, mechanic = _chat_participants(request.user, other_id)
    if customer is None:
        raise ApiFailure("New conversations are available between a customer and a mechanic. Existing conversations remain in Messages.", 403)
    if request.method == "GET":
        try:
            after = max(0, int(request.GET.get("after", 0)))
        except (ValueError, TypeError):
            raise ApiFailure("Use a valid message cursor.")
        messages = ChatMessage.objects.filter(
            thread__in=threads_for(request.user, other_id), id__gt=after,
        ).select_related("sender").order_by("id")
        Notification.objects.filter(
            recipient=request.user, url=f"/chat/{other_id}/", read_at__isnull=True,
        ).update(read_at=timezone.now())
        return result([s.message(item) for item in messages])
    if not User.objects.filter(pk=other_id, is_active=True).exists():
        raise ApiFailure("This account cannot receive new messages.", 403)
    body = request.mobile_data.get("body", "")
    if not isinstance(body, str) or len(body.strip()) > 2000:
        raise ApiFailure("Messages must be text of 2,000 characters or fewer.")
    body, audio = body.strip(), request.FILES.get("audio")
    if not body and not audio:
        raise ApiFailure("Write a message or record a voice message before sending.")
    key, mime, duration = "", "", 0
    try:
        if audio:
            data, mime, duration, extension = validate_audio(audio, request.mobile_data.get("audio_duration"))
            key = store_voice(data, extension)
        with transaction.atomic():
            thread, _ = ChatThread.objects.get_or_create(customer=customer, mechanic=mechanic)
            item = ChatMessage.objects.create(
                thread=thread, sender=request.user, body=body,
                audio_object_key=key, audio_mime=mime, audio_duration=duration,
            )
            thread.save(update_fields=["updated_at"])
            other = mechanic if request.user.pk == customer.pk else customer
            create_notification(
                other, f"New message from {s.person(request.user)['name']}"[:120],
                body or "Sent you a voice message. Open the chat to listen.",
                f"/chat/{request.user.pk}/",
            )
    except ValidationError:
        raise
    except Exception as error:
        if key:
            try:
                remove_voice(key)
            except Exception as cleanup_error:
                logger.warning("Native voice cleanup failed: %s", type(cleanup_error).__name__)
        logger.warning("Native message unavailable: %s", type(error).__name__)
        raise ApiFailure("Your message could not be sent. Please retry; voice storage may be temporarily unavailable.", 503)
    return result(s.message(item), 201)


@api("GET")
def voice(request, message_id):
    # Reuse the original private endpoint's participant authorization, byte
    # ranges, container type and App Storage retrieval; no public object URLs.
    return voice_message_audio(request, message_id)
