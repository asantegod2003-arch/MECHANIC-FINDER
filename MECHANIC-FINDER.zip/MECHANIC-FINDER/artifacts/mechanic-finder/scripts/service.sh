#!/usr/bin/env bash
# Shared entry point for artifact workflows and production. No schema writes.
set -euo pipefail
app_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
workspace_root="$(cd "$app_dir/../.." && pwd)"
cd "$app_dir"

case "${1:-}" in
  development)
    : "${PORT:?The artifact workflow must supply PORT}"
    exec python manage.py runserver "0.0.0.0:$PORT"
    ;;
  build)
    # Install into Replit's configured Python environment, never a virtualenv.
    python -m pip install --disable-pip-version-check -r "$workspace_root/requirements.txt"
    DJANGO_DEBUG=False python manage.py collectstatic --noinput
    ;;
  production)
    : "${PORT:?The artifact service must supply PORT}"
    export DJANGO_DEBUG=False
    exec python -m gunicorn \
      --bind "0.0.0.0:$PORT" \
      --access-logfile - --error-logfile - \
      mechanicfinder.wsgi:application
    ;;
  *)
    echo "Usage: service.sh {development|build|production}" >&2
    exit 2
    ;;
esac
