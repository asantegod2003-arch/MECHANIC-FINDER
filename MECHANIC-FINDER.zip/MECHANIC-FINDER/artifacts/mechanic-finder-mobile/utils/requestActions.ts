type Actor = { id: number; role: string | null; available: boolean };
type Request = { status: string; customer: { id: number }; mechanic?: { id: number } | null };

// Accepting is a role/availability permission, not an assignment permission:
// a pending job intentionally has no assigned mechanic yet.
export function canAcceptRequest(actor: Actor | null | undefined, job: Request | null | undefined): boolean {
  return Boolean(
    actor?.role === 'mechanic' && actor.available &&
    job?.status === 'pending' && !job.mechanic &&
    job.customer.id !== actor.id,
  );
}
