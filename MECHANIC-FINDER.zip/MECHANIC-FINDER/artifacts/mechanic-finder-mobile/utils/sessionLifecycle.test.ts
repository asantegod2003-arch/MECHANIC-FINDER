import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import {
  hasExceededAwayLimit,
  IDLE_TIMEOUT_MS,
  preserveFirstAwayTimestamp,
  resolveAwayTimestamp,
  startsAwayPeriod,
} from './sessionLifecycle.ts';

test('idle limit expires at exactly ten minutes, not before', () => {
  assert.equal(hasExceededAwayLimit(1_000, 1_000 + 5 * 60_000), false);
  assert.equal(hasExceededAwayLimit(1_000, 1_000 + IDLE_TIMEOUT_MS - 1), false);
  assert.equal(hasExceededAwayLimit(1_000, 1_000 + IDLE_TIMEOUT_MS), true);
});

test('a repeated away transition preserves the original timestamp', () => {
  assert.equal(preserveFirstAwayTimestamp(100, 250), 100);
  assert.equal(preserveFirstAwayTimestamp(null, 250), 250);
  assert.equal(startsAwayPeriod('background', 'inactive'), false);
});

test('memory departure timestamp survives an interrupted persistence write', () => {
  const inMemoryDeparture = 1_000;
  const persistedDeparture: number | null = null;
  const departure = resolveAwayTimestamp(persistedDeparture, inMemoryDeparture);
  assert.equal(departure, inMemoryDeparture);
  assert.equal(hasExceededAwayLimit(departure, 1_000 + IDLE_TIMEOUT_MS), true);
});
