import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import { canAcceptRequest } from './requestActions.ts';

const mechanic = { id: 2, role: 'mechanic', available: true };
const pending = { status: 'pending', customer: { id: 1 }, mechanic: null };

test('available mechanic can accept an unassigned pending request', () => {
  assert.equal(canAcceptRequest(mechanic, pending), true);
});

test('accept stays hidden for offline, customer, missing-role and signed-out users', () => {
  for (const actor of [
    { ...mechanic, available: false },
    { ...mechanic, role: 'customer' },
    { ...mechanic, role: null },
    null, undefined,
  ]) assert.equal(canAcceptRequest(actor, pending), false);
});

test('accept stays hidden for own, assigned, unavailable and unloaded requests', () => {
  assert.equal(canAcceptRequest({ ...mechanic, id: 1 }, pending), false);
  assert.equal(canAcceptRequest(mechanic, { ...pending, mechanic: { id: 3 } }), false);
  assert.equal(canAcceptRequest(mechanic, { ...pending, mechanic: { id: 2 } }), false);
  for (const status of ['accepted', 'on_the_way', 'arrived', 'completed', 'cancelled'])
    assert.equal(canAcceptRequest(mechanic, { ...pending, status }), false);
  assert.equal(canAcceptRequest(mechanic, null), false);
  assert.equal(canAcceptRequest(mechanic, undefined), false);
});
