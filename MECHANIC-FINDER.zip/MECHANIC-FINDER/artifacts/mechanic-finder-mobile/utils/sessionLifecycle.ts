export const IDLE_TIMEOUT_MS = 600_000;

export function hasExceededAwayLimit(awaySince: number | null, now: number): boolean {
  return awaySince !== null && now - awaySince >= IDLE_TIMEOUT_MS;
}

export function preserveFirstAwayTimestamp(previous: number | null, candidate: number): number {
  return previous ?? candidate;
}

export function resolveAwayTimestamp(persisted: number | null, inMemory: number | null): number | null {
  return inMemory ?? persisted;
}

export function startsAwayPeriod(previousState: string | null | undefined, nextState: string): boolean {
  return previousState === 'active' && nextState !== 'active';
}
