import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState, AppStateStatus, Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useQueryClient } from '@tanstack/react-query';
import { getMobileMe, mobileActivity, mobileLogout } from '@workspace/api-client-react';
import type { MobileUser } from '@workspace/api-client-react';
import { hasExceededAwayLimit, preserveFirstAwayTimestamp, resolveAwayTimestamp, startsAwayPeriod } from '@/utils/sessionLifecycle';

const TOKEN_KEY = 'mechanic-finder-session';
const AWAY_KEY = 'mechanic-finder-away-since';
let browserToken: string | null = null;
let memoryTokenFallback: string | null = null;
let memoryAwayAt: number | null = null;
let awayStorageQueue: Promise<void> = Promise.resolve();
let expireUnauthorized: (() => Promise<void>) | null = null;
const stopOnAway = new Set<() => void>();

export async function getSavedToken(): Promise<string | null> {
  if (Platform.OS === 'web') return browserToken;
  try {
    const saved = await SecureStore.getItemAsync(TOKEN_KEY);
    if (saved) memoryTokenFallback = saved;
    return saved ?? memoryTokenFallback;
  } catch {
    return memoryTokenFallback;
  }
}

async function readAwayTimestamp(): Promise<number | null> {
  if (Platform.OS === 'web') return memoryAwayAt;
  try {
    const persisted = await AsyncStorage.getItem(AWAY_KEY);
    if (persisted !== null) {
      const timestamp = Number(persisted);
      if (Number.isFinite(timestamp)) {
        memoryAwayAt = resolveAwayTimestamp(timestamp, memoryAwayAt);
      }
    }
  } catch {
    // Keep the synchronously recorded process-memory timestamp as a safe fallback.
  }
  return memoryAwayAt;
}

function persistAwayTimestamp(timestamp: number): void {
  memoryAwayAt = preserveFirstAwayTimestamp(memoryAwayAt, timestamp);
  if (Platform.OS !== 'web') {
    const capturedTimestamp = memoryAwayAt;
    awayStorageQueue = awayStorageQueue.catch(() => undefined)
      .then(() => AsyncStorage.setItem(AWAY_KEY, String(capturedTimestamp)))
      .then(() => undefined).catch(() => undefined);
  }
}

function clearAwayTimestamp(): void {
  memoryAwayAt = null;
  if (Platform.OS !== 'web') {
    awayStorageQueue = awayStorageQueue.catch(() => undefined)
      .then(() => AsyncStorage.removeItem(AWAY_KEY))
      .then(() => undefined).catch(() => undefined);
  }
}

export function stopForegroundTasks(): void {
  for (const stop of stopOnAway) {
    try { stop(); } catch { /* a screen may already have unmounted */ }
  }
}

export function registerForegroundStopper(stop: () => void): () => void {
  stopOnAway.add(stop);
  return () => stopOnAway.delete(stop);
}

export async function clearUnauthorizedSession(): Promise<void> {
  await expireUnauthorized?.();
}

export function handleUnauthorizedError(error: unknown): void {
  if ((error as { status?: number } | null)?.status === 401) void clearUnauthorizedSession();
}

function reportActivity(state: 'active' | 'away', token: string): void {
  void mobileActivity({ state }, { headers: { Authorization: `Bearer ${token}` } }).catch(handleUnauthorizedError);
}

type AuthContextValue = {
  user: MobileUser | null;
  token: string | null;
  ready: boolean;
  validating: boolean;
  validationError: string | null;
  isAuthenticated: boolean;
  setSession: (token: string, user: MobileUser) => Promise<void>;
  updateUser: (user: MobileUser) => void;
  logout: () => Promise<void>;
  validateSession: () => Promise<boolean>;
  noteExplicitAction: () => void;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<MobileUser | null>(null);
  const [ready, setReady] = useState(false);
  const [validating, setValidating] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const appState = useRef<string | null | undefined>(AppState.currentState);
  const tokenRef = useRef<string | null>(null);
  const sessionValidated = useRef(false);
  const lastExplicitHeartbeat = useRef(0);

  const clearLocalSession = useCallback(async () => {
    stopForegroundTasks();
    tokenRef.current = null;
    memoryTokenFallback = null;
    sessionValidated.current = false;
    setToken(null);
    setUser(null);
    setValidationError(null);
    if (Platform.OS === 'web') {
      browserToken = null;
    } else {
      void Promise.allSettled([SecureStore.deleteItemAsync(TOKEN_KEY)]);
    }
    clearAwayTimestamp();
    queryClient.clear();
  }, [queryClient]);

  const validateSession = useCallback(async () => {
    const saved = tokenRef.current ?? await getSavedToken();
    if (!saved) {
      setReady(true);
      setValidating(false);
      sessionValidated.current = false;
      return false;
    }
    tokenRef.current = saved;
    setToken(saved);
    sessionValidated.current = false;
    setValidating(true);
    setValidationError(null);
    try {
      const currentUser = await getMobileMe();
      setUser(currentUser);
      sessionValidated.current = true;
      setReady(true);
      clearAwayTimestamp();
      reportActivity('active', saved);
      return true;
    } catch (error) {
      const status = (error as { status?: number }).status;
      if (status === 401) {
        await clearLocalSession();
        setReady(true);
      } else {
        setValidationError('We could not confirm your account. Check your connection and try again.');
        setReady(true);
      }
      return false;
    } finally {
      setValidating(false);
    }
  }, [clearLocalSession]);

  const setSession = useCallback(async (nextToken: string, nextUser: MobileUser) => {
    if (Platform.OS === 'web') browserToken = nextToken;
    else await SecureStore.setItemAsync(TOKEN_KEY, nextToken, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
    clearAwayTimestamp();
    tokenRef.current = nextToken;
    memoryTokenFallback = nextToken;
    sessionValidated.current = true;
    setToken(nextToken);
    setUser(nextUser);
    setValidationError(null);
    setReady(true);
    reportActivity('active', nextToken);
  }, []);

  const expireAwaySession = useCallback(async (capturedToken: string) => {
    const revoke = mobileLogout({ headers: { Authorization: `Bearer ${capturedToken}` } }).catch(() => undefined);
    await clearLocalSession();
    setReady(true);
    void revoke;
  }, [clearLocalSession]);

  const logout = useCallback(async () => {
    const capturedToken = tokenRef.current;
    try {
      if (capturedToken) await mobileLogout({ headers: { Authorization: `Bearer ${capturedToken}` } });
    } catch {
      // Local credentials are removed even if the server cannot be reached.
    } finally {
      await clearLocalSession();
      setReady(true);
    }
  }, [clearLocalSession]);

  const noteExplicitAction = useCallback(() => {
    const now = Date.now();
    const capturedToken = tokenRef.current;
    if (!capturedToken || !sessionValidated.current || now - lastExplicitHeartbeat.current < 60_000) return;
    lastExplicitHeartbeat.current = now;
    reportActivity('active', capturedToken);
  }, []);

  useEffect(() => {
    expireUnauthorized = async () => { await clearLocalSession(); setReady(true); };
    void (async () => {
      const saved = await getSavedToken();
      const awayAt = await readAwayTimestamp();
      if (saved && hasExceededAwayLimit(awayAt, Date.now())) {
        tokenRef.current = saved;
        memoryTokenFallback = saved;
        await expireAwaySession(saved);
        return;
      }
      if (saved) {
        tokenRef.current = saved;
        await validateSession();
      } else {
        clearAwayTimestamp();
        setReady(true);
      }
    })().catch(() => {
      setValidationError('We could not restore your account. Check your connection and try again.');
      setReady(true);
    });
    return () => { expireUnauthorized = null; };
  }, [clearLocalSession, expireAwaySession, validateSession]);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (nextState: AppStateStatus) => {
      const previousState = appState.current;
      const isAway = startsAwayPeriod(previousState, nextState);
      const isResume = previousState !== 'active' && nextState === 'active';
      appState.current = nextState;
      if (isAway) {
        stopForegroundTasks();
        const capturedToken = tokenRef.current;
        persistAwayTimestamp(Date.now());
        if (capturedToken) reportActivity('away', capturedToken);
      } else if (isResume && tokenRef.current) {
        const capturedToken = tokenRef.current;
        void (async () => {
          const persisted = await readAwayTimestamp();
          const awayAt = resolveAwayTimestamp(persisted, memoryAwayAt);
          if (hasExceededAwayLimit(awayAt, Date.now())) {
            await expireAwaySession(capturedToken);
            return;
          }
          await validateSession();
        })().catch(handleUnauthorizedError);
      }
    });
    return () => subscription.remove();
  }, [expireAwaySession, validateSession]);

  const value = useMemo<AuthContextValue>(() => ({
    user, token, ready, validating, validationError, isAuthenticated: Boolean(token && user),
    setSession, updateUser: setUser, logout, validateSession, noteExplicitAction,
  }), [user, token, ready, validating, validationError, setSession, logout, validateSession, noteExplicitAction]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
