import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View, TextInputProps, ViewStyle } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/contexts/AuthContext';

export function Screen({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  const colors = useColors();
  return <View style={[styles.screen, { backgroundColor: colors.background }, style]}>{children}</View>;
}

export function PrimaryButton({ title, onPress, disabled, secondary = false, danger = false, testID }: {
  title: string; onPress: () => void; disabled?: boolean; secondary?: boolean; danger?: boolean; testID?: string;
}) {
  const colors = useColors();
  const auth = useAuth();
  const bg = danger ? colors.destructive : secondary ? colors.secondary : colors.primary;
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={title} testID={testID} onPress={() => { auth.noteExplicitAction(); onPress(); }} disabled={disabled}
      style={({ pressed }) => [styles.button, { backgroundColor: bg, opacity: disabled ? 0.5 : pressed ? 0.82 : 1 }]}>
      <Text style={[styles.buttonText, { color: secondary ? colors.secondaryForeground : colors.primaryForeground }]}>{title}</Text>
    </Pressable>
  );
}

export function TextButton({ title, onPress, accessibilityLabel }: { title: string; onPress: () => void; accessibilityLabel?: string }) {
  const colors = useColors();
  const auth = useAuth();
  return <Pressable accessibilityRole="button" accessibilityLabel={accessibilityLabel ?? title} hitSlop={8} onPress={() => { auth.noteExplicitAction(); onPress(); }}
    style={({ pressed }) => [styles.textButton, { opacity: pressed ? 0.65 : 1 }]}>
    <Text style={{ color: colors.primary, fontFamily: 'Poppins_600SemiBold', fontSize: 14 }}>{title}</Text>
  </Pressable>;
}

export function Field({ label, error, multiline, ...props }: TextInputProps & { label: string; error?: string }) {
  const colors = useColors();
  return <View style={styles.fieldWrap}>
    <Text accessibilityRole="text" style={[styles.fieldLabel, { color: colors.foreground }]}>{label}</Text>
    <TextInput
      accessibilityLabel={label}
      placeholderTextColor={colors.mutedForeground}
      multiline={multiline}
      textAlignVertical={multiline ? 'top' : 'center'}
      {...props}
      style={[
        styles.input, { borderColor: error ? colors.destructive : colors.border, backgroundColor: colors.card, color: colors.foreground },
        multiline && styles.multiline, props.style,
      ]}
    />
    {error ? <Text accessibilityRole="alert" style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}
  </View>;
}

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  const colors = useColors();
  return <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }, style]}>{children}</View>;
}

export function SectionTitle({ children, detail }: { children: React.ReactNode; detail?: string }) {
  const colors = useColors();
  return <View style={styles.section}>
    <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{children}</Text>
    {detail ? <Text style={[styles.detail, { color: colors.mutedForeground }]}>{detail}</Text> : null}
  </View>;
}

export function ErrorNotice({ message, retry }: { message: string; retry?: () => void }) {
  const colors = useColors();
  return <Card style={{ borderColor: colors.destructive }}>
    <Text accessibilityRole="alert" style={{ color: colors.destructive, fontFamily: 'Poppins_500Medium', marginBottom: retry ? 8 : 0 }}>{message}</Text>
    {retry ? <TextButton title="Try again" onPress={retry} /> : null}
  </Card>;
}

export function LoadingState({ label = 'Loading' }: { label?: string }) {
  const colors = useColors();
  return <View accessibilityRole="progressbar" accessibilityLabel={label} style={styles.loading}>
    <ActivityIndicator color={colors.primary} />
    <Text style={{ color: colors.mutedForeground, fontFamily: 'Poppins_500Medium' }}>{label}</Text>
  </View>;
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  button: { minHeight: 48, borderRadius: 10, paddingHorizontal: 16, alignItems: 'center', justifyContent: 'center', marginVertical: 5 },
  buttonText: { fontFamily: 'Poppins_600SemiBold', fontSize: 15, textAlign: 'center' },
  textButton: { alignSelf: 'flex-start', paddingVertical: 8 },
  fieldWrap: { marginBottom: 12 },
  fieldLabel: { fontFamily: 'Poppins_500Medium', fontSize: 13, marginBottom: 5 },
  input: { width: '100%', minHeight: 48, borderWidth: 1, borderRadius: 9, paddingHorizontal: 13, paddingVertical: 11, fontFamily: 'Poppins_400Regular', fontSize: 14 },
  multiline: { minHeight: 92 },
  errorText: { fontFamily: 'Poppins_400Regular', fontSize: 12, marginTop: 4 },
  card: { borderWidth: 1, padding: 16, marginVertical: 7, shadowOpacity: 0.04, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 1 },
  section: { marginTop: 17, marginBottom: 7 },
  sectionTitle: { fontFamily: 'Poppins_600SemiBold', fontSize: 19 },
  detail: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 20, marginTop: 3 },
  loading: { minHeight: 120, alignItems: 'center', justifyContent: 'center', gap: 12 },
});
