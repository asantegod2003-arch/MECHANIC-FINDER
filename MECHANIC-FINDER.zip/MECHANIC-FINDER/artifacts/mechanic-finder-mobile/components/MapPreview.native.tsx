import React from 'react';
import { Platform, StyleSheet } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE, Region } from 'react-native-maps';
import { useColors } from '@/hooks/useColors';

export type MapPin = { latitude: number; longitude: number; title: string; subtitle?: string };
type Props = { points: MapPin[]; height?: number; accessibilityLabel: string };

export default function MapPreview({ points, height = 230, accessibilityLabel }: Props) {
  const colors = useColors();
  if (!points.length) return null;
  const latitude = points.reduce((sum, point) => sum + point.latitude, 0) / points.length;
  const longitude = points.reduce((sum, point) => sum + point.longitude, 0) / points.length;
  const latExtent = Math.max(...points.map((point) => Math.abs(point.latitude - latitude)), 0.004);
  const lngExtent = Math.max(...points.map((point) => Math.abs(point.longitude - longitude)), 0.004);
  const region: Region = { latitude, longitude, latitudeDelta: Math.max(0.009, latExtent * 2.4), longitudeDelta: Math.max(0.009, lngExtent * 2.4) };
  return <MapView style={[styles.map, { height }]} region={region} provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
    accessibilityLabel={accessibilityLabel} showsCompass showsScale scrollEnabled zoomEnabled>
    {points.map((point, index) => <Marker key={`${point.title}-${index}`} coordinate={point} title={point.title} description={point.subtitle} pinColor={index === 0 ? colors.primary : colors.secondaryForeground} />)}
  </MapView>;
}

const styles = StyleSheet.create({ map: { width: '100%' } });
