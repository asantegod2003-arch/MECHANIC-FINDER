import React from 'react';
import { router } from 'expo-router';
import { Card, ErrorNotice, LoadingState, PrimaryButton } from '@/components/ui';
import { useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';
import { Text } from 'react-native';

export function AuthGate({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const colors = useColors();
  if (!auth.ready || auth.validating) return <LoadingState label="Checking your account" />;
  if (auth.validationError) return <ErrorNotice message={auth.validationError} retry={() => void auth.validateSession()} />;
  if (!auth.user) return <Card>
    <Text style={{ color: colors.foreground, fontFamily: 'Poppins_600SemiBold', fontSize: 17 }}>Sign in to continue</Text>
    <Text style={{ color: colors.mutedForeground, fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 20, marginTop: 5 }}>Your private account information is only shown after your session is verified.</Text>
    <PrimaryButton title="Go to sign in" onPress={() => router.push('/(tabs)')} />
  </Card>;
  return <>{children}</>;
}
