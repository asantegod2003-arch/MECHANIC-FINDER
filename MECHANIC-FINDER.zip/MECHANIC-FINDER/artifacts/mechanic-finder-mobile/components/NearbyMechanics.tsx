import React, { useEffect, useState } from 'react';
import { AppState, Linking, Platform, StyleSheet, Text } from 'react-native';
import { router } from 'expo-router';
import * as Location from 'expo-location';
import { findNearbyMobileMechanics } from '@workspace/api-client-react';
import type { NearbyMechanic } from '@workspace/api-client-react';
import { useColors } from '@/hooks/useColors';
import { handleUnauthorizedError } from '@/contexts/AuthContext';
import { Card, LoadingState, PrimaryButton, SectionTitle } from '@/components/ui';

type Status = 'loading' | 'ready' | 'denied' | 'error';

export function NearbyMechanics({ customerId }: { customerId: number }) {
  const colors = useColors();
  const [status, setStatus] = useState<Status>('loading');
  const [items, setItems] = useState<NearbyMechanic[]>([]);
  const [blocked, setBlocked] = useState(false);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    const refresh = () => setAttempt(value => value + 1);
    const timer = setInterval(() => {
      if (AppState.currentState === 'active' &&
        (Platform.OS !== 'web' || document.visibilityState === 'visible')) refresh();
    }, 3 * 60_000);
    const listener = AppState.addEventListener('change', state => { if (state === 'active') refresh(); });
    const onVisible = () => { if (document.visibilityState === 'visible') refresh(); };
    if (Platform.OS === 'web') document.addEventListener('visibilitychange', onVisible);
    return () => {
      clearInterval(timer);
      listener.remove();
      if (Platform.OS === 'web') document.removeEventListener('visibilitychange', onVisible);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    const load = async () => {
      setStatus('loading');
      try {
        const permission = await Location.requestForegroundPermissionsAsync();
        if (cancelled) return;
        if (!permission.granted) {
          setBlocked(!permission.canAskAgain);
          setStatus('denied');
          return;
        }
        const fix = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
        if (cancelled) return;
        const matches = await findNearbyMobileMechanics({
          latitude: fix.coords.latitude,
          longitude: fix.coords.longitude,
        }, { signal: controller.signal });
        if (cancelled) return;
        setItems(matches);
        setStatus('ready');
      } catch (error) {
        if (!cancelled) {
          handleUnauthorizedError(error);
          setStatus('error');
        }
      }
    };
    void load();
    return () => { cancelled = true; controller.abort(); };
  }, [customerId, attempt]);

  return <>
    <SectionTitle detail="Online mechanics within 25 km, nearest first. Distances are approximate.">Mechanics near you</SectionTitle>
    {status === 'loading' ? <LoadingState label="Finding nearby mechanics" /> : null}
    {status === 'denied' ? <Card>
      <Text style={[styles.body, { color: colors.foreground }]}>Allow location to see mechanics near you, or browse by service area instead.</Text>
      <PrimaryButton title="Try location again" onPress={() => setAttempt(value => value + 1)} secondary />
      {blocked && Platform.OS !== 'web' ? <PrimaryButton title="Open location settings" secondary onPress={() => void Linking.openSettings().catch(() => undefined)} /> : null}
    </Card> : null}
    {status === 'error' ? <Card>
      <Text style={[styles.body, { color: colors.foreground }]}>We could not check nearby mechanics right now. You can still search by area.</Text>
      <PrimaryButton title="Retry nearby search" onPress={() => setAttempt(value => value + 1)} secondary />
    </Card> : null}
    {status === 'ready' && items.length === 0 ? <Card>
      <Text style={[styles.body, { color: colors.foreground }]}>No online mechanic with a recently updated location was found within 25 km. Browse all mechanics by area, or check again later.</Text>
      <PrimaryButton title="Check again" onPress={() => setAttempt(value => value + 1)} secondary />
    </Card> : null}
    {status === 'ready' ? items.map(({ mechanic, distance_label }) => <Card key={mechanic.id}>
      <Text style={[styles.name, { color: colors.foreground }]}>{mechanic.name}</Text>
      <Text style={[styles.distance, { color: colors.primary }]}>{distance_label} · Available</Text>
      <Text style={[styles.body, { color: colors.mutedForeground }]}>{mechanic.service_area || 'Service area not listed'}{mechanic.repair_specialties ? ` · ${mechanic.repair_specialties}` : ''}</Text>
      <PrimaryButton title={`View ${mechanic.name}'s profile`} secondary
        onPress={() => router.push({ pathname: '/mechanic/[id]', params: { id: String(mechanic.id) } })} />
    </Card>) : null}
    <PrimaryButton title="Browse all mechanics by area" secondary onPress={() => router.push('/(tabs)/find')} />
  </>;
}

const styles = StyleSheet.create({
  name: { fontFamily: 'Poppins_600SemiBold', fontSize: 17 },
  distance: { fontFamily: 'Poppins_600SemiBold', fontSize: 14, marginTop: 5 },
  body: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 20, marginTop: 5 },
});
