import React, { useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import type { MapPin } from './MapPreview.native';

type Props = { points: MapPin[]; height?: number; accessibilityLabel: string };
const TILE = 256;
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

function pixelPoint(latitude: number, longitude: number, zoom: number) {
  const scale = TILE * 2 ** zoom;
  const lat = clamp(latitude, -85.0511, 85.0511) * Math.PI / 180;
  return {
    x: (longitude + 180) / 360 * scale,
    y: (1 - Math.log(Math.tan(lat) + 1 / Math.cos(lat)) / Math.PI) / 2 * scale,
  };
}

export default function MapPreview({ points, height = 230, accessibilityLabel }: Props) {
  const colors = useColors();
  const [width, setWidth] = useState(0);
  if (!points.length) return null;
  const latitude = points.reduce((sum, point) => sum + point.latitude, 0) / points.length;
  const longitude = points.reduce((sum, point) => sum + point.longitude, 0) / points.length;
  const spread = Math.max(...points.map((point) => Math.abs(point.latitude - latitude)), ...points.map((point) => Math.abs(point.longitude - longitude)), 0.001);
  const zoom = clamp(Math.floor(Math.log2(Math.max(1, Math.min(width || 360, height) / (spread * 256 / 360)) / 2)), 3, 17);
  const center = pixelPoint(latitude, longitude, zoom);
  const centerTileX = Math.floor(center.x / TILE);
  const centerTileY = Math.floor(center.y / TILE);
  const tiles = [];
  for (let y = -1; y <= 1; y += 1) {
    for (let x = -1; x <= 1; x += 1) {
      const tileX = (centerTileX + x + 2 ** zoom) % 2 ** zoom;
      const tileY = clamp(centerTileY + y, 0, 2 ** zoom - 1);
      tiles.push({
        key: `${zoom}-${tileX}-${tileY}-${x}-${y}`,
        uri: `https://tile.openstreetmap.org/${zoom}/${tileX}/${tileY}.png`,
        left: width / 2 + (centerTileX + x) * TILE - center.x,
        top: height / 2 + (centerTileY + y) * TILE - center.y,
      });
    }
  }
  return <View accessibilityLabel={accessibilityLabel} accessibilityRole="image" onLayout={(event) => setWidth(event.nativeEvent.layout.width)}
    style={[styles.frame, { height, borderColor: colors.border, backgroundColor: colors.secondary }]}>
    {tiles.map((tile) => <Image key={tile.key} source={{ uri: tile.uri }} resizeMode="stretch"
      style={{ position: 'absolute', left: tile.left, top: tile.top, width: TILE, height: TILE }} />)}
    {points.map((point, index) => {
      const pixel = pixelPoint(point.latitude, point.longitude, zoom);
      return <View key={`${point.title}-${index}`} accessibilityLabel={point.title}
        style={[styles.pin, { left: width / 2 + pixel.x - center.x - 8, top: height / 2 + pixel.y - center.y - 8, backgroundColor: colors.primary, borderColor: colors.card }]} />;
    })}
    <Text style={[styles.attribution, { color: colors.foreground, backgroundColor: colors.card }]}>© OpenStreetMap contributors</Text>
  </View>;
}

const styles = StyleSheet.create({
  frame: { width: '100%', overflow: 'hidden', borderWidth: 1, borderRadius: 10 },
  pin: { position: 'absolute', width: 16, height: 16, borderWidth: 3, borderRadius: 8 },
  attribution: { position: 'absolute', right: 4, bottom: 3, fontFamily: 'Poppins_400Regular', fontSize: 9, paddingHorizontal: 4, borderRadius: 3 },
});
