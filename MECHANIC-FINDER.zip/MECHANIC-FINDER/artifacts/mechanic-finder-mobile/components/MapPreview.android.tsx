import React from 'react';
import { Linking, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import Constants, { ExecutionEnvironment } from 'expo-constants';
import MapView, { Marker, PROVIDER_GOOGLE, Region } from 'react-native-maps';
import MapTiles from './MapPreview.web';
import type { MapPin } from './MapPreview.native';
import { useColors } from '@/hooks/useColors';

type Props = { points: MapPin[]; height?: number; accessibilityLabel: string };

export default function MapPreview({ points, height = 230, accessibilityLabel }: Props) {
  const colors = useColors();
  if (!points.length) return null;
  const latitude = points.reduce((sum, point) => sum + point.latitude, 0) / points.length;
  const longitude = points.reduce((sum, point) => sum + point.longitude, 0) / points.length;
  const latExtent = Math.max(...points.map((point) => Math.abs(point.latitude - latitude)), 0.004);
  const lngExtent = Math.max(...points.map((point) => Math.abs(point.longitude - longitude)), 0.004);
  const region: Region = { latitude, longitude, latitudeDelta: Math.max(0.009, latExtent * 2.4), longitudeDelta: Math.max(0.009, lngExtent * 2.4) };
  const config = Constants.expoConfig as { android?: { config?: { googleMaps?: { apiKey?: string } } } } | null;
  const hasGoogleMaps = Constants.executionEnvironment === ExecutionEnvironment.StoreClient ||
    Boolean(config?.android?.config?.googleMaps?.apiKey?.trim());

  if (!hasGoogleMaps) return <View>
    <MapTiles points={points} height={height} accessibilityLabel={`${accessibilityLabel}. OpenStreetMap preview because Google Maps is not configured in this standalone build.`} />
    <Text accessibilityRole="text" style={[styles.caption, { color: colors.mutedForeground }]}>
      This build has no Google Maps SDK key. The captured location is shown on an OpenStreetMap preview.
    </Text>
    <Pressable accessibilityRole="link" accessibilityLabel="Open this captured location in Google Maps"
      onPress={() => void Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`).catch(() => undefined)}
      style={({ pressed }) => [styles.link, { backgroundColor: colors.secondary, opacity: pressed ? 0.75 : 1 }]}>
      <Text style={[styles.linkText, { color: colors.secondaryForeground }]}>Open location in Google Maps</Text>
    </Pressable>
  </View>;

  return <MapView style={[styles.map, { height }]} region={region} provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
    accessibilityLabel={accessibilityLabel} showsCompass showsScale scrollEnabled zoomEnabled>
    {points.map((point, index) => <Marker key={`${point.title}-${index}`} coordinate={point} title={point.title} description={point.subtitle} pinColor={index === 0 ? colors.primary : colors.secondaryForeground} />)}
  </MapView>;
}

const styles = StyleSheet.create({
  map: { width: '100%' },
  caption: { fontFamily: 'Poppins_400Regular', fontSize: 11, lineHeight: 17, marginTop: 7 },
  link: { alignSelf: 'flex-start', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 9, marginTop: 8 },
  linkText: { fontFamily: 'Poppins_600SemiBold', fontSize: 12 },
});
