import React from 'react';
import { Platform, ScrollView, StyleSheet, Text } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useGetMobileMechanic } from '@workspace/api-client-react';
import { Screen, Card, ErrorNotice, LoadingState, PrimaryButton, SectionTitle } from '@/components/ui';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/contexts/AuthContext';

export default function MechanicProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const mechanicId = Number(id);
  const colors = useColors();
  const auth = useAuth();
  const query = useGetMobileMechanic(mechanicId, { query: { enabled: Number.isInteger(mechanicId) && mechanicId > 0 } });
  const mechanic = query.data;
  const top = Platform.OS === 'web' ? 67 : 0;
  if (!Number.isInteger(mechanicId) || mechanicId <= 0) return <Screen><ErrorNotice message="This mechanic profile address is invalid." /></Screen>;
  if (query.isLoading) return <Screen><LoadingState label="Loading public mechanic profile" /></Screen>;
  if (query.isError || !mechanic) return <Screen><ErrorNotice message="This mechanic profile could not be loaded." retry={() => void query.refetch()} /></Screen>;
  const canStartChat = auth.user?.role === 'customer';
  return <Screen>
    <ScrollView contentContainerStyle={{ paddingTop: top + 12, paddingHorizontal: 18, paddingBottom: 40 }}>
      <SectionTitle detail={mechanic.business_name || mechanic.service_area || 'Public mechanic profile'}>{mechanic.name}</SectionTitle>
      <Card>
        <Text style={[styles.badge, { color: mechanic.verified ? colors.primary : colors.mutedForeground }]}>{mechanic.verified ? 'Verified mechanic' : 'Verification not yet complete'}</Text>
        <Text style={[styles.heading, { color: colors.foreground }]}>{mechanic.available ? 'Available for work' : 'Currently unavailable'}</Text>
        <Text style={[styles.label, { color: colors.mutedForeground }]}>Service area</Text>
        <Text style={[styles.value, { color: colors.foreground }]}>{mechanic.service_area || 'Not provided'}</Text>
        <Text style={[styles.label, { color: colors.mutedForeground }]}>Repair specialties</Text>
        <Text style={[styles.value, { color: colors.foreground }]}>{mechanic.repair_specialties || 'Not provided'}</Text>
        <Text style={[styles.label, { color: colors.mutedForeground }]}>Customer feedback</Text>
        <Text style={[styles.value, { color: colors.foreground }]}>{mechanic.average_rating == null ? 'No customer ratings yet' : `${mechanic.average_rating.toFixed(1)} out of 5 · ${mechanic.review_count} reviews`}</Text>
      </Card>
      <SectionTitle>Completed repair reviews</SectionTitle>
      {mechanic.reviews.length ? mechanic.reviews.map((review, index) => <Card key={`${review.created_at}-${index}`}>
        <Text style={[styles.review, { color: colors.primary }]}>{review.rating} out of 5 · {review.customer_name}</Text>
        {review.comment ? <Text style={[styles.value, { color: colors.foreground }]}>{review.comment}</Text> : null}
        <Text style={[styles.label, { color: colors.mutedForeground }]}>{new Date(review.created_at).toLocaleDateString()}</Text>
      </Card>) : <Card><Text style={[styles.value, { color: colors.mutedForeground }]}>This mechanic has no public repair reviews yet.</Text></Card>}
      {auth.user?.role === 'customer' ? <PrimaryButton title="Message this mechanic" onPress={() => router.push({ pathname: '/chat/[otherId]', params: { otherId: String(mechanic.id), name: mechanic.name } })} /> : null}
      {!auth.user ? <PrimaryButton title="Sign in to message this mechanic" secondary onPress={() => router.push('/(tabs)')} /> : null}
      {auth.user?.role === 'mechanic' ? <Text style={[styles.value, { color: colors.mutedForeground }]}>Use a repair request to message a customer about their service.</Text> : null}
      {auth.user?.role === 'customer' ? <PrimaryButton title="Request roadside help" secondary onPress={() => router.push('/request/new')} /> : null}
    </ScrollView>
  </Screen>;
}

const styles = StyleSheet.create({
  badge: { fontFamily: 'Poppins_600SemiBold', fontSize: 13 },
  heading: { fontFamily: 'Poppins_700Bold', fontSize: 18, marginTop: 7 },
  label: { fontFamily: 'Poppins_500Medium', fontSize: 12, marginTop: 13 },
  value: { fontFamily: 'Poppins_400Regular', fontSize: 14, lineHeight: 22, marginTop: 4 },
  review: { fontFamily: 'Poppins_600SemiBold', fontSize: 13 },
});
