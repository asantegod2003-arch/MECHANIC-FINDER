import React, { useEffect, useRef, useState } from 'react';
import { FlatList, Linking, Platform, StyleSheet, Text, TextInput, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { File } from 'expo-file-system';
import {
  RecordingPresets, requestRecordingPermissionsAsync,
  setAudioModeAsync, useAudioPlayer, useAudioRecorder, useAudioRecorderState,
} from 'expo-audio';
import { useQueryClient } from '@tanstack/react-query';
import { getGetMobileMessagesQueryKey, getGetMobileVoiceUrl, getMobileVoice, sendMobileMessage, useGetMobileMessages } from '@workspace/api-client-react';
import type { Message } from '@workspace/api-client-react';
import { AuthGate } from '@/components/AuthGate';
import { ErrorNotice, PrimaryButton, Screen, TextButton } from '@/components/ui';
import { handleUnauthorizedError, registerForegroundStopper, useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

const MAX_AUDIO_SECONDS = 120;
const MAX_AUDIO_BYTES = 8 * 1024 * 1024;

export default function ChatScreen() {
  const params = useLocalSearchParams<{ otherId: string; name?: string }>();
  const otherId = Number(params.otherId);
  const personName = params.name || 'Conversation';
  const auth = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const query = useGetMobileMessages(otherId, undefined, {
    query: { enabled: Number.isInteger(otherId) && otherId > 0 && auth.isAuthenticated, refetchInterval: 5_000 },
  });
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recordingState = useAudioRecorderState(recorder, 300);
  const localPlayer = useAudioPlayer(null);
  const inputRef = useRef<React.ElementRef<typeof TextInput>>(null);
  const previewUrlRef = useRef<string | null>(null);
  const [body, setBody] = useState('');
  const [recording, setRecording] = useState(false);
  const [clipUri, setClipUri] = useState<string | null>(null);
  const [clipDuration, setClipDuration] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [permissionMessage, setPermissionMessage] = useState('');
  const [permissionBlocked, setPermissionBlocked] = useState(false);
  const [webPlaybackUrl, setWebPlaybackUrl] = useState<string | null>(null);
  const headerTop = Platform.OS === 'web' ? 67 : insets.top;
  const data = [...(query.data ?? [])].reverse();

  const stopRecorder = async () => {
    if (recorder.isRecording) {
      try { await recorder.stop(); } catch { /* already stopped by the audio session */ }
    }
    setRecording(false);
  };
  const finishRecording = async () => {
    await stopRecorder();
    const uri = recorder.uri;
    const duration = Math.min(MAX_AUDIO_SECONDS, Math.max(0, recorder.currentTime));
    if (!uri || duration <= 0) { setError('No voice recording was captured. Try again.'); return; }
    const file = new File(uri);
    if (!file.size || file.size > MAX_AUDIO_BYTES) {
      setError(file.size ? 'Voice messages must be no larger than 8 MB.' : 'The recording file size could not be confirmed. Please record it again.');
      return;
    }
    setClipUri(uri); setClipDuration(duration);
    setPermissionMessage(duration >= MAX_AUDIO_SECONDS
      ? 'Voice message ready. The two-minute limit was reached. Preview it, record again, or send.'
      : 'Voice message ready. Preview it, record again, or send.');
  };
  useEffect(() => registerForegroundStopper(() => {
    if (recording) void finishRecording();
    localPlayer.pause();
  }), [localPlayer, recorder, recording]);
  useEffect(() => () => {
    void stopRecorder();
    localPlayer.pause();
    if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
  }, [localPlayer, recorder]);
  useEffect(() => {
    if (recording && recordingState.durationMillis >= MAX_AUDIO_SECONDS * 1000) {
      void finishRecording();
    }
  }, [recording, recordingState.durationMillis]);
  useEffect(() => () => { if (clipUri) { try { new File(clipUri).delete(); } catch { /* temporary file cleanup is best-effort */ } } }, [clipUri]);
  useEffect(() => {
    if (!webPlaybackUrl) return;
    return () => URL.revokeObjectURL(webPlaybackUrl);
  }, [webPlaybackUrl]);

  const send = async () => {
    const trimmed = body.trim();
    if (!trimmed && !clipUri) { setError('Write a message or record a voice message before sending.'); return; }
    setBusy(true); setError(''); auth.noteExplicitAction();
    try {
      const payload: { body?: string; audio?: File; audio_duration?: number } = {};
      if (trimmed) payload.body = trimmed;
      if (clipUri) {
        const file = new File(clipUri);
        if (!file.size || file.size > MAX_AUDIO_BYTES) {
          setError(file.size ? 'Voice messages must be no larger than 8 MB.' : 'The recording file size could not be confirmed. Please record it again.');
          setBusy(false); return;
        }
        payload.audio = file;
        payload.audio_duration = Math.min(MAX_AUDIO_SECONDS, clipDuration);
      }
      await sendMobileMessage(otherId, payload);
      setBody(''); setClipUri(null); setClipDuration(0); setPermissionMessage('');
      await queryClient.invalidateQueries({ queryKey: getGetMobileMessagesQueryKey(otherId) });
      await query.refetch();
      inputRef.current?.focus();
    } catch (e) {
      handleUnauthorizedError(e);
      setError((e as { message?: string }).message ?? 'Your message could not be sent. Please try again.');
    } finally { setBusy(false); }
  };

  const beginRecording = async () => {
    setPermissionMessage(''); setError('');
    try {
      const permission = await requestRecordingPermissionsAsync();
      if (!permission.granted) {
        setPermissionBlocked(!permission.canAskAgain);
        setPermissionMessage(permission.canAskAgain
          ? 'Microphone permission was not granted. Allow access to record a voice message.'
          : 'Microphone permission is blocked in settings.');
        return;
      }
      setPermissionBlocked(false);
      if (clipUri) { try { new File(clipUri).delete(); } catch { /* old recording cleanup */ } }
      setClipUri(null); setClipDuration(0);
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
      setRecording(true);
    } catch (e) { setError((e as { message?: string }).message ?? 'The microphone could not start recording.'); }
  };
  const cancelClip = () => {
    if (recording) void stopRecorder();
    if (clipUri) { try { new File(clipUri).delete(); } catch { /* temporary file cleanup */ } }
    setClipUri(null); setClipDuration(0); setPermissionMessage('Voice recording cancelled.');
    localPlayer.pause();
  };
  const previewClip = () => {
    if (!clipUri) return;
    localPlayer.replace({ uri: clipUri });
    localPlayer.play();
  };
  const playMessage = async (message: Message) => {
    setError('');
    if (Platform.OS === 'web') {
      try {
        const blob = await getMobileVoice(message.id);
        const url = URL.createObjectURL(blob);
        if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
        previewUrlRef.current = url; setWebPlaybackUrl(url);
        localPlayer.replace(url); localPlayer.play();
      } catch (e) { handleUnauthorizedError(e); setError((e as { message?: string }).message ?? 'Private voice message could not be loaded.'); }
    } else {
      if (!auth.token) return;
      const absoluteUrl = `https://${process.env.EXPO_PUBLIC_DOMAIN}${getGetMobileVoiceUrl(message.id)}`;
      localPlayer.replace({ uri: absoluteUrl, headers: { Authorization: `Bearer ${auth.token}` } });
      localPlayer.play();
    }
  };

  if (!Number.isInteger(otherId) || otherId <= 0) return <Screen><ErrorNotice message="This conversation address is invalid." /></Screen>;
  return <Screen>
    <AuthGate>
      <KeyboardAvoidingView style={styles.keyboard} behavior="padding" keyboardVerticalOffset={0}>
        <View style={[styles.header, { paddingTop: headerTop + 8, backgroundColor: colors.background, borderColor: colors.border }]}>
          <TextButton title="Back" onPress={() => router.back()} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>{personName}</Text>
            <Text style={[styles.headerDetail, { color: colors.mutedForeground }]}>Private conversation</Text>
          </View>
        </View>
        {query.isError ? <ErrorNotice message="Messages could not be loaded." retry={() => void query.refetch()} /> : null}
        {query.isLoading && !query.data ? <View style={{ padding: 15 }}><Text style={[styles.headerDetail, { color: colors.mutedForeground }]}>Loading messages…</Text></View> : null}
        <FlatList
          inverted
          data={data}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => <MessageBubble message={item} mine={item.sender_id === auth.user?.id} onPlay={playMessage} />}
          contentContainerStyle={styles.listContent}
          keyboardDismissMode="interactive"
          keyboardShouldPersistTaps="handled"
          ListEmptyComponent={<Text style={[styles.empty, { color: colors.mutedForeground }]}>No messages yet. Say hello when you are ready.</Text>}
        />
        {permissionMessage ? <Text accessibilityRole="alert" style={[styles.status, { color: colors.primary }]}>{permissionMessage}</Text> : null}
        {permissionBlocked ? <PrimaryButton title="Open microphone settings" secondary onPress={() => { if (Platform.OS !== 'web') void Linking.openSettings().catch(() => undefined); }} /> : null}
        {error ? <ErrorNotice message={error} /> : null}
        {clipUri ? <View style={[styles.clip, { borderColor: colors.border, backgroundColor: colors.secondary }]}>
          <Text style={[styles.status, { color: colors.foreground }]}>Voice message preview · {Math.round(clipDuration)} seconds</Text>
          <View style={styles.clipButtons}>
            <PrimaryButton title="Play preview" secondary onPress={previewClip} />
            <PrimaryButton title="Record again" secondary onPress={() => void beginRecording()} />
            <PrimaryButton title="Cancel recording" danger onPress={cancelClip} />
          </View>
        </View> : null}
        <View style={[styles.composer, { borderColor: colors.border, backgroundColor: colors.card, paddingBottom: Math.max(insets.bottom, Platform.OS === 'web' ? 34 : 8) }]}>
          <TextInput ref={inputRef} accessibilityLabel="Write a message" placeholder="Write a message…" placeholderTextColor={colors.mutedForeground}
            value={body} onChangeText={setBody} maxLength={2000} multiline style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]} />
          <View style={styles.composerButtons}>
            {recording ? <PrimaryButton title={`Stop recording · ${Math.floor(recordingState.durationMillis / 1000)}s`} danger onPress={() => void finishRecording()} /> :
              <PrimaryButton title="Record voice message" secondary onPress={() => void beginRecording()} />}
            <PrimaryButton title={busy ? 'Sending…' : 'Send message'} onPress={() => void send()} disabled={busy || recording} testID="send-message" />
          </View>
        </View>
      </KeyboardAvoidingView>
    </AuthGate>
  </Screen>;
}

function MessageBubble({ message, mine, onPlay }: { message: Message; mine: boolean; onPlay: (message: Message) => void }) {
  const colors = useColors();
  return <View style={[styles.bubbleRow, mine ? styles.right : styles.left]}>
    <View style={[styles.bubble, { backgroundColor: mine ? colors.primary : colors.card, borderColor: colors.border }]}>
      {!mine ? <Text style={[styles.sender, { color: colors.primary }]}>{message.sender_name}</Text> : null}
      {message.body ? <Text style={[styles.messageText, { color: mine ? colors.primaryForeground : colors.foreground }]}>{message.body}</Text> : null}
      {message.audio_url ? <PrimaryButton title={`Play voice message${message.audio_duration ? ` · ${Math.round(message.audio_duration)} seconds` : ''}`} secondary={!mine} onPress={() => onPlay(message)} /> : null}
      <Text style={[styles.time, { color: mine ? colors.primaryForeground : colors.mutedForeground }]}>{new Date(message.created_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</Text>
    </View>
  </View>;
}

const styles = StyleSheet.create({
  keyboard: { flex: 1 },
  header: { flexDirection: 'row', gap: 12, alignItems: 'center', paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  headerTitle: { fontFamily: 'Poppins_600SemiBold', fontSize: 17 },
  headerDetail: { fontFamily: 'Poppins_400Regular', fontSize: 11 },
  listContent: { paddingHorizontal: 14, paddingVertical: 12, flexGrow: 1, justifyContent: 'flex-end' },
  empty: { fontFamily: 'Poppins_400Regular', textAlign: 'center', fontSize: 13, padding: 20 },
  bubbleRow: { width: '100%', flexDirection: 'row', marginVertical: 4 },
  left: { justifyContent: 'flex-start' },
  right: { justifyContent: 'flex-end' },
  bubble: { maxWidth: '86%', minWidth: 100, borderWidth: 1, borderRadius: 14, padding: 11 },
  sender: { fontFamily: 'Poppins_600SemiBold', fontSize: 11, marginBottom: 3 },
  messageText: { fontFamily: 'Poppins_400Regular', fontSize: 14, lineHeight: 21 },
  time: { fontFamily: 'Poppins_400Regular', fontSize: 10, alignSelf: 'flex-end', marginTop: 5 },
  status: { fontFamily: 'Poppins_500Medium', fontSize: 12, paddingHorizontal: 14, paddingVertical: 5 },
  composer: { borderTopWidth: 1, padding: 11 },
  input: { minHeight: 44, maxHeight: 110, borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 9, fontFamily: 'Poppins_400Regular', fontSize: 14 },
  composerButtons: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'space-between', marginTop: 5 },
  clip: { borderTopWidth: 1, padding: 10 },
  clipButtons: { flexDirection: 'row', flexWrap: 'wrap', gap: 5 },
});
