import React, { useEffect } from 'react';
import { MutationCache, QueryCache, QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import {
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
  useFonts,
} from '@expo-google-fonts/poppins';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { setAuthTokenGetter, setBaseUrl } from '@workspace/api-client-react';
import { AuthProvider, clearUnauthorizedSession, getSavedToken } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

// Keep the API origin explicit: an Expo preview domain serves the JS bundle,
// while the main development domain routes /api/mobile/ to Django.
setBaseUrl(
  process.env.EXPO_PUBLIC_API_BASE_URL ||
    `https://${process.env.EXPO_PUBLIC_DOMAIN}`,
);
setAuthTokenGetter(getSavedToken);

function isUnauthorized(error: unknown): boolean {
  return (error as { status?: number } | null)?.status === 401;
}

const queryClient = new QueryClient({
  queryCache: new QueryCache({ onError: (error) => { if (isUnauthorized(error)) void clearUnauthorizedSession(); } }),
  mutationCache: new MutationCache({ onError: (error) => { if (isUnauthorized(error)) void clearUnauthorizedSession(); } }),
  defaultOptions: { queries: { retry: 1, staleTime: 15_000, refetchOnWindowFocus: true } },
});

function RootLayoutNav() {
  const colors = useColors();
  return (
    <Stack screenOptions={{ headerBackTitle: 'Back', contentStyle: { backgroundColor: colors.background }, headerTintColor: colors.primary, headerStyle: { backgroundColor: colors.background }, headerTitleStyle: { fontFamily: 'Poppins_600SemiBold' } }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="mechanic/[id]" options={{ title: 'Mechanic profile' }} />
      <Stack.Screen name="request/new" options={{ title: 'Request roadside help' }} />
      <Stack.Screen name="request/[id]" options={{ title: 'Repair request' }} />
      <Stack.Screen name="chat/[otherId]" options={{ title: 'Messages', headerShown: false }} />
      <Stack.Screen name="setup" options={{ title: 'Finish account setup', presentation: 'modal' }} />
      <Stack.Screen name="notifications" options={{ title: 'Notifications' }} />
      <Stack.Screen name="verification" options={{ title: 'Mechanic verification' }} />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView>
            <KeyboardProvider>
              <AuthProvider>
                <RootLayoutNav />
              </AuthProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
