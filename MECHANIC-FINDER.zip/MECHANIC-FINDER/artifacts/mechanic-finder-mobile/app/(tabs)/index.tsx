import React, { useState } from 'react';
import { ImageBackground, Platform, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { Card, ErrorNotice, Field, LoadingState, PrimaryButton, Screen, SectionTitle, TextButton } from '@/components/ui';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/contexts/AuthContext';
import { NearbyMechanics } from '@/components/NearbyMechanics';
import { mobileLogin, mobileSignup, useGetMobileDashboard } from '@workspace/api-client-react';
import type { LoginInput, MobileError, SignupInput } from '@workspace/api-client-react';

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const auth = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [working, setWorking] = useState(false);
  const [notice, setNotice] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [login, setLogin] = useState<LoginInput>({ username: '', password: '' });
  const [signup, setSignup] = useState<SignupInput>({
    first_name: '', last_name: '', username: '', email: '', password: '', confirm_password: '', role: 'customer',
  });

  const fieldErrorMap = (error: unknown) => {
    const apiError = error as { data?: MobileError; message?: string; status?: number; url?: string };
    const errors: Record<string, string> = {};
    Object.entries(apiError.data?.errors ?? {}).forEach(([field, messages]) => { errors[field] = messages.join(' '); });
    setFieldErrors(errors);
    if (apiError.status === 404) {
      const path = mode === 'signup' ? 'signup' : 'login';
      const expectedUrl = `${(process.env.EXPO_PUBLIC_API_BASE_URL || `https://${process.env.EXPO_PUBLIC_DOMAIN}`).replace(/\/+$/, '')}/api/mobile/${path}/`;
      const requestUrl = apiError.url || expectedUrl;
      setNotice(`HTTP 404 for ${requestUrl}. This preview's API route needs checking.`);
    } else {
      setNotice(apiError.data?.message ?? apiError.message ?? 'We could not complete that. Please try again.');
    }
  };

  const submitLogin = async () => {
    setWorking(true); setNotice(''); setFieldErrors({});
    try {
      const session = await mobileLogin(login);
      await auth.setSession(session.token, session.user);
      setLogin({ username: '', password: '' });
      setSignup({ first_name: '', last_name: '', username: '', email: '', password: '', confirm_password: '', role: 'customer' });
      setMode('login');
      router.replace(session.user.needs_setup ? '/setup' : '/(tabs)');
    } catch (error) { fieldErrorMap(error); } finally { setWorking(false); }
  };
  const submitSignup = async () => {
    setWorking(true); setNotice(''); setFieldErrors({});
    if (!signup.username?.trim() && !signup.email?.trim()) {
      setFieldErrors({ username: 'Enter a username or an email address.', email: 'Enter an email address or a username.' });
      setNotice('Add at least a username or an email address.');
      setWorking(false); return;
    }
    if (signup.password !== signup.confirm_password) {
      setFieldErrors({ confirm_password: 'Passwords do not match.' }); setNotice('Check the password confirmation.');
      setWorking(false); return;
    }
    try {
      const session = await mobileSignup(signup);
      await auth.setSession(session.token, session.user);
      setLogin({ username: '', password: '' });
      setSignup({ first_name: '', last_name: '', username: '', email: '', password: '', confirm_password: '', role: 'customer' });
      setMode('login');
      router.replace(session.user.needs_setup ? '/setup' : '/(tabs)');
    } catch (error) { fieldErrorMap(error); } finally { setWorking(false); }
  };

  const contentTop = Platform.OS === 'web' ? 67 : insets.top;
  return <Screen>
    <KeyboardAwareScrollViewCompat contentContainerStyle={{ paddingHorizontal: 18, paddingTop: contentTop + 10, paddingBottom: 120 }} bottomOffset={24}>
      <ImageBackground source={require('../../assets/images/hero.jpg')} imageStyle={styles.heroImage} style={[styles.hero, { backgroundColor: colors.secondary }]}>
        <View style={[styles.heroWash, { backgroundColor: colors.primary + 'D9' }]}>
          <Text style={[styles.brand, { color: colors.primaryForeground }]}>Mechanic Finder -Ghana</Text>
          <Text style={[styles.heroTitle, { color: colors.primaryForeground }]}>Help is closer than you think.</Text>
          <Text style={[styles.heroIntro, { color: colors.primaryForeground }]}>Find a mechanic, request roadside help, and follow your repair in one place.</Text>
          <PrimaryButton title="Find a mechanic" onPress={() => router.push('/(tabs)/find')} secondary />
        </View>
      </ImageBackground>

      {auth.validating ? <LoadingState label="Checking your account" /> : null}
      {auth.validationError ? <ErrorNotice message={auth.validationError} retry={() => void auth.validateSession()} /> : null}
      {auth.user ? (
        <>
          <SectionTitle>{`Welcome, ${auth.user.name}`}</SectionTitle>
          {auth.user.needs_setup || !auth.user.role ? <Card>
            <Text style={[styles.body, { color: colors.foreground }]}>Choose how you use Mechanic Finder so we can set up your account.</Text>
            <PrimaryButton title="Finish account setup" onPress={() => router.push('/setup')} />
          </Card> : <>
            {auth.user.role === 'customer' ? <NearbyMechanics key={auth.user.id} customerId={auth.user.id} /> : null}
            <Dashboard />
          </>}
          {auth.user.role === 'customer' ? <PrimaryButton title="Request roadside help" onPress={() => router.push('/request/new')} /> : null}
        </>
      ) : auth.ready && !auth.validating ? (
        <Card style={{ padding: 16 }}>
          <Text style={[styles.authTitle, { color: colors.foreground }]}>{mode === 'login' ? 'Welcome back' : 'Create your account'}</Text>
          <Text style={[styles.detail, { color: colors.mutedForeground }]}>
            {mode === 'login' ? 'Sign in with your username or email.' : 'Use your existing Mechanic Finder identity.'}
          </Text>
          {notice ? <Text accessibilityRole="alert" style={{ color: colors.destructive, fontFamily: 'Poppins_500Medium', marginTop: 8 }}>{notice}</Text> : null}
          {mode === 'login' ? <>
            <Field label="Username or email" value={login.username} autoCapitalize="none" autoCorrect={false} onChangeText={(username) => setLogin({ ...login, username })} error={fieldErrors.username} returnKeyType="next" />
            <Field label="Password" value={login.password} secureTextEntry onChangeText={(password) => setLogin({ ...login, password })} error={fieldErrors.password} onSubmitEditing={() => void submitLogin()} />
            <PrimaryButton title={working ? 'Signing in…' : 'Sign in'} onPress={() => void submitLogin()} disabled={working} testID="login-submit" />
          </> : <>
            <Field label="First name" value={signup.first_name} onChangeText={(first_name) => setSignup({ ...signup, first_name })} error={fieldErrors.first_name} />
            <Field label="Last name" value={signup.last_name} onChangeText={(last_name) => setSignup({ ...signup, last_name })} error={fieldErrors.last_name} />
            <Field label="Username (optional)" value={signup.username} autoCapitalize="none" onChangeText={(username) => setSignup({ ...signup, username })} error={fieldErrors.username} />
            <Field label="Email address (optional)" value={signup.email} autoCapitalize="none" keyboardType="email-address" onChangeText={(email) => setSignup({ ...signup, email })} error={fieldErrors.email} />
            <Text style={[styles.label, { color: colors.foreground }]}>I need an account as</Text>
            <View style={styles.roles}>
              {(['customer', 'mechanic'] as const).map((role) => <View key={role} style={{ flex: 1 }}>
                <PrimaryButton title={role === 'customer' ? 'Customer' : 'Mechanic'} secondary={signup.role !== role} onPress={() => setSignup({ ...signup, role })} />
              </View>)}
            </View>
            <Field label="Password" value={signup.password} secureTextEntry onChangeText={(password) => setSignup({ ...signup, password })} error={fieldErrors.password} />
            <Field label="Confirm password" value={signup.confirm_password} secureTextEntry onChangeText={(confirm_password) => setSignup({ ...signup, confirm_password })} error={fieldErrors.confirm_password} />
            <PrimaryButton title={working ? 'Creating account…' : 'Create account'} onPress={() => void submitSignup()} disabled={working} testID="signup-submit" />
          </>}
          <View style={styles.switchAuth}>
            <Text style={[styles.detail, { color: colors.mutedForeground }]}>{mode === 'login' ? 'New to Mechanic Finder?' : 'Already have an account?'}</Text>
            <TextButton title={mode === 'login' ? 'Create account' : 'Sign in'} onPress={() => { setMode(mode === 'login' ? 'signup' : 'login'); setNotice(''); setFieldErrors({}); }} />
          </View>
          <Text style={[styles.finePrint, { color: colors.mutedForeground }]}>Need account recovery? Contact support through the website. Email recovery is not available from this app.</Text>
        </Card>
      ) : null}

      <SectionTitle>Browse the service</SectionTitle>
      <Card>
        <Text style={[styles.body, { color: colors.foreground }]}>Search public mechanic profiles by name, service area, or repair specialty. Directory results do not reveal private GPS locations.</Text>
        <PrimaryButton title="Browse mechanics" onPress={() => router.push('/(tabs)/find')} secondary />
        {auth.user?.role === 'customer' ? <PrimaryButton title="Create a roadside request" onPress={() => router.push('/request/new')} /> : null}
      </Card>
      <Text style={[styles.finePrint, { color: colors.mutedForeground }]}>Mechanic Finder helps connect customers and mechanics in Ghana. Keep repair discussions in your private conversation.</Text>
    </KeyboardAwareScrollViewCompat>
  </Screen>;
}

function Dashboard() {
  const colors = useColors();
  const auth = useAuth();
  const query = useGetMobileDashboard({ query: { enabled: Boolean(auth.user) } });
  const requests = query.data?.requests ?? [];
  const nearby = query.data?.nearby ?? [];
  if (query.isLoading) return <LoadingState label="Loading your dashboard" />;
  if (query.isError) return <ErrorNotice message="Could not load your requests." retry={() => void query.refetch()} />;
  return <>
    <SectionTitle>{auth.user?.role === 'mechanic' ? 'Available requests' : 'Your repair requests'}</SectionTitle>
    {auth.user?.role === 'mechanic' && nearby.length ? nearby.map((job) => <Card key={`near-${job.id}`}>
      <Text style={[styles.cardTitle, { color: colors.foreground }]}>{job.vehicle_problem}</Text>
      <Text style={[styles.detail, { color: colors.mutedForeground }]}>{job.location} · {job.customer.name}</Text>
      <PrimaryButton title="View request" secondary onPress={() => router.push(`/request/${job.id}`)} />
    </Card>) : null}
    {requests.length ? requests.map((job) => <Card key={job.id}>
      <Text style={[styles.cardTitle, { color: colors.foreground }]}>{job.vehicle_problem}</Text>
      <Text style={[styles.detail, { color: colors.mutedForeground }]}>{job.status.replaceAll('_', ' ')} · {job.location}</Text>
      <PrimaryButton title="Open repair" secondary onPress={() => router.push(`/request/${job.id}`)} />
    </Card>) : <Card><Text style={[styles.body, { color: colors.mutedForeground }]}>Your repair history will appear here when you create or accept a request.</Text></Card>}
    {auth.user?.role === 'mechanic' ? <TextButton title="See all nearby work" onPress={() => router.push('/(tabs)/find')} /> : null}
    {query.isFetching ? <LoadingState label="Refreshing dashboard" /> : null}
  </>;
}

const styles = StyleSheet.create({
  hero: { minHeight: 270, borderRadius: 16, overflow: 'hidden', marginBottom: 18, justifyContent: 'flex-end' },
  heroImage: { borderRadius: 16 },
  heroWash: { padding: 20, minHeight: 270, justifyContent: 'flex-end' },
  brand: { fontFamily: 'Poppins_600SemiBold', fontSize: 14, marginBottom: 10 },
  heroTitle: { fontFamily: 'Poppins_700Bold', fontSize: 29, lineHeight: 36 },
  heroIntro: { fontFamily: 'Poppins_400Regular', fontSize: 14, lineHeight: 22, marginTop: 7, marginBottom: 8 },
  authTitle: { fontFamily: 'Poppins_700Bold', fontSize: 22 },
  detail: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 20 },
  body: { fontFamily: 'Poppins_400Regular', fontSize: 14, lineHeight: 22 },
  label: { fontFamily: 'Poppins_500Medium', fontSize: 13, marginTop: 3 },
  roles: { flexDirection: 'row', gap: 8 },
  switchAuth: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 8, marginTop: 4 },
  finePrint: { fontFamily: 'Poppins_400Regular', fontSize: 11, lineHeight: 17, marginTop: 10, marginBottom: 12 },
  cardTitle: { fontFamily: 'Poppins_600SemiBold', fontSize: 16 },
});
