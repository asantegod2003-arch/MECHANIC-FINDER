import React from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useGetMobileConversations } from '@workspace/api-client-react';
import { AuthGate } from '@/components/AuthGate';
import { Card, ErrorNotice, LoadingState, PrimaryButton, Screen, SectionTitle } from '@/components/ui';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/contexts/AuthContext';

export default function MessagesScreen() {
  const colors = useColors();
  const auth = useAuth();
  const insets = useSafeAreaInsets();
  const query = useGetMobileConversations({ query: { enabled: auth.isAuthenticated, refetchInterval: 30_000 } });
  const top = Platform.OS === 'web' ? 67 : insets.top;
  return <Screen>
    <ScrollView contentContainerStyle={{ paddingTop: top + 16, paddingHorizontal: 18, paddingBottom: 120 }}>
      <SectionTitle detail="Private conversations with customers and mechanics.">Messages</SectionTitle>
      <AuthGate>
        <PrimaryButton title="View notifications" secondary onPress={() => router.push('/notifications')} />
        {query.isLoading ? <LoadingState label="Loading your conversations" /> : null}
        {query.isError ? <ErrorNotice message="Your conversations could not be loaded." retry={() => void query.refetch()} /> : null}
        {query.data?.length === 0 ? <Card><Text style={[styles.body, { color: colors.mutedForeground }]}>No conversations yet. When you connect with a mechanic or customer, your messages will appear here.</Text></Card> : null}
        {query.data?.map((conversation) => {
          const person = conversation.other_person;
          const latest = conversation.latest_message;
          return <Pressable key={person.id} accessibilityRole="button" accessibilityLabel={`Open conversation with ${person.name}`}
            onPress={() => {
              auth.noteExplicitAction();
              router.push({ pathname: '/chat/[otherId]', params: { otherId: String(person.id), name: person.name } });
            }}
            style={({ pressed }) => [styles.item, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.82 : 1 }]}>
            <View style={[styles.avatar, { backgroundColor: colors.secondary }]}><Text style={[styles.initial, { color: colors.primary }]}>{person.name.slice(0, 1).toUpperCase()}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.name, { color: colors.foreground }]}>{person.name}</Text>
              <Text numberOfLines={2} style={[styles.body, { color: colors.mutedForeground }]}>{latest?.audio_url ? 'Voice message' : latest?.body || 'Conversation started'}</Text>
            </View>
            <Text style={[styles.date, { color: colors.mutedForeground }]}>{new Date(conversation.updated_at).toLocaleDateString()}</Text>
          </Pressable>;
        })}
      </AuthGate>
    </ScrollView>
  </Screen>;
}

const styles = StyleSheet.create({
  item: { flexDirection: 'row', gap: 12, alignItems: 'center', padding: 14, borderWidth: 1, borderRadius: 12, marginVertical: 5 },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  initial: { fontFamily: 'Poppins_700Bold', fontSize: 17 },
  name: { fontFamily: 'Poppins_600SemiBold', fontSize: 15 },
  body: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 19, marginTop: 3 },
  date: { fontFamily: 'Poppins_400Regular', fontSize: 10, alignSelf: 'flex-start' },
});
