import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { Tabs } from 'expo-router';
import { NativeTabs } from 'expo-router/native-tabs';
import { isLiquidGlassAvailable } from 'expo-glass-effect';
import { BlurView } from 'expo-blur';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

function GlassTabs() {
  return <NativeTabs>
    <NativeTabs.Trigger name="index">
      <NativeTabs.Trigger.Icon sf={{ default: 'house', selected: 'house.fill' }} md="home" />
      <NativeTabs.Trigger.Label>Home</NativeTabs.Trigger.Label>
    </NativeTabs.Trigger>
    <NativeTabs.Trigger name="find">
      <NativeTabs.Trigger.Icon sf={{ default: 'magnifyingglass', selected: 'magnifyingglass' }} md="search" />
      <NativeTabs.Trigger.Label>Find</NativeTabs.Trigger.Label>
    </NativeTabs.Trigger>
    <NativeTabs.Trigger name="messages">
      <NativeTabs.Trigger.Icon sf={{ default: 'bubble.left.and.bubble.right', selected: 'bubble.left.and.bubble.right.fill' }} md="chat" />
      <NativeTabs.Trigger.Label>Messages</NativeTabs.Trigger.Label>
    </NativeTabs.Trigger>
    <NativeTabs.Trigger name="account">
      <NativeTabs.Trigger.Icon sf={{ default: 'person.crop.circle', selected: 'person.crop.circle.fill' }} md="account_circle" />
      <NativeTabs.Trigger.Label>Account</NativeTabs.Trigger.Label>
    </NativeTabs.Trigger>
  </NativeTabs>;
}

function ClassicTabs() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isIOS = Platform.OS === 'ios';
  const isWeb = Platform.OS === 'web';
  return <Tabs screenOptions={{
    headerShown: false,
    tabBarActiveTintColor: colors.primary,
    tabBarInactiveTintColor: colors.mutedForeground,
    tabBarLabelStyle: { fontFamily: 'Poppins_500Medium', fontSize: 11, marginTop: 2 },
    tabBarStyle: {
      position: 'absolute',
      backgroundColor: isIOS ? 'transparent' : colors.card,
      borderTopWidth: 1,
      borderTopColor: colors.border,
      elevation: 0,
      paddingBottom: isWeb ? 0 : insets.bottom,
      height: isWeb ? 84 : 58 + insets.bottom,
    },
    tabBarBackground: () => isIOS
      ? <BlurView intensity={90} tint="light" style={StyleSheet.absoluteFill} />
      : isWeb ? <View style={[StyleSheet.absoluteFill, { backgroundColor: colors.card }]} /> : null,
  }}>
    <Tabs.Screen name="index" options={{ title: 'Home', tabBarIcon: ({ color, size }) => <Feather name="home" size={size} color={(color ?? colors.primary) as string} /> }} />
    <Tabs.Screen name="find" options={{ title: 'Find', tabBarIcon: ({ color, size }) => <Feather name="search" size={size} color={(color ?? colors.primary) as string} /> }} />
    <Tabs.Screen name="messages" options={{ title: 'Messages', tabBarIcon: ({ color, size }) => <Feather name="message-circle" size={size} color={(color ?? colors.primary) as string} /> }} />
    <Tabs.Screen name="account" options={{ title: 'Account', tabBarIcon: ({ color, size }) => <Feather name="user" size={size} color={(color ?? colors.primary) as string} /> }} />
  </Tabs>;
}

export default function TabsLayout() {
  return Platform.OS === 'ios' && isLiquidGlassAvailable() ? <GlassTabs /> : <ClassicTabs />;
}
