import React, { useMemo, useState } from 'react';
import { FlatList, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useGetMobileMechanics } from '@workspace/api-client-react';
import type { GetMobileMechanicsParams, Mechanic } from '@workspace/api-client-react';
import { Screen, Field, Card, ErrorNotice, LoadingState, PrimaryButton, SectionTitle, TextButton } from '@/components/ui';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/contexts/AuthContext';

export default function FindScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const auth = useAuth();
  const [q, setQ] = useState('');
  const [area, setArea] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [filters, setFilters] = useState<GetMobileMechanicsParams>({});
  const query = useGetMobileMechanics(filters, { query: { retry: 1 } });
  const top = Platform.OS === 'web' ? 67 : insets.top;
  const apply = () => {
    auth.noteExplicitAction();
    setFilters({ q: q.trim() || undefined, area: area.trim() || undefined, specialty: specialty.trim() || undefined });
  };
  return <Screen>
    <KeyboardAwareScrollViewCompat contentContainerStyle={{ paddingTop: top + 12, paddingHorizontal: 18, paddingBottom: 120 }}>
      <SectionTitle detail="Find a public profile by name, neighbourhood, or repair skill.">Find a mechanic</SectionTitle>
      <Card>
        <Field label="Mechanic name" value={q} onChangeText={setQ} returnKeyType="search" onSubmitEditing={apply} />
        <Field label="Service area" value={area} onChangeText={setArea} returnKeyType="search" onSubmitEditing={apply} />
        <Field label="Repair specialty" value={specialty} onChangeText={setSpecialty} returnKeyType="search" onSubmitEditing={apply} />
        <PrimaryButton title="Search mechanics" onPress={apply} testID="directory-search" />
        {(filters.q || filters.area || filters.specialty) ? <TextButton title="Clear all filters" onPress={() => { setQ(''); setArea(''); setSpecialty(''); setFilters({}); }} /> : null}
      </Card>
      {query.isLoading ? <LoadingState label="Searching public mechanic profiles" /> : null}
      {query.isError ? <ErrorNotice message="Mechanic profiles could not be loaded." retry={() => void query.refetch()} /> : null}
      {query.data?.length === 0 ? <Card><Text style={[styles.body, { color: colors.mutedForeground }]}>No public profiles match those filters. Try a different area or specialty.</Text></Card> : null}
      {query.data?.map((mechanic) => <MechanicRow key={mechanic.id} mechanic={mechanic} onOpen={() => {
        auth.noteExplicitAction();
        router.push({ pathname: '/mechanic/[id]', params: { id: String(mechanic.id) } });
      }} />)}
    </KeyboardAwareScrollViewCompat>
  </Screen>;
}

function MechanicRow({ mechanic, onOpen }: { mechanic: Mechanic; onOpen: () => void }) {
  const colors = useColors();
  return <Pressable accessibilityRole="button" accessibilityLabel={`View ${mechanic.name}'s mechanic profile`} onPress={onOpen}
    style={({ pressed }) => [styles.row, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.8 : 1 }]}>
    <View style={[styles.avatar, { backgroundColor: colors.secondary }]}><Text style={[styles.initial, { color: colors.primary }]}>{mechanic.name.slice(0, 1).toUpperCase()}</Text></View>
    <View style={styles.rowInfo}>
      <Text style={[styles.name, { color: colors.foreground }]}>{mechanic.name}</Text>
      <Text style={[styles.body, { color: colors.mutedForeground }]}>{mechanic.service_area || 'Service area not listed'}</Text>
      <Text style={[styles.body, { color: colors.mutedForeground }]}>{mechanic.repair_specialties || 'Specialties not listed'}</Text>
      <Text style={[styles.meta, { color: colors.primary }]}>
        {mechanic.verified ? 'Verified mechanic' : 'Profile not yet verified'}
        {'  ·  '}{mechanic.average_rating == null ? 'No ratings yet' : `${mechanic.average_rating.toFixed(1)} rating (${mechanic.review_count} reviews)`}
        {'  ·  '}{mechanic.available ? 'Available' : 'Not available'}
      </Text>
    </View>
  </Pressable>;
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', borderWidth: 1, borderRadius: 12, padding: 14, marginVertical: 6, alignItems: 'flex-start', gap: 12 },
  avatar: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  initial: { fontFamily: 'Poppins_700Bold', fontSize: 17 },
  rowInfo: { flex: 1 },
  name: { fontFamily: 'Poppins_600SemiBold', fontSize: 16 },
  body: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 20, marginTop: 3 },
  meta: { fontFamily: 'Poppins_500Medium', fontSize: 11, lineHeight: 17, marginTop: 5 },
});
