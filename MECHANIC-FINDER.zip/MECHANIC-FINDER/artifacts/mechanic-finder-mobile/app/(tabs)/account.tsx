import React, { useState } from 'react';
import { Linking, Platform, ScrollView, StyleSheet, Switch, Text } from 'react-native';
import { router } from 'expo-router';
import * as Location from 'expo-location';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { requestMobileAccountDeletion, updateMobileProfile } from '@workspace/api-client-react';
import type { ProfileInput } from '@workspace/api-client-react';
import { AuthGate } from '@/components/AuthGate';
import { Card, ErrorNotice, Field, PrimaryButton, Screen, SectionTitle, TextButton } from '@/components/ui';
import { getSavedToken, handleUnauthorizedError, useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function AccountScreen() {
  const auth = useAuth();
  // Tab screens stay mounted. Scope private drafts and confirmations to the
  // signed-in identity so another login never inherits the previous account.
  return <AccountForm key={auth.user?.id ?? 'signed-out'} />;
}

function AccountForm() {
  const colors = useColors();
  const auth = useAuth();
  const insets = useSafeAreaInsets();
  const [serviceArea, setServiceArea] = useState<string | null>(null);
  const [specialties, setSpecialties] = useState<string | null>(null);
  const [deletePassword, setDeletePassword] = useState('');
  const [deleteConfirmed, setDeleteConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [locationMessage, setLocationMessage] = useState('');
  const [confirmLogout, setConfirmLogout] = useState(false);
  const top = Platform.OS === 'web' ? 67 : insets.top;

  const requestPosition = async () => {
    setLocationMessage('');
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (!permission.granted) {
        setLocationMessage(permission.canAskAgain ? 'Location access was not allowed. Allow it to share your actual mechanic position.' : 'Location access is blocked. Open device settings to allow location.');
        return null;
      }
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      return { latitude: position.coords.latitude, longitude: position.coords.longitude };
    } catch {
      setLocationMessage('Your device could not provide a current position. Try again when location services are available.');
      return null;
    }
  };

  const saveProfile = async (input: ProfileInput) => {
    auth.noteExplicitAction(); setBusy(true); setError(''); setMessage('');
    try {
      const updated = await updateMobileProfile(input);
      auth.updateUser(updated);
      setServiceArea(updated.service_area); setSpecialties(updated.repair_specialties);
      setMessage('Your profile has been updated.');
      return true;
    } catch (e) {
      handleUnauthorizedError(e);
      setError((e as { message?: string }).message ?? 'Profile could not be updated.');
      return false;
    } finally { setBusy(false); }
  };

  const toggleAvailable = async (available: boolean) => {
    if (!auth.user || auth.user.role !== 'mechanic') return;
    if (available) {
      const current = await requestPosition();
      if (!current) return;
      await saveProfile({ available: true, latitude: current.latitude, longitude: current.longitude });
    } else {
      await saveProfile({ available: false });
    }
  };
  const refreshNearbyLocation = async () => {
    if (!auth.user?.available || auth.user.role !== 'mechanic') return;
    const session = auth.token;
    const current = await requestPosition();
    if (!current || !session) return;
    // A permission prompt can finish after logout or an account switch.
    const activeToken = await getSavedToken().catch(() => null);
    if (activeToken !== session) return;
    if (await saveProfile({ latitude: current.latitude, longitude: current.longitude })) {
      setMessage('Location updated. Nearby customers can find your approximate distance for the next 10 minutes.');
    }
  };

  const deleteRequest = async () => {
    if (!deleteConfirmed) { setDeleteConfirmed(true); return; }
    if (!deletePassword) { setError('Enter your password to request account deletion.'); return; }
    setBusy(true); setError(''); setMessage('');
    try {
      const result = await requestMobileAccountDeletion({ password: deletePassword, confirm: true });
      setMessage(`${result.message} This request is processed manually by an administrator; your account has not been erased or disabled.`);
      setDeletePassword('');
      setDeleteConfirmed(false);
    } catch (e) {
      handleUnauthorizedError(e);
      setError((e as { message?: string }).message ?? 'The deletion request could not be submitted.');
    } finally { setBusy(false); }
  };

  return <Screen>
    <ScrollView contentContainerStyle={{ paddingTop: top + 16, paddingHorizontal: 18, paddingBottom: 120 }}>
      <SectionTitle detail="Your profile, availability, and account controls.">Account</SectionTitle>
      <AuthGate>
        {auth.user ? <>
          <Card>
            <Text style={[styles.name, { color: colors.foreground }]}>{auth.user.name}</Text>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>Username: {auth.user.username}</Text>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>Email: {auth.user.email || 'No email address on this account'}</Text>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>Account role: {auth.user.role ?? 'Not set up yet'}</Text>
          </Card>
          {auth.user.needs_setup || !auth.user.role ? <Card>
            <Text style={[styles.body, { color: colors.foreground }]}>Choose a customer or mechanic role to finish your account setup. Existing messages remain available.</Text>
            <PrimaryButton title="Finish account setup" onPress={() => router.push('/setup')} />
          </Card> : null}
          {auth.user.role === 'mechanic' ? <>
            <Card>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>Public mechanic profile</Text>
              <Text style={[styles.body, { color: colors.mutedForeground }]}>Only service area and repair specialties appear in public search. Your precise GPS is never shown in the directory.</Text>
              <Field label="Service area" value={serviceArea ?? auth.user?.service_area ?? ''} onChangeText={setServiceArea} maxLength={150} />
              <Field label="Repair specialties" value={specialties ?? auth.user?.repair_specialties ?? ''} onChangeText={setSpecialties} multiline maxLength={500} />
              <PrimaryButton title={busy ? 'Saving…' : 'Save profile'} disabled={busy} onPress={() => void saveProfile({ service_area: serviceArea ?? auth.user?.service_area ?? '', repair_specialties: specialties ?? auth.user?.repair_specialties ?? '' })} />
            </Card>
            <Card>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>Available for roadside work</Text>
              <Text style={[styles.body, { color: colors.mutedForeground }]}>Going online captures your current device GPS for dispatch. Customers nearby see an approximate distance, never your exact coordinates. Your nearby listing needs a location update at least every 10 minutes while you are online. This does not move any saved repair pin.</Text>
              <Switch accessibilityLabel="Available for roadside work" value={auth.user.available} onValueChange={(v) => void toggleAvailable(v)}
                trackColor={{ true: colors.primary, false: colors.border }} thumbColor={colors.cardForeground} />
              {auth.user.available ? <PrimaryButton title="Update my nearby location" secondary disabled={busy} onPress={() => void refreshNearbyLocation()} /> : null}
              {locationMessage ? <ErrorNotice message={locationMessage} /> : null}
              {locationMessage && !locationMessage.includes('could not') && Platform.OS !== 'web' ? <PrimaryButton title="Open location settings" secondary onPress={() => void Linking.openSettings().catch(() => undefined)} /> : null}
            </Card>
            <Card>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>Mechanic verification</Text>
              <Text style={[styles.body, { color: colors.mutedForeground }]}>Status: {auth.user.verified ? 'Verified' : 'Not verified'}. Applications are reviewed by an administrator.</Text>
              <PrimaryButton title="View or submit verification form" secondary onPress={() => router.push('/verification')} />
            </Card>
          </> : null}
          <Card>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Notifications</Text>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>View in-app updates for requests, repairs, and messages.</Text>
            <PrimaryButton title="Open notifications" secondary onPress={() => router.push('/notifications')} />
          </Card>
          {message ? <Text accessibilityRole="alert" style={[styles.success, { color: colors.primary }]}>{message}</Text> : null}
          {error ? <ErrorNotice message={error} /> : null}
          {!confirmLogout ? <PrimaryButton title="Sign out" danger onPress={() => setConfirmLogout(true)} /> : <Card>
            <Text style={[styles.body, { color: colors.foreground }]}>Sign out now? You will need to sign in again to see private account information.</Text>
            <PrimaryButton title="Confirm sign out" danger onPress={() => void auth.logout().then(() => router.replace('/(tabs)'))} />
            <PrimaryButton title="Stay signed in" secondary onPress={() => setConfirmLogout(false)} />
          </Card>}
          <Card style={{ marginTop: 18 }}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Request account deletion</Text>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>This submits a manual request for administrator processing. It does not immediately erase your data or disable your account.</Text>
            <Field label="Account password" value={deletePassword} onChangeText={setDeletePassword} secureTextEntry />
            <TextButton title={deleteConfirmed ? 'Confirmation selected' : 'I understand this is a manual request'} onPress={() => setDeleteConfirmed(!deleteConfirmed)} />
            {deleteConfirmed ? <PrimaryButton title={busy ? 'Submitting…' : 'Submit deletion request'} disabled={busy} danger onPress={() => void deleteRequest()} /> : null}
          </Card>
          <Text style={[styles.finePrint, { color: colors.mutedForeground }]}>Password recovery email delivery is not configured in this app. No privacy or terms links are provided because no verified mobile policy URLs were supplied.</Text>
        </> : null}
      </AuthGate>
    </ScrollView>
  </Screen>;
}

const styles = StyleSheet.create({
  name: { fontFamily: 'Poppins_700Bold', fontSize: 20 },
  cardTitle: { fontFamily: 'Poppins_600SemiBold', fontSize: 16 },
  body: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 21, marginTop: 4 },
  success: { fontFamily: 'Poppins_500Medium', fontSize: 13, marginVertical: 8 },
  finePrint: { fontFamily: 'Poppins_400Regular', fontSize: 11, lineHeight: 17, marginTop: 18, marginBottom: 14 },
});
