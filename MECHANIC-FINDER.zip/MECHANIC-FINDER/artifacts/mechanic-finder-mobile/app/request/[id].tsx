import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Linking, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import { useQueryClient } from '@tanstack/react-query';
import { actOnMobileRequest, createMobileEstimate, decideMobileEstimate, saveMobileReview, updateMobileJourney, useGetMobileRequest } from '@workspace/api-client-react';
import type { JobActionAction } from '@workspace/api-client-react';
import { AuthGate } from '@/components/AuthGate';
import MapPreview from '@/components/MapPreview';
import { Card, ErrorNotice, Field, LoadingState, PrimaryButton, Screen, SectionTitle } from '@/components/ui';
import { handleUnauthorizedError, registerForegroundStopper, useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';
import { canAcceptRequest } from '@/utils/requestActions';

type CurrentPosition = { latitude: number; longitude: number; accuracy: number | null };

export default function RequestDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const requestId = Number(id);
  const colors = useColors();
  const auth = useAuth();
  const queryClient = useQueryClient();
  const query = useGetMobileRequest(requestId, { query: { enabled: Number.isInteger(requestId) && requestId > 0 && auth.isAuthenticated, refetchInterval: 15_000 } });
  const job = query.data;
  const [actionBusy, setActionBusy] = useState(false);
  const [busyAction, setBusyAction] = useState<JobActionAction | null>(null);
  const [error, setError] = useState('');
  const [permissionMessage, setPermissionMessage] = useState('');
  const [journeyEnabled, setJourneyEnabled] = useState(false);
  const journeyRef = useRef(false);
  const journeySubscription = useRef<Location.LocationSubscription | null>(null);
  const [estimateAmount, setEstimateAmount] = useState('');
  const [estimateDescription, setEstimateDescription] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const top = Platform.OS === 'web' ? 67 : 0;
  const isCustomer = auth.user?.id === job?.customer.id;
  const isMechanic = auth.user?.id === job?.mechanic?.id;
  const canAccept = canAcceptRequest(auth.user, job);
  const latestEstimate = job?.estimates[job.estimates.length - 1];

  const turnJourneyOff = useCallback(async () => {
    if (!journeyRef.current) return;
    journeyRef.current = false;
    setJourneyEnabled(false);
    if (requestId > 0) {
      try { await updateMobileJourney(requestId, { enabled: false }); } catch { /* stopping the local GPS listener is the priority */ }
    }
  }, [requestId]);
  useEffect(() => registerForegroundStopper(() => {
    journeySubscription.current?.remove();
    journeySubscription.current = null;
    void turnJourneyOff();
  }), [turnJourneyOff]);
  useEffect(() => () => {
    journeySubscription.current?.remove();
    journeySubscription.current = null;
    void turnJourneyOff();
  }, [turnJourneyOff]);
  useEffect(() => {
    if (job && job.status !== 'on_the_way' && journeyEnabled) void turnJourneyOff();
  }, [job?.status, journeyEnabled, turnJourneyOff]);
  useEffect(() => {
    if (!journeyEnabled || job?.status !== 'on_the_way' || !isMechanic) return;
    let subscription: Location.LocationSubscription | null = null;
    let stopped = false;
    void (async () => {
      try {
        if (stopped) return;
        subscription = await Location.watchPositionAsync(
          { accuracy: Location.Accuracy.Balanced, timeInterval: 12_000, distanceInterval: 25 },
          (position) => {
            if (!stopped) void updateMobileJourney(requestId, {
              enabled: true, latitude: position.coords.latitude, longitude: position.coords.longitude,
              ...(position.coords.accuracy != null ? { accuracy: position.coords.accuracy } : {}),
            }).catch((error) => handleUnauthorizedError(error));
          },
        );
        // Backgrounding can happen while native watcher creation is pending.
        // Dispose a late subscription instead of leaving GPS active.
        if (stopped) {
          subscription.remove();
          return;
        }
        journeySubscription.current = subscription;
      } catch { setPermissionMessage('Live location sharing stopped. Check device location permissions and try again.'); void turnJourneyOff(); }
    })();
    return () => {
      stopped = true;
      subscription?.remove();
      if (journeySubscription.current === subscription) journeySubscription.current = null;
    };
  }, [journeyEnabled, job?.status, isMechanic, requestId, turnJourneyOff]);

  const refresh = async () => {
    await query.refetch();
    await queryClient.invalidateQueries();
  };
  const captureCurrent = async (): Promise<CurrentPosition | null> => {
    setPermissionMessage('');
    const permission = await Location.requestForegroundPermissionsAsync();
    if (!permission.granted) {
      setPermissionMessage(permission.canAskAgain
        ? 'Location access is needed to capture the mechanic’s real GPS position before accepting this request.'
        : 'Location access is blocked. Open device settings and allow location before accepting.');
      return null;
    }
    try {
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      return { latitude: location.coords.latitude, longitude: location.coords.longitude, accuracy: location.coords.accuracy };
    } catch {
      setPermissionMessage('The device could not get a fresh GPS fix. Turn on location services and retry.');
      return null;
    }
  };
  const runAction = async (action: JobActionAction) => {
    if (!job) return;
    if (action === 'accept' && !canAccept) return;
    setBusyAction(action); setActionBusy(true); setError(''); auth.noteExplicitAction();
    try {
      const position = action === 'accept' ? await captureCurrent() : null;
      if (action === 'accept' && !position) { setActionBusy(false); setBusyAction(null); return; }
      await actOnMobileRequest(requestId, {
        action,
        ...(position ? {
          latitude: position.latitude, longitude: position.longitude,
          ...(position.accuracy != null ? { accuracy: position.accuracy } : {}),
        } : {}),
      });
      if (action === 'arrive' || action === 'complete' || action === 'cancel') await turnJourneyOff();
      await refresh();
    } catch (e) {
      handleUnauthorizedError(e);
      setError((e as { message?: string }).message ?? `Could not ${action.replaceAll('_', ' ')} this repair request.`);
    } finally { setActionBusy(false); setBusyAction(null); }
  };
  const submitEstimate = async () => {
    const amount = estimateAmount.trim();
    if (!amount || !/^\d+(\.\d{1,2})?$/.test(amount) || Number(amount) <= 0 || !estimateDescription.trim()) {
      setError('Enter a positive GHS amount and describe the proposed repair.'); return;
    }
    setActionBusy(true); setError(''); auth.noteExplicitAction();
    try {
      await createMobileEstimate(requestId, { amount, description: estimateDescription.trim() });
      setEstimateAmount(''); setEstimateDescription(''); await refresh();
    } catch (e) { handleUnauthorizedError(e); setError((e as { message?: string }).message ?? 'The estimate could not be sent.'); }
    finally { setActionBusy(false); }
  };
  const decision = async (value: 'accept' | 'decline') => {
    if (!latestEstimate) return;
    setActionBusy(true); setError(''); auth.noteExplicitAction();
    try { await decideMobileEstimate(latestEstimate.id, { decision: value }); await refresh(); }
    catch (e) { handleUnauthorizedError(e); setError((e as { message?: string }).message ?? 'The estimate decision could not be saved.'); }
    finally { setActionBusy(false); }
  };
  const submitReview = async () => {
    setActionBusy(true); setError(''); auth.noteExplicitAction();
    try {
      await saveMobileReview(requestId, { rating: reviewRating, comment: reviewComment.trim() });
      await refresh();
    } catch (e) { handleUnauthorizedError(e); setError((e as { message?: string }).message ?? 'Your review could not be saved.'); }
    finally { setActionBusy(false); }
  };
  const enableJourney = async () => {
    if (!job || job.status !== 'on_the_way' || !isMechanic) return;
    setActionBusy(true); setError('');
    const position = await captureCurrent();
    if (!position) { setActionBusy(false); return; }
    try {
      await updateMobileJourney(requestId, {
        enabled: true, latitude: position.latitude, longitude: position.longitude,
        ...(position.accuracy != null ? { accuracy: position.accuracy } : {}),
      });
      journeyRef.current = true; setJourneyEnabled(true); auth.noteExplicitAction(); await refresh();
    } catch (e) { handleUnauthorizedError(e); setError((e as { message?: string }).message ?? 'Live location could not be enabled.'); }
    finally { setActionBusy(false); }
  };

  if (!Number.isInteger(requestId) || requestId <= 0) return <Screen><ErrorNotice message="This repair request address is invalid." /></Screen>;
  return <Screen>
    <ScrollView contentContainerStyle={{ paddingTop: top + 10, paddingHorizontal: 18, paddingBottom: 34 }}>
      <AuthGate>
        {query.isLoading ? <LoadingState label="Loading repair details" /> : null}
        {query.isError ? <ErrorNotice message="This request is unavailable or could not be loaded." retry={() => void query.refetch()} /> : null}
        {job && !query.isLoading ? <>
          <SectionTitle detail={`Request ${job.id} · ${new Date(job.created_at).toLocaleString()}`}>{job.vehicle_problem}</SectionTitle>
          <Card>
            <Text style={[styles.status, { color: colors.primary }]}>{job.status.replaceAll('_', ' ')}</Text>
            <Text style={[styles.line, { color: colors.foreground }]}>Landmark: {job.location}</Text>
            <Text style={[styles.line, { color: colors.foreground }]}>Customer: {job.customer.name}</Text>
            <Text style={[styles.line, { color: colors.foreground }]}>Contact: {job.phone_number}</Text>
            {job.mechanic ? <Text style={[styles.line, { color: colors.foreground }]}>Mechanic: {job.mechanic.name}</Text> : null}
            {job.customer_position ? <Text style={[styles.caption, { color: colors.mutedForeground }]}>Customer pin captured {job.customer_position.captured_at ?? 'at an unreported time'}{job.customer_position.accuracy != null ? ` · accuracy about ${Math.round(job.customer_position.accuracy)} m` : ''}</Text> : <Text style={[styles.caption, { color: colors.mutedForeground }]}>No customer GPS pin was included with this request.</Text>}
            {job.mechanic_position ? <Text style={[styles.caption, { color: colors.mutedForeground }]}>Mechanic acceptance pin captured {job.mechanic_position.captured_at ?? 'at an unreported time'}{job.mechanic_position.accuracy != null ? ` · accuracy about ${Math.round(job.mechanic_position.accuracy)} m` : ''}</Text> : null}
            {job.live_tracking_enabled && job.live_position ? <Text style={[styles.caption, { color: colors.primary }]}>Live journey point captured {job.live_position.captured_at ?? 'at an unreported time'}{job.live_position.accuracy != null ? ` · accuracy about ${Math.round(job.live_position.accuracy)} m` : ''}</Text> : null}
          </Card>
          {job.customer_position || job.mechanic_position || (job.live_tracking_enabled && job.live_position) ? <Card style={{ padding: 8 }}>
            <MapPreview points={[
              ...(job.customer_position ? [{ latitude: job.customer_position.latitude, longitude: job.customer_position.longitude, title: 'Original customer request location', subtitle: `Captured ${job.customer_position.captured_at ?? 'time not reported'}` }] : []),
              ...(job.mechanic_position ? [{ latitude: job.mechanic_position.latitude, longitude: job.mechanic_position.longitude, title: 'Mechanic acceptance location', subtitle: `Captured ${job.mechanic_position.captured_at ?? 'time not reported'}` }] : []),
              ...(job.live_tracking_enabled && job.live_position ? [{ latitude: job.live_position.latitude, longitude: job.live_position.longitude, title: 'Opt-in live journey point', subtitle: `Captured ${job.live_position.captured_at ?? 'time not reported'}` }] : []),
            ]} accessibilityLabel="Repair tracking map with immutable request and acceptance pins and a separate optional live point" />
          </Card> : null}

          {canAccept ? <>
            {permissionMessage ? <ErrorNotice message={permissionMessage} /> : null}
            {permissionMessage && !permissionMessage.includes('could not') && Platform.OS !== 'web' ? <PrimaryButton title="Open location settings" secondary onPress={() => void Linking.openSettings().catch(() => undefined)} /> : null}
            <PrimaryButton title={busyAction === 'accept' ? 'Capturing GPS and accepting…' : 'Accept request (share fresh GPS)'} disabled={actionBusy} onPress={() => void runAction('accept')} />
          </> : null}
          {isMechanic && job.status === 'accepted' ? <PrimaryButton title={busyAction === 'start' ? 'Updating…' : 'Start repair journey'} disabled={actionBusy} onPress={() => void runAction('start')} /> : null}
          {isMechanic && job.status === 'on_the_way' ? <>
            <Card>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>Optional live journey sharing</Text>
              <Text style={[styles.caption, { color: colors.mutedForeground }]}>Only share a separate live location while this screen is active. Your accepted location pin stays unchanged. Sharing stops when you leave this screen, go away, arrive, or sign out.</Text>
              <PrimaryButton title={journeyEnabled ? 'Stop live location sharing' : 'Share live location while travelling'} secondary disabled={actionBusy} onPress={() => journeyEnabled ? void turnJourneyOff() : void enableJourney()} />
            </Card>
            <PrimaryButton title={busyAction === 'arrive' ? 'Updating…' : 'I have arrived'} disabled={actionBusy} onPress={() => void runAction('arrive')} />
          </> : null}
          {isMechanic && job.status === 'arrived' ? <>
            <Card>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>Repair estimate in GHS</Text>
              <Field label="Amount (GHS)" value={estimateAmount} onChangeText={setEstimateAmount} keyboardType="decimal-pad" placeholder="For example, 150.00" />
              <Field label="Repair description" value={estimateDescription} onChangeText={setEstimateDescription} multiline maxLength={2000} />
              <PrimaryButton title="Send estimate to customer" disabled={actionBusy} onPress={() => void submitEstimate()} />
            </Card>
            <PrimaryButton title={busyAction === 'complete' ? 'Completing…' : 'Complete repair'} disabled={actionBusy || latestEstimate?.status !== 'accepted'} onPress={() => void runAction('complete')} />
            {latestEstimate?.status !== 'accepted' ? <Text style={[styles.caption, { color: colors.mutedForeground }]}>The customer must accept the latest estimate before the repair can be marked complete.</Text> : null}
          </> : null}
          {isCustomer && job.status === 'pending' ? <PrimaryButton title="Cancel this pending request" danger disabled={actionBusy} onPress={() => void runAction('cancel')} /> : null}
          {isCustomer && latestEstimate ? <Card>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Latest repair estimate</Text>
            <Text style={[styles.line, { color: colors.foreground }]}>GHS {latestEstimate.amount} · {latestEstimate.status}</Text>
            <Text style={[styles.line, { color: colors.foreground }]}>{latestEstimate.description}</Text>
            <Text style={[styles.caption, { color: colors.mutedForeground }]}>Sent {new Date(latestEstimate.created_at).toLocaleString()}</Text>
            {latestEstimate.status === 'proposed' ? <View style={styles.row}>
              <View style={styles.flex}><PrimaryButton title="Accept estimate" disabled={actionBusy} onPress={() => void decision('accept')} /></View>
              <View style={styles.flex}><PrimaryButton title="Decline" secondary disabled={actionBusy} onPress={() => void decision('decline')} /></View>
            </View> : null}
          </Card> : null}
          {isCustomer && job.status === 'completed' && !job.review ? <Card>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Rate this repair</Text>
            <View style={styles.row}>
              {[1, 2, 3, 4, 5].map((rating) => <View key={rating} style={styles.rating}>
                <PrimaryButton title={`${rating} star${rating === 1 ? '' : 's'}`} secondary={reviewRating !== rating} onPress={() => setReviewRating(rating)} />
              </View>)}
            </View>
            <Field label="Review comment (optional)" value={reviewComment} onChangeText={setReviewComment} multiline maxLength={1000} />
            <PrimaryButton title="Submit repair review" disabled={actionBusy} onPress={() => void submitReview()} />
          </Card> : null}
          {job.review ? <Card><Text style={[styles.cardTitle, { color: colors.foreground }]}>Customer rating: {job.review.rating} out of 5</Text>
            {job.review.comment ? <Text style={[styles.line, { color: colors.foreground }]}>{job.review.comment}</Text> : null}</Card> : null}
          {(isCustomer && job.mechanic || isMechanic && job.customer) ? <PrimaryButton title={`Message ${isCustomer ? job.mechanic?.name : job.customer.name}`} secondary
            onPress={() => {
              const person = isCustomer ? job.mechanic : job.customer;
              if (person) router.push({ pathname: '/chat/[otherId]', params: { otherId: String(person.id), name: person.name } });
            }} /> : null}
          {error ? <ErrorNotice message={error} retry={() => void refresh()} /> : null}
          <PrimaryButton title="Refresh repair status" secondary onPress={() => void refresh()} />
        </> : null}
      </AuthGate>
    </ScrollView>
  </Screen>;
}

const styles = StyleSheet.create({
  status: { fontFamily: 'Poppins_700Bold', fontSize: 18, textTransform: 'capitalize' },
  line: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 21, marginTop: 5 },
  caption: { fontFamily: 'Poppins_400Regular', fontSize: 11, lineHeight: 18, marginTop: 7 },
  cardTitle: { fontFamily: 'Poppins_600SemiBold', fontSize: 15, marginBottom: 5 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  flex: { flex: 1, minWidth: 120 },
  rating: { flexGrow: 1, flexBasis: 72 },
});
