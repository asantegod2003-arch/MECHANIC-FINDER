import React, { useState } from 'react';
import { Linking, Platform, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import * as Location from 'expo-location';
import { createMobileRequest } from '@workspace/api-client-react';
import type { RequestInput } from '@workspace/api-client-react';
import { AuthGate } from '@/components/AuthGate';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { ErrorNotice, Field, PrimaryButton, Screen, SectionTitle } from '@/components/ui';
import { handleUnauthorizedError, useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';
import MapPreview from '@/components/MapPreview';

type CapturedPin = { latitude: number; longitude: number; accuracy: number | null; capturedAt: string } | null;

export default function NewRequestScreen() {
  const colors = useColors();
  const auth = useAuth();
  const [problem, setProblem] = useState('');
  const [landmark, setLandmark] = useState('');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState<CapturedPin>(null);
  const [locationState, setLocationState] = useState('');
  const [locationBusy, setLocationBusy] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const top = Platform.OS === 'web' ? 67 : 0;
  const capture = async () => {
    setLocationBusy(true); setLocationState('');
    try {
      let permission: Location.LocationPermissionResponse;
      try {
        permission = await Location.requestForegroundPermissionsAsync();
      } catch {
        setLocationState('Location permission could not be checked. Please try again.');
        return;
      }
      if (!permission.granted) {
        setLocationState(permission.canAskAgain
          ? 'Location permission was not granted. Allow location access to capture the real breakdown point.'
          : 'Location permission is blocked in device settings. Open Settings to allow location.');
        return;
      }
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setPin({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        capturedAt: new Date(position.timestamp).toLocaleString(),
      });
      setLocationState('');
    } catch {
      setLocationState('Your device could not capture a current location. Turn on location services and try again.');
    } finally { setLocationBusy(false); }
  };
  const submit = async () => {
    if (!problem.trim() || !landmark.trim() || !phone.trim()) { setError('Add the vehicle problem, a nearby landmark, and a contact phone number.'); return; }
    if (!pin) { setError('Capture your current location and check the map preview before sending your request.'); return; }
    setBusy(true); setError(''); auth.noteExplicitAction();
    const payload: RequestInput = {
      vehicle_problem: problem.trim(), location: landmark.trim(), phone_number: phone.trim(),
      customer_latitude: pin.latitude, customer_longitude: pin.longitude,
      ...(pin.accuracy != null ? { customer_location_accuracy: pin.accuracy } : {}),
    };
    try {
      const job = await createMobileRequest(payload);
      router.replace({ pathname: '/request/[id]', params: { id: String(job.id) } });
    } catch (e) {
      handleUnauthorizedError(e);
      setError((e as { message?: string }).message ?? 'The roadside request could not be sent. Please try again.');
    } finally { setBusy(false); }
  };
  return <Screen>
    <KeyboardAwareScrollViewCompat contentContainerStyle={{ paddingTop: top + 8, paddingHorizontal: 18, paddingBottom: 30 }} bottomOffset={70}>
      <SectionTitle detail="Tell nearby mechanics what happened and share the exact place where your car is stopped.">Request roadside help</SectionTitle>
      <AuthGate>
        {auth.user?.role !== 'customer' ? <ErrorNotice message="Roadside requests are for customer accounts." /> : <>
          <Field label="What is wrong with the vehicle?" value={problem} onChangeText={setProblem} multiline maxLength={200} placeholder="Describe the repair problem" />
          <Field label="Nearby landmark or directions" value={landmark} onChangeText={setLandmark} multiline maxLength={255} placeholder="For example, near a station or main road" />
          <Field label="Phone number mechanics can call" value={phone} onChangeText={setPhone} keyboardType="phone-pad" maxLength={20} />
          <SectionTitle>Capture your location</SectionTitle>
          <Text style={[styles.copy, { color: colors.mutedForeground }]}>The pin is captured from this device and saved to this request. It is not replaced by later profile or GPS updates.</Text>
          <PrimaryButton title={locationBusy ? 'Getting current location…' : pin ? 'Capture location again' : 'Use my current location'} onPress={() => void capture()} disabled={locationBusy} />
          {locationState ? <>
            <ErrorNotice message={locationState} />
            {!locationState.includes('could not') && Platform.OS !== 'web' ? <PrimaryButton title="Open device settings" secondary onPress={() => void Linking.openSettings().catch(() => undefined)} /> : null}
            <PrimaryButton title="Try location again" secondary onPress={() => void capture()} disabled={locationBusy} />
          </> : null}
          {pin ? <View style={[styles.mapFrame, { borderColor: colors.border }]}>
            <MapPreview points={[{ latitude: pin.latitude, longitude: pin.longitude, title: 'Captured vehicle location', subtitle: `Captured ${pin.capturedAt}` }]} accessibilityLabel="Map preview of the captured vehicle location" />
            <Text style={[styles.pinCaption, { color: colors.foreground }]}>Captured {pin.capturedAt}{pin.accuracy != null ? ` · accuracy about ${Math.round(pin.accuracy)} m` : ''}</Text>
          </View> : <View style={[styles.mapPlaceholder, { borderColor: colors.border, backgroundColor: colors.secondary }]}>
            <Text style={[styles.copy, { color: colors.mutedForeground }]}>A real map preview will appear after you capture your location.</Text>
          </View>}
          {error ? <ErrorNotice message={error} /> : null}
          <PrimaryButton title={busy ? 'Sending request…' : 'Send roadside request'} onPress={() => void submit()} disabled={busy || locationBusy} testID="send-request" />
        </>}
      </AuthGate>
    </KeyboardAwareScrollViewCompat>
  </Screen>;
}

const styles = StyleSheet.create({
  copy: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 21 },
  mapFrame: { borderWidth: 1, borderRadius: 12, overflow: 'hidden', marginTop: 10, marginBottom: 12 },
  pinCaption: { fontFamily: 'Poppins_500Medium', fontSize: 11, padding: 10, lineHeight: 17 },
  mapPlaceholder: { borderWidth: 1, borderRadius: 12, minHeight: 100, alignItems: 'center', justifyContent: 'center', padding: 20, marginVertical: 10 },
});
