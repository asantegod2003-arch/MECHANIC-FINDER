import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text } from 'react-native';
import { router } from 'expo-router';
import { setupMobileAccount } from '@workspace/api-client-react';
import type { SetupMobileAccountBodyRole } from '@workspace/api-client-react';
import { AuthGate } from '@/components/AuthGate';
import { Card, PrimaryButton, Screen, SectionTitle } from '@/components/ui';
import { handleUnauthorizedError, useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function SetupScreen() {
  const colors = useColors();
  const auth = useAuth();
  const [role, setRole] = useState<SetupMobileAccountBodyRole>('customer');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    if (auth.user?.role && !auth.user.needs_setup) router.replace('/(tabs)');
  }, [auth.user?.role, auth.user?.needs_setup]);
  const select = async (nextRole: SetupMobileAccountBodyRole) => {
    setRole(nextRole); setError(''); auth.noteExplicitAction(); setBusy(true);
    try {
      const updated = await setupMobileAccount({ role: nextRole });
      auth.updateUser(updated);
      router.replace('/(tabs)');
    } catch (e) {
      handleUnauthorizedError(e);
      setError((e as { message?: string }).message ?? 'Account setup could not be saved.');
    } finally { setBusy(false); }
  };
  return <Screen>
    <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 32 }}>
      <SectionTitle detail="Your identity and existing conversations stay with your account.">Choose your role</SectionTitle>
      <AuthGate>
        <Card>
          <Text style={[styles.copy, { color: colors.foreground }]}>Select the role that best matches how you use Mechanic Finder. You can still read your existing messages while this profile is being set up.</Text>
          {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
          <PrimaryButton title="I need roadside help" secondary={role !== 'customer'} disabled={busy} onPress={() => setRole('customer')} />
          <PrimaryButton title="I provide mechanic services" secondary={role !== 'mechanic'} disabled={busy} onPress={() => setRole('mechanic')} />
          <PrimaryButton title={busy ? 'Saving…' : `Continue as ${role}`} disabled={busy} onPress={() => void select(role)} />
        </Card>
      </AuthGate>
    </ScrollView>
  </Screen>;
}

const styles = StyleSheet.create({
  copy: { fontFamily: 'Poppins_400Regular', fontSize: 14, lineHeight: 22, marginBottom: 8 },
  error: { fontFamily: 'Poppins_500Medium', fontSize: 13, marginBottom: 10 },
});
