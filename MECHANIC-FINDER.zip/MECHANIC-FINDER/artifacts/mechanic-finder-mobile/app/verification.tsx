import React, { useState } from 'react';
import { Platform, ScrollView, StyleSheet, Text } from 'react-native';
import { submitMobileVerification, useGetMobileVerification } from '@workspace/api-client-react';
import type { VerificationInput } from '@workspace/api-client-react';
import { AuthGate } from '@/components/AuthGate';
import { Card, ErrorNotice, Field, LoadingState, PrimaryButton, Screen, SectionTitle } from '@/components/ui';
import { handleUnauthorizedError, useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function VerificationScreen() {
  const colors = useColors();
  const auth = useAuth();
  const query = useGetMobileVerification({ query: { enabled: auth.user?.role === 'mechanic' } });
  const [fields, setFields] = useState<Partial<VerificationInput>>({});
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const top = Platform.OS === 'web' ? 67 : 0;
  const current = query.data;
  const value = (name: keyof VerificationInput) => fields[name] ?? current?.[name] ?? '';
  const update = (name: keyof VerificationInput, text: string) => setFields((prev) => ({ ...prev, [name]: text }));
  const submit = async () => {
    if (!current && !['business_name', 'contact_number', 'service_area', 'experience', 'credential_reference'].every((name) => fields[name as keyof VerificationInput]?.trim())) {
      setError('Complete each field before submitting your application.'); return;
    }
    const payload: VerificationInput = {
      business_name: value('business_name'), contact_number: value('contact_number'), service_area: value('service_area'),
      experience: value('experience'), credential_reference: value('credential_reference'),
    };
    auth.noteExplicitAction(); setBusy(true); setError(''); setMessage('');
    try {
      const result = await submitMobileVerification(payload);
      setMessage(`Application status: ${result.status}. ${result.public_feedback}`);
      void query.refetch();
    } catch (e) { handleUnauthorizedError(e); setError((e as { message?: string }).message ?? 'Verification application could not be submitted.'); }
    finally { setBusy(false); }
  };
  return <Screen>
    <ScrollView contentContainerStyle={{ paddingTop: top + 12, paddingHorizontal: 18, paddingBottom: 32 }}>
      <SectionTitle detail="Submit real business details for administrator review.">Mechanic verification</SectionTitle>
      <AuthGate>
        {auth.user?.role !== 'mechanic' ? <Card><Text style={[styles.copy, { color: colors.foreground }]}>Verification is available for mechanic accounts.</Text></Card> : <>
          {query.isLoading ? <LoadingState label="Loading your verification application" /> : null}
          {query.isError ? <ErrorNotice message="Your application status could not be loaded." retry={() => void query.refetch()} /> : null}
          {current ? <Card>
            <Text style={[styles.status, { color: colors.primary }]}>Status: {current.status.replaceAll('_', ' ')}</Text>
            {current.public_feedback ? <Text style={[styles.copy, { color: colors.foreground }]}>{current.public_feedback}</Text> : null}
            <Text style={[styles.copy, { color: colors.mutedForeground }]}>Only public feedback is shown here. Private administrator review notes are not available in this app.</Text>
          </Card> : null}
          <Card>
            <Text style={[styles.copy, { color: colors.mutedForeground }]}>Your application is sent for manual administrator review. Submission does not automatically verify a mechanic.</Text>
            <Field label="Business name" value={value('business_name')} onChangeText={(text) => update('business_name', text)} maxLength={150} />
            <Field label="Contact number" value={value('contact_number')} onChangeText={(text) => update('contact_number', text)} keyboardType="phone-pad" maxLength={30} />
            <Field label="Service area" value={value('service_area')} onChangeText={(text) => update('service_area', text)} maxLength={150} />
            <Field label="Experience" value={value('experience')} onChangeText={(text) => update('experience', text)} multiline maxLength={2000} />
            <Field label="Credential reference" value={value('credential_reference')} onChangeText={(text) => update('credential_reference', text)} maxLength={255} />
            {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
            {message ? <Text accessibilityRole="alert" style={[styles.success, { color: colors.primary }]}>{message}</Text> : null}
            <PrimaryButton title={busy ? 'Submitting…' : current?.status === 'pending' ? 'Update application' : 'Submit for review'} onPress={() => void submit()} disabled={busy || query.isLoading} />
          </Card>
        </>}
      </AuthGate>
    </ScrollView>
  </Screen>;
}

const styles = StyleSheet.create({
  copy: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 21 },
  status: { fontFamily: 'Poppins_600SemiBold', fontSize: 15, marginBottom: 5 },
  error: { fontFamily: 'Poppins_500Medium', fontSize: 13 },
  success: { fontFamily: 'Poppins_500Medium', fontSize: 13, marginVertical: 5 },
});
