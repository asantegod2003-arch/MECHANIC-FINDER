import React from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { router } from 'expo-router';
import { readMobileNotifications, useGetMobileNotifications } from '@workspace/api-client-react';
import { AuthGate } from '@/components/AuthGate';
import { Card, ErrorNotice, LoadingState, PrimaryButton, Screen, SectionTitle } from '@/components/ui';
import { handleUnauthorizedError, useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

function nativeDestination(url: string): string | { pathname: '/chat/[otherId]'; params: { otherId: string } } {
  const requestMatch = url.match(/(?:requests?|repairs?|tracking|track)\/(\d+)/i);
  if (requestMatch) return `/request/${requestMatch[1]}`;
  const chatMatch = url.match(/(?:chat|messages?)\/(?:user\/)?(\d+)|(?:otherId|other_id|user_id)=(\d+)/i);
  if (chatMatch) return { pathname: '/chat/[otherId]', params: { otherId: chatMatch[1] ?? chatMatch[2] } };
  return '/(tabs)';
}

export default function NotificationsScreen() {
  const colors = useColors();
  const auth = useAuth();
  const query = useGetMobileNotifications({ query: { enabled: auth.isAuthenticated } });
  const unread = query.data?.filter((notification) => !notification.is_read).length ?? 0;
  const top = Platform.OS === 'web' ? 67 : 0;
  const markAll = async () => {
    auth.noteExplicitAction();
    try { await readMobileNotifications({}); await query.refetch(); } catch (e) { handleUnauthorizedError(e); }
  };
  const open = async (notification: NonNullable<typeof query.data>[number]) => {
    auth.noteExplicitAction();
    if (!notification.is_read) {
      try { await readMobileNotifications({ id: notification.id }); await query.refetch(); } catch (e) { handleUnauthorizedError(e); }
    }
    router.push(nativeDestination(notification.url) as never);
  };
  return <Screen>
    <ScrollView contentContainerStyle={{ paddingTop: top + 12, paddingHorizontal: 18, paddingBottom: 32 }}>
      <SectionTitle detail={unread ? `${unread} unread update${unread === 1 ? '' : 's'}` : 'Updates about your requests, repairs and messages.'}>Notifications</SectionTitle>
      <AuthGate>
        {query.isLoading ? <LoadingState label="Loading notifications" /> : null}
        {query.isError ? <ErrorNotice message="Notifications could not be loaded." retry={() => void query.refetch()} /> : null}
        {unread > 0 ? <PrimaryButton title="Mark all as read" secondary onPress={() => void markAll()} /> : null}
        {query.data?.length === 0 ? <Card><Text style={[styles.body, { color: colors.mutedForeground }]}>You have no in-app notifications.</Text></Card> : null}
        {query.data?.map((notification) => <Pressable key={notification.id} accessibilityRole="button" accessibilityLabel={`Open notification: ${notification.title}`}
          onPress={() => void open(notification)} style={({ pressed }) => [styles.item, {
            backgroundColor: notification.is_read ? colors.card : colors.secondary, borderColor: colors.border, opacity: pressed ? 0.82 : 1,
          }]}>
          <Text style={[styles.title, { color: colors.foreground }]}>{notification.title}</Text>
          <Text style={[styles.body, { color: colors.foreground }]}>{notification.message}</Text>
          <Text style={[styles.date, { color: colors.mutedForeground }]}>{new Date(notification.created_at).toLocaleString()}</Text>
          {!notification.is_read ? <Text style={[styles.unread, { color: colors.primary }]}>Unread · tap to open</Text> : null}
        </Pressable>)}
      </AuthGate>
    </ScrollView>
  </Screen>;
}

const styles = StyleSheet.create({
  item: { borderWidth: 1, borderRadius: 12, padding: 15, marginVertical: 5 },
  title: { fontFamily: 'Poppins_600SemiBold', fontSize: 15 },
  body: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 20, marginTop: 4 },
  date: { fontFamily: 'Poppins_400Regular', fontSize: 11, marginTop: 7 },
  unread: { fontFamily: 'Poppins_600SemiBold', fontSize: 11, marginTop: 7 },
});
