/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#20352a',
    tint: '#198754',

    // Core surfaces
    background: '#f5f8f5',
    foreground: '#20352a',

    // Cards / elevated surfaces
    card: '#ffffff',
    cardForeground: '#20352a',

    // Primary action color (buttons, links, active states)
    primary: '#198754',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#e9f1eb',
    secondaryForeground: '#12663f',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#edf2ed',
    mutedForeground: '#64736a',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#e9f1eb',
    accentForeground: '#12663f',

    // Destructive actions (delete, error states)
    destructive: '#b42318',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#dce7df',
    input: '#dce7df',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 10,
};

export default colors;
