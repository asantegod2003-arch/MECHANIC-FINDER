# Mechanic Finder -Ghana: mobile release checklist

## What this build is

- A React Native / Expo Router application for Android and iPhone, not a website
  inside a WebView.
- Display name confirmed by the owner: **Mechanic Finder -Ghana**.
- Initial iOS bundle identifier and Android package:
  **`com.mechanicfinderghana.app`**. Availability in the store accounts must still
  be checked before the first release. Do not change released identifiers.
- The existing green car icon, Poppins typography, and website branding are
  retained. There is no separate mobile user database.
- The website remains at <https://mechanic-finder.replit.app>.
  This URL was obtained from the deployment service, not inferred from the
  workspace name.

## Preview now

Open the **Mechanic Finder Ghana Mobile** artifact. Use Replit's **Preview on
your phone** and scan its QR code in Expo Go. Follow the managed sign-in steps if
that panel requests them. Keep the project running while testing.

The preview calls the development Django service and its development database.
A production mobile build must call the published Django service and production
database, using the corresponding existing production accounts.

## Publish the backend before a production mobile build

The new native endpoints are `/api/mobile/`. The Django artifact owns that
specific prefix, while the shared Node service retains `/api/healthz`. The
existing website stays at `/`; it has not been replaced.

Production `EXPO_PUBLIC_DOMAIN` and `EXPO_PUBLIC_API_BASE_URL` resolve to the
published Django host `mechanic-finder.replit.app`; the development workflow
sets `EXPO_PUBLIC_API_BASE_URL` to the shared project development domain. Do not
use `REPLIT_EXPO_DEV_DOMAIN` for API calls: it serves the Expo bundle, not the
Django mobile endpoints. A login request sent to that Expo-only host returns
404, not a credential error. Do not hardcode development domains or localhost
in mobile application networking.

After publishing the project/backend, check:

- `/` and `/login/` still load the website.
- `/api/healthz` returns the health JSON.
- `/api/mobile/mechanics/` returns the public directory JSON.
- `/api/mobile/me/` without a bearer token returns **401**, not an HTML page.
- A real existing production account signs in successfully.

There are no new model/schema migrations for this native API. **Do not add
production startup migrations or push the empty Drizzle scaffold schema.**

## Required phone checks before store submission

### Development checks completed

The focused browser regression is `node scripts/src/native-auth.e2e.mjs` from
the workspace root with the Expo service running. It uses a unique synthetic
development account and records its ID in ignored
`generated-artifacts/mobile-auth-result.json`; clean up that exact ID and
username after the check, never real accounts. It verifies phone-width
navigation, retained fields on signup errors, signup, server-side logout,
wrong-password feedback, email login to the same account, and private screen
access. The current run passed and its fixtures were removed.

The nearby-mechanic regression is
`node scripts/src/native-nearby.e2e.mjs`. It also asserts that Expo API
requests use the development backend host, then removes its six synthetic
accounts.

Mobile TypeScript and the three departure-lifecycle unit tests pass, as do the
34 native API regression tests. Existing website tests also passed during
integration. These checks do **not** constitute a signed-device test.

Expo Doctor currently passes 19 of 20 checks. Its remaining recommendation is
to advance Expo 58.0.19 to 58.0.20 and Expo Router 58.0.26 to 58.0.27. The attempted
update was rejected by the package firewall's minimum-release-age policy; do
not bypass that protection or suppress these packages from checks. Retry the
approved patches and rerun compatibility checks before a store release.
`react-native-maps` remains explicitly pinned to 1.18.0 and excluded from Expo's
automatic version replacement; SDK 58 expects 1.29.11. Its actual signed-device
compatibility must be verified rather than inferred from a passing web build.

Browser previews and server tests cannot verify physical GPS, microphones,
Bluetooth/headset routing, native SecureStore, or native operating-system
permission dialogs. Complete these on actual Android and iPhone devices:

1. Sign up using an email address and separately using a username. Check
   duplicate credentials, wrong passwords, clear field errors, and role setup
   for an older account with no unambiguous profile.
2. Leave the app for less than ten minutes and return: remain signed in. Leave
   for at least ten continuous minutes and return: require login. Internal
   navigation must not log the user out. Three-hour idle expiry remains a
   server-side backstop; polling must not renew it.
3. Customer: allow GPS, check the point and accuracy before submitting a repair
   request. Deny GPS, then retry or open device settings. Never substitute a
   guessed or default location.
4. Mechanic: go online, update presence, see a new pending request, and accept
   with a fresh GPS fix. A second mechanic must not claim the accepted request.
5. Confirm request and acceptance pins remain fixed when presence or optional
   foreground journey tracking changes. Check both timestamps and accuracy.
   Location streaming must stop on leaving the app, logout, or ending sharing.
    Live points and effective sharing state expire server-side after 60 seconds
    without a fresh capture, even if a disconnected phone cannot send its stop.
6. Exchange messages in both directions, including existing conversations from
   before this build. Missing/changed role profiles must not hide saved history.
7. Record, preview, cancel, re-record, send, and play private voice messages on
   both devices, including microphone denial/retry. Verify M4A/WebM support,
   the two-minute/eight-megabyte limits, interruptions, and no microphone left
   active in the background.
8. Propose a price, approve/decline the latest estimate as the customer, complete
   an approved repair, and leave a customer review. Try the same actions as
   someone outside the repair and confirm access is denied.
9. Inspect notification actions and history, logout, network interruptions,
   small-phone layout, keyboard handling, and screen-reader labels.

Precise physical accuracy depends on the device and available GPS signal.
Historical missing captures cannot be reconstructed. Do not market coordinates
as guaranteed exact physical positions.

## Maps and permission configuration

- After customer login, the mobile home screen requests a foreground GPS fix
  and finds available mechanics with presence updated in the previous 10
  minutes, sorted by proximity within 25 km. It shows coarse distance bands
  (including within 1 km), never a mechanic's precise coordinates. The
  customer's search GPS travels in an authenticated POST body; the lookup
  neither stores it nor creates a repair request. Foreground refresh does not
  renew the three-hour idle session. If GPS is declined or no
  fresh result exists, the public service-area directory remains usable.
- Going online captures the mechanic's GPS. Mechanics can refresh their
  nearby-listing location from Account while online; after 10 minutes without
  a refresh, the listing expires rather than presenting an old position as
  current. Saved request and acceptance pins remain separate.

- Ask only for foreground location and microphone access when the user chooses
  the related feature. Do not enable background location or background
  recording for this build.
- iPhone maps use the platform map provider. The Android Google Maps SDK needs
  a correctly restricted Android Maps key for a standalone Google-map build;
  Expo Go's own map configuration is not a production key.
- Keep a key-free map preview/fallback and an explicit external Maps action
  available rather than mounting an unconfigured Android Google map.
- Web previews use map tiles with attribution. They still require internet
  access. A visible point must always come from captured GPS.
- If configuring Google Maps later, use the integration/secrets workflow,
  restrict the key to the Android package/signing certificate, and verify it in
  a signed build. Do not put private credentials in source or chat.

## Owner-controlled privacy, deletion and moderation requirements

These are **release blockers**, not claims of completed store compliance:

- Publish real privacy-policy and terms URLs owned by the business. Describe
  account information, precise location, repair/contact details, private text
  and voice messages, App Storage, and map providers accurately. Complete
  Apple's privacy disclosures and Google Play's Data safety form accordingly.
- The in-app deletion action currently asks for the password and explicit
  confirmation, then saves a **manual deletion request** to the user's and
  administrators' private notifications. It does **not** erase data, disable the
  account, or promise a completion date. An administrator must process it.
- Establish a verified deletion/retention policy and an actual fulfillment
  process. Do not use a bare Django User delete that silently cascades other
  participants' repair/conversation histories. Decide retained legal/business
  records with the owner rather than inventing a retention period.
- Provide a public, working browser route for account-deletion requests and
  store-listing deletion links where required. It is not implemented by the
  current native request endpoint.
- Complete the already queued unwanted-chat block/report work and connect it to
  native messaging. Add the required moderation/contact process and user terms
  acceptance before submitting an app containing user messages to a store.
- In-app notifications are implemented. Background push notifications remain
  separate queued work; do not advertise them as implemented.
- Password recovery email still requires the existing Resend sender/domain
  setup. Do not promise recovery email delivery before it is verified.

## Apple App Store

The owner needs an Apple Developer Program membership and App Store Connect
access, confirmed app identity/availability, app category, age rating, support
and privacy URLs, actual-device screenshots, and review access/instructions.
Never include a real user's password in store metadata.

Replit's **Expo Launch** provides the build/signing and iOS upload/submission
flow. The owner starts publishing and approves the store steps; this task does
not publish, buy membership, accept agreements, or guarantee review approval.
TestFlight and App Store acceptance are separate from a working Expo preview.

Official Replit guidance:
- <https://docs.replit.com/build/mobile-apple-account>
- <https://docs.replit.com/build/mobile-upload-ios>
- <https://docs.replit.com/build/mobile-publish-ios>

## Google Play

The Android application is cross-platform source, not a submitted Play Store
listing or a verified signed AAB. Replit currently does **not** provide direct
Google Play publishing.

The owner needs a Google Play Console developer account, identity verification,
confirmed package availability, a separate supported Android signing/release
process, screenshots/store assets, content ratings, Data safety and deletion
links, and the testing requirements applicable to that account. Verify the
current requirements in Play Console; they can change.

No Android release or paid developer-account commitment has been performed.
