import { ReplitConnectors } from "@replit/connectors-sdk";

try {
    let input = "";
    for await (const chunk of process.stdin) input += chunk.toString();
    const payload = JSON.parse(input);
    const response = await new ReplitConnectors().proxy("resend", "/emails", {
        method: "POST", body: payload,
    });
    if (!response.ok) process.exitCode = 1;
    else console.log(JSON.stringify({sent: true}));
} catch (_) {
    process.exitCode = 1;
}
