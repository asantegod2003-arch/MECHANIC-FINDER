# Mechanic Finder

## Stack
Django 6.0 on Python 3.12, server-rendered templates, and Replit's managed
PostgreSQL database (`DATABASE_URL`). The original `db.sqlite3` file is kept
unchanged as a local backup; its imported users, profiles, and rescue requests
were copied into PostgreSQL.

## Running on Replit
Click **Run** to start the **Start application** workflow. It runs:

```sh
python manage.py migrate --noinput && python manage.py runserver 0.0.0.0:5000
```

Dependencies are pinned in `requirements.txt` (UTF-8). The configured Python
environment installs these packages. Do not use a virtual environment.

## Configuration
- `SESSION_SECRET` is required and provides Django's signing key. It is already
  configured as a Replit secret; never put its value in source control.
- `GOOGLE_MAPS_API_KEY` is optional for starting the app, but required for the
  Google Maps view on rescue tracking pages. Add it through Replit Secrets.
  Enable the Maps JavaScript API and Directions API and restrict the key to
  the app's allowed website domains. The credential previously embedded in
  source should be rotated/restricted by its owner.
- `DJANGO_DEBUG` defaults to `True` for development. Development accepts proxy
  hosts and allows the Replit preview iframe. The HTTPS proxy header is trusted
  so CSRF checks work through Replit.
- Publishing runs Django with debug disabled, collects static assets, and serves
  the app with Gunicorn. Production accepts Replit's `.replit.app` host by
  default; set `DJANGO_ALLOWED_HOSTS` if using a custom domain. Secure session
  and CSRF cookies are enabled in production.
- Public mechanic directory: `/mechanics/`. It lists only mechanics marked
  available and supports search by name or username. It does not expose rescue
  requests, phone numbers, or GPS coordinates.
- Replit's publish flow provisions the production PostgreSQL database from the
  seeded development database and applies the production schema. Do not replace
  the existing database without the user's approval.

## Checks
```sh
python manage.py check
python manage.py test
```

Public pages: `/`, `/login/`, `/signup/`. Customer and mechanic dashboards
require signing in with the corresponding account role.
