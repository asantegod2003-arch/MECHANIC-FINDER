from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponseForbidden
from django.views.decorators.http import require_POST
from django.utils import timezone

from .models import RescueRequest
from .forms import RescueRequestForm
from accounts.models import Profile
from accounts.notifications import create_notification, notify_nearby_mechanics
from django.urls import reverse
from django.db import transaction
import math


def _coordinates(latitude, longitude):
    """Missing or invalid GPS values are not a position at zero degrees."""
    if latitude is None or longitude is None:
        return None
    try:
        latitude, longitude = float(latitude), float(longitude)
    except (TypeError, ValueError):
        return None
    if (
        math.isfinite(latitude) and math.isfinite(longitude)
        and -90 <= latitude <= 90 and -180 <= longitude <= 180
    ):
        return {"lat": latitude, "lng": longitude}
    return None


def _mechanic_position(rescue_request):
    if not rescue_request.mechanic_id:
        return None, None
    return _coordinates(
        rescue_request.mechanic_latitude, rescue_request.mechanic_longitude
    ), rescue_request.mechanic_location_captured_at


def _is_mechanic(user):
    return hasattr(user, "profile") and user.profile.role == "mechanic"


def _is_customer(user):
    return hasattr(user, "profile") and user.profile.role == "customer"


# ==========================================
# CREATE RESCUE REQUEST
# ==========================================

@login_required
def create_request(request):

    if not _is_customer(request.user):
        return redirect("mechanic_dashboard")

    if request.method == "POST":

        form = RescueRequestForm(request.POST)

        if form.is_valid():

            rescue = form.save(commit=False)

            rescue.customer = request.user
            rescue.customer_location_captured_at = timezone.now()

            rescue.save()
            notify_nearby_mechanics(rescue)

            messages.success(
                request,
                "Rescue request submitted. Waiting for a mechanic."
            )

            return redirect("customer_dashboard")

    else:

        form = RescueRequestForm()

    return render(
        request,
        "rescue/create_request.html",
        {
            "form": form
        }
    )


# ==========================================
# MECHANIC REQUESTS
# ==========================================

@login_required
def mechanic_requests(request):

    if not _is_mechanic(request.user):
        return redirect("customer_dashboard")

    return redirect("mechanic_dashboard")


# ==========================================
# ACCEPT REQUEST
# ==========================================

@login_required
@require_POST
def accept_request(request, request_id):

    if not _is_mechanic(request.user):
        return redirect("customer_dashboard")

    if not request.user.profile.available:
        messages.warning(
            request,
            "Go online before accepting jobs."
        )
        return redirect("mechanic_dashboard")

    position = _coordinates(request.POST.get("latitude"), request.POST.get("longitude"))
    accuracy = request.POST.get("accuracy")
    try:
        accuracy = float(accuracy) if accuracy not in ("", None) else None
        if accuracy is not None and (not math.isfinite(accuracy) or accuracy < 0):
            raise ValueError
    except (TypeError, ValueError):
        position = None
    if position is None:
        messages.error(request, "Allow precise location access and try Accept again. No job was accepted without GPS.")
        return redirect("mechanic_dashboard")
    with transaction.atomic():
        rescue_request = get_object_or_404(
            RescueRequest.objects.select_for_update(), id=request_id, status="pending"
        )
        rescue_request.mechanic = request.user
        rescue_request.status = "accepted"
        rescue_request.mechanic_latitude = position["lat"]
        rescue_request.mechanic_longitude = position["lng"]
        rescue_request.mechanic_location_accuracy = accuracy
        rescue_request.mechanic_location_captured_at = timezone.now()
        rescue_request.save()
        create_notification(
            recipient=rescue_request.customer,
            title="Your rescue request was accepted",
            message=f"{request.user.get_full_name() or request.user.username} accepted your request.",
            url=reverse("tracking", args=[rescue_request.id]),
        )

    messages.success(request, "Job accepted.")

    return redirect("mechanic_dashboard")


# ==========================================
# START TRIP
# ==========================================

@login_required
@require_POST
@transaction.atomic
def start_trip(request, request_id):

    if not _is_mechanic(request.user):
        return redirect("customer_dashboard")

    rescue_request = get_object_or_404(
        RescueRequest.objects.select_for_update(),
        id=request_id,
        mechanic=request.user, status="accepted"
    )

    rescue_request.status = "on_the_way"

    rescue_request.save()
    create_notification(
        recipient=rescue_request.customer, title="Your mechanic is on the way",
        message="Open the map to view journey updates when the mechanic shares their location.",
        url=reverse("tracking", args=[rescue_request.id]),
    )

    return redirect("mechanic_dashboard")


# ==========================================
# MARK ARRIVED
# ==========================================

@login_required
@require_POST
@transaction.atomic
def mark_arrived(request, request_id):

    if not _is_mechanic(request.user):
        return redirect("customer_dashboard")

    rescue_request = get_object_or_404(
        RescueRequest.objects.select_for_update(),
        id=request_id,
        mechanic=request.user, status="on_the_way"
    )

    rescue_request.status = "arrived"
    rescue_request.live_tracking_enabled = False

    rescue_request.save()

    return redirect("mechanic_dashboard")


# ==========================================
# COMPLETE JOB
# ==========================================

@login_required
@require_POST
@transaction.atomic
def complete_job(request, request_id):

    if not _is_mechanic(request.user):
        return redirect("customer_dashboard")

    rescue_request = get_object_or_404(
        RescueRequest.objects.select_for_update(),
        id=request_id,
        mechanic=request.user, status="arrived"
    )

    estimate = rescue_request.estimates.first()
    if not estimate or estimate.status != "accepted":
        messages.error(request, "The customer must approve the latest repair estimate before this job can be completed.")
        return redirect("repair_detail", request_id=rescue_request.id)
    rescue_request.status = "completed"
    rescue_request.live_tracking_enabled = False

    rescue_request.save()
    create_notification(
        recipient=rescue_request.customer, title="Repair completed",
        message="You can now leave a review for this completed repair.",
        url=reverse("repair_detail", args=[rescue_request.id]),
    )

    return redirect("mechanic_dashboard")


# ==========================================
# CUSTOMER TRACKING PAGE
# ==========================================

@login_required
def tracking(request, request_id):

    rescue_request = get_object_or_404(
        RescueRequest,
        id=request_id
    )

    is_customer = rescue_request.customer_id == request.user.id
    is_assigned_mechanic = (
        rescue_request.mechanic_id == request.user.id
    )

    if not (is_customer or is_assigned_mechanic):
        return HttpResponseForbidden("You cannot view this tracking page.")

    return render(
        request,
        "rescue/tracking.html",
        {
            "rescue_request": rescue_request,
            "is_customer": is_customer,
            "tracking_data": {
                "customer": _coordinates(
                    rescue_request.customer_latitude, rescue_request.customer_longitude
                ),
                "pollUrl": reverse("mechanic_location", args=[rescue_request.id]),
                "customerLocationUrl": reverse("update_customer_location", args=[rescue_request.id]),
                "isCustomer": is_customer,
                "isMechanic": is_assigned_mechanic,
                "journeyUrl": reverse("update_live_journey", args=[rescue_request.id]),
                "status": rescue_request.status,
            },
        }
    )


@login_required
@require_POST
@transaction.atomic
def update_customer_location(request, request_id):
    rescue_request = get_object_or_404(
        RescueRequest.objects.select_for_update(), id=request_id, customer=request.user
    )
    if rescue_request.status in ("completed", "cancelled"):
        return JsonResponse({"success": False, "message": "This request is already closed."}, status=400)
    if _coordinates(rescue_request.customer_latitude, rescue_request.customer_longitude):
        return JsonResponse({
            "success": False,
            "message": "The GPS position captured for this request is fixed and cannot be replaced.",
        }, status=409)
    position = _coordinates(request.POST.get("latitude"), request.POST.get("longitude"))
    if position is None:
        return JsonResponse({"success": False, "message": "Invalid location."}, status=400)
    rescue_request.customer_latitude = position["lat"]
    rescue_request.customer_longitude = position["lng"]
    rescue_request.customer_location_captured_at = timezone.now()
    rescue_request.save(update_fields=[
        "customer_latitude", "customer_longitude", "customer_location_captured_at", "updated_at"
    ])
    return JsonResponse({"success": True, "customer": position})


# ==========================================
# UPDATE MECHANIC LOCATION
# ==========================================

# ==========================================
# UPDATE MECHANIC LOCATION
# ==========================================

@login_required
@require_POST
def update_location(request, request_id):

    if not _is_mechanic(request.user):
        return JsonResponse(
            {"success": False, "message": "Not allowed."},
            status=403
        )

    rescue_request = get_object_or_404(
        RescueRequest,
        id=request_id,
        mechanic=request.user
    )

    try:

        latitude = float(request.POST.get("latitude"))
        longitude = float(request.POST.get("longitude"))

    except (TypeError, ValueError):

        return JsonResponse(
            {
                "success": False,
                "message": "Invalid location."
            },
            status=400
        )

    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        return JsonResponse(
            {"success": False, "message": "Invalid location."},
            status=400
        )

    # Get the mechanic's profile
    profile = get_object_or_404(
        Profile,
        user=request.user
    )

    # Save the mechanic's current GPS location
    profile.latitude = latitude
    profile.longitude = longitude
    profile.location_updated_at = timezone.now()

    profile.save(
        update_fields=[
            "latitude",
            "longitude",
            "location_updated_at"
        ]
    )

    # Presence may move, but the acceptance snapshot on the job must not.

    return JsonResponse(
        {
            "success": True,
            "latitude": latitude,
            "longitude": longitude
        }
    )
    
    


# ==========================================
# GET MECHANIC LOCATION
# ==========================================

@login_required
def mechanic_location(request, request_id):

    rescue_request = get_object_or_404(
        RescueRequest,
        id=request_id
    )

    is_customer = rescue_request.customer_id == request.user.id
    is_assigned_mechanic = (
        rescue_request.mechanic_id == request.user.id
    )

    if not (is_customer or is_assigned_mechanic):
        return JsonResponse(
            {"success": False, "message": "Not allowed."},
            status=403
        )

    position, updated_at = _mechanic_position(rescue_request)
    live = _coordinates(rescue_request.live_latitude, rescue_request.live_longitude)
    sharing = rescue_request.live_tracking_enabled and rescue_request.status == "on_the_way"
    fresh = bool(
        sharing and live and rescue_request.live_location_updated_at
        and (timezone.now() - rescue_request.live_location_updated_at).total_seconds() <= 60
    )

    return JsonResponse(
        {
            "success": True,
            "latitude": position["lat"] if position else None,
            "longitude": position["lng"] if position else None,
            "location_updated_at": updated_at.isoformat() if updated_at else None,
            "mechanic_captured_at": updated_at.isoformat() if updated_at else None,
            "mechanic_accuracy": rescue_request.mechanic_location_accuracy,
            "customer_accuracy": rescue_request.customer_location_accuracy,
            "customer_captured_at": (
                rescue_request.customer_location_captured_at.isoformat()
                if rescue_request.customer_location_captured_at else None
            ),
            "customer": _coordinates(
                rescue_request.customer_latitude, rescue_request.customer_longitude
            ),
            "status": rescue_request.status,
            "live": live if sharing else None,
            "live_sharing": sharing,
            "live_fresh": fresh,
            "live_updated_at": (
                rescue_request.live_location_updated_at.isoformat()
                if sharing and rescue_request.live_location_updated_at else None
            ),
            "live_accuracy": rescue_request.live_accuracy if sharing else None,
        }
    )


@login_required
@require_POST
@transaction.atomic
def update_live_journey(request, request_id):
    job = get_object_or_404(
        RescueRequest.objects.select_for_update(), pk=request_id, mechanic=request.user
    )
    if request.POST.get("action") == "stop":
        job.live_tracking_enabled = False
        job.save(update_fields=["live_tracking_enabled"])
        return JsonResponse({"success": True, "sharing": False})
    if job.status != "on_the_way":
        return JsonResponse({"error": "Live journey sharing is only available while travelling to this customer."}, status=400)
    position = _coordinates(request.POST.get("latitude"), request.POST.get("longitude"))
    try:
        accuracy = float(request.POST.get("accuracy", ""))
        if not math.isfinite(accuracy) or accuracy < 0:
            raise ValueError
    except (TypeError, ValueError):
        return JsonResponse({"error": "A valid GPS accuracy reading is required."}, status=400)
    if not position:
        return JsonResponse({"error": "Invalid GPS position."}, status=400)
    job.live_latitude, job.live_longitude = position["lat"], position["lng"]
    job.live_accuracy, job.live_location_updated_at = accuracy, timezone.now()
    job.live_tracking_enabled = True
    job.save(update_fields=[
        "live_latitude", "live_longitude", "live_accuracy", "live_location_updated_at", "live_tracking_enabled"
    ])
    return JsonResponse({"success": True, "sharing": True})


# ==========================================
# CANCEL REQUEST
# ==========================================

@login_required
def cancel_request(request, request_id):

    if not _is_customer(request.user):
        return redirect("mechanic_dashboard")

    rescue_request = get_object_or_404(
        RescueRequest,
        id=request_id,
        customer=request.user
    )

    if rescue_request.status == "pending":

        rescue_request.status = "cancelled"

        rescue_request.save()

    return redirect("customer_dashboard")