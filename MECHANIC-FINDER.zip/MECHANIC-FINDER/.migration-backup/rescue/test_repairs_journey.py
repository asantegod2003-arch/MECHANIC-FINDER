from datetime import timedelta

from django.contrib.auth.models import User
from django.test import TestCase, Client
from django.urls import reverse
from django.utils import timezone

from accounts.models import Profile
from .models import RescueRequest, RepairEstimate, RepairReview


class RepairApprovalAndJourneyTests(TestCase):
    def setUp(self):
        self.customer = User.objects.create_user(username="repair-customer")
        self.mechanic = User.objects.create_user(username="repair-mechanic")
        self.stranger = User.objects.create_user(username="repair-stranger")
        for user, role in ((self.customer, "customer"), (self.mechanic, "mechanic"), (self.stranger, "customer")):
            Profile.objects.create(user=user, role=role)
        self.job = RescueRequest.objects.create(
            customer=self.customer, mechanic=self.mechanic, status="accepted",
            vehicle_problem="Tyre", location="Accra", phone_number="0000000000",
            customer_latitude=5.6, customer_longitude=-0.2,
            mechanic_latitude=5.7, mechanic_longitude=-0.3,
            mechanic_location_captured_at=timezone.now(),
        )
        self.detail = reverse("repair_detail", args=[self.job.pk])
        self.propose = reverse("create_estimate", args=[self.job.pk])
        self.journey = reverse("update_live_journey", args=[self.job.pk])
        self.poll = reverse("mechanic_location", args=[self.job.pk])
        self.client.force_login(self.mechanic)

    def test_assigned_mechanic_proposes_and_only_customer_can_decide(self):
        self.assertRedirects(self.client.post(self.propose, {"amount": "150.50", "description": "Parts and labour"}), self.detail)
        estimate = RepairEstimate.objects.get()
        decision = reverse("decide_estimate", args=[estimate.pk])
        self.assertEqual(self.client.post(decision, {"decision": "accept"}).status_code, 404)
        self.client.force_login(self.customer)
        self.assertRedirects(self.client.post(decision, {"decision": "accept"}), self.detail)
        estimate.refresh_from_db()
        self.assertEqual(estimate.status, "accepted")
        self.assertIsNotNone(estimate.decided_at)

    def test_replacement_preserves_quote_history_and_invalidates_old_proposal(self):
        self.client.post(self.propose, {"amount": "100", "description": "Initial work"})
        old = RepairEstimate.objects.get()
        self.client.post(self.propose, {"amount": "200", "description": "Updated work"})
        old.refresh_from_db()
        self.assertEqual(old.status, "superseded")
        self.assertEqual(RepairEstimate.objects.count(), 2)
        self.client.force_login(self.customer)
        self.client.post(reverse("decide_estimate", args=[old.pk]), {"decision": "accept"})
        old.refresh_from_db()
        self.assertEqual(old.status, "superseded")

    def test_invalid_prices_and_other_users_cannot_create_estimates(self):
        for amount in ("-1", "0", "NaN", "1.001"):
            self.assertEqual(self.client.post(self.propose, {"amount": amount, "description": "Work"}).status_code, 400)
        self.client.force_login(self.stranger)
        self.assertEqual(self.client.get(self.detail).status_code, 403)
        self.assertEqual(self.client.post(self.propose, {"amount": "100", "description": "Work"}).status_code, 404)
        self.assertEqual(RepairEstimate.objects.count(), 0)

    def test_completion_requires_latest_approved_estimate(self):
        self.job.status = "arrived"
        self.job.save()
        complete = reverse("complete_job", args=[self.job.pk])
        self.client.post(complete)
        self.job.refresh_from_db()
        self.assertEqual(self.job.status, "arrived")
        RepairEstimate.objects.create(job=self.job, description="Repair", amount=100, status="accepted")
        self.client.post(complete)
        self.job.refresh_from_db()
        self.assertEqual(self.job.status, "completed")
        self.assertEqual(self.client.get(complete).status_code, 405)

    def test_reviews_only_after_completion_and_one_editable_review_per_job(self):
        url = reverse("save_review", args=[self.job.pk])
        self.client.force_login(self.customer)
        self.client.post(url, {"rating": 5, "comment": "Helpful"})
        self.assertFalse(RepairReview.objects.exists())
        self.job.status = "completed"
        self.job.save()
        self.assertRedirects(self.client.post(url, {"rating": 5, "comment": "Helpful"}), self.detail)
        self.client.post(url, {"rating": 4, "comment": "Updated review"})
        self.assertEqual(RepairReview.objects.count(), 1)
        self.assertEqual(RepairReview.objects.get().rating, 4)
        self.client.force_login(self.mechanic)
        self.assertEqual(self.client.post(url, {"rating": 5}).status_code, 404)

    def test_review_rating_bounds_and_public_average(self):
        self.job.status = "completed"
        self.job.save()
        self.client.force_login(self.customer)
        url = reverse("save_review", args=[self.job.pk])
        for rating in (0, 6):
            self.assertEqual(self.client.post(url, {"rating": rating}).status_code, 400)
        self.client.post(url, {"rating": 4, "comment": "Real completed repair"})
        response = self.client.get(reverse("mechanic_detail", args=[self.mechanic.pk]))
        self.assertEqual(response.context["average_rating"], 4)
        self.assertEqual(response.context["review_count"], 1)
        self.assertContains(response, "Real completed repair")

    def test_live_position_is_separate_from_both_fixed_capture_pins(self):
        self.client.post(reverse("start_trip", args=[self.job.pk]))
        response = self.client.post(self.journey, {"latitude": 5.65, "longitude": -0.25, "accuracy": 8})
        self.assertEqual(response.status_code, 200)
        self.client.force_login(self.customer)
        data = self.client.get(self.poll).json()
        self.assertEqual(data["live"], {"lat": 5.65, "lng": -0.25})
        self.assertTrue(data["live_fresh"])
        self.assertEqual(data["latitude"], 5.7)
        self.assertEqual(data["customer"], {"lat": 5.6, "lng": -0.2})
        self.job.refresh_from_db()
        self.assertEqual(self.job.mechanic_latitude, 5.7)

    def test_live_sharing_cannot_be_started_before_trip_or_by_customer_or_stranger(self):
        payload = {"latitude": 5.65, "longitude": -0.25, "accuracy": 8}
        self.assertEqual(self.client.post(self.journey, payload).status_code, 400)
        self.client.force_login(self.customer)
        self.assertEqual(self.client.post(self.journey, payload).status_code, 404)
        self.client.force_login(self.stranger)
        self.assertEqual(self.client.get(self.poll).status_code, 403)

    def test_stop_arrival_and_staleness_never_expose_a_fresh_journey_point(self):
        self.job.status = "on_the_way"
        self.job.save()
        self.client.post(self.journey, {"latitude": 5.65, "longitude": -0.25, "accuracy": 8})
        self.job.refresh_from_db()
        self.job.live_location_updated_at = timezone.now() - timedelta(minutes=2)
        self.job.save()
        self.assertFalse(self.client.get(self.poll).json()["live_fresh"])
        self.client.post(self.journey, {"action": "stop"})
        self.assertIsNone(self.client.get(self.poll).json()["live"])
        self.client.post(self.journey, {"latitude": 5.65, "longitude": -0.25, "accuracy": 8})
        self.client.post(reverse("mark_arrived", args=[self.job.pk]))
        self.assertIsNone(self.client.get(self.poll).json()["live"])
        self.assertEqual(self.client.post(self.journey, {"latitude": 5.6, "longitude": 0, "accuracy": 5}).status_code, 400)

    def test_all_price_review_and_journey_actions_require_csrf_and_post(self):
        csrf = Client(enforce_csrf_checks=True)
        csrf.force_login(self.mechanic)
        self.assertEqual(csrf.post(self.propose, {"amount": "100", "description": "Work"}).status_code, 403)
        self.assertEqual(self.client.get(self.journey).status_code, 405)
        self.assertEqual(self.client.get(self.propose).status_code, 405)

    def test_pending_customer_can_open_repair_details_before_assignment(self):
        self.job.mechanic = None
        self.job.status = "pending"
        self.job.save()
        self.client.force_login(self.customer)
        self.assertEqual(self.client.get(self.detail).status_code, 200)
