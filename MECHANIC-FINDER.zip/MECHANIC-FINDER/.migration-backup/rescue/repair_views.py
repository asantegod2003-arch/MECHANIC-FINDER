from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from accounts.notifications import create_notification
from .models import RescueRequest, RepairEstimate, RepairReview
from .repair_forms import EstimateForm, ReviewForm


def _detail(request, job, estimate_form=None, review_form=None, status=200):
    if request.user.id not in (job.customer_id, job.mechanic_id):
        return HttpResponseForbidden("This repair is private.")
    estimates = list(job.estimates.all())
    review = RepairReview.objects.filter(job=job).first()
    return render(request, "rescue/repair_detail.html", {
        "job": job, "is_customer": request.user.id == job.customer_id,
        "is_mechanic": request.user.id == job.mechanic_id, "estimates": estimates,
        "latest_estimate": estimates[0] if estimates else None,
        "estimate_form": estimate_form if estimate_form is not None else EstimateForm(),
        "review_form": review_form if review_form is not None else ReviewForm(instance=review),
        "review": review,
    }, status=status)


@login_required
@require_GET
def repair_detail(request, request_id):
    return _detail(request, get_object_or_404(RescueRequest, pk=request_id))


@login_required
@require_POST
@transaction.atomic
def create_estimate(request, request_id):
    job = get_object_or_404(RescueRequest.objects.select_for_update(), pk=request_id, mechanic=request.user)
    if job.status not in ("accepted", "on_the_way", "arrived"):
        messages.error(request, "Estimates can only be sent for active accepted repairs.")
        return redirect("repair_detail", request_id=job.id)
    form = EstimateForm(request.POST)
    if not form.is_valid():
        return _detail(request, job, estimate_form=form, status=400)
    job.estimates.filter(status="proposed").update(status="superseded")
    estimate = form.save(commit=False)
    estimate.job = job
    estimate.save()
    create_notification(
        recipient=job.customer, title="Repair estimate ready",
        message=f"Your mechanic proposed GHS {estimate.amount}. Open the repair to approve or decline.",
        url=reverse("repair_detail", args=[job.id]),
    )
    messages.success(request, "Estimate sent. The customer must approve this price.")
    return redirect("repair_detail", request_id=job.id)


@login_required
@require_POST
@transaction.atomic
def decide_estimate(request, estimate_id):
    # All quote mutations lock the job first, so concurrent replacement/approval is serialized.
    estimate = get_object_or_404(RepairEstimate.objects.select_related("job"), pk=estimate_id, job__customer=request.user)
    job = RescueRequest.objects.select_for_update().get(pk=estimate.job_id)
    estimate.refresh_from_db()
    decision = request.POST.get("decision")
    if (
        decision not in ("accept", "decline") or estimate.status != "proposed"
        or job.estimates.first().pk != estimate.pk or job.status in ("completed", "cancelled")
    ):
        messages.error(request, "This estimate can no longer be changed. Review the latest proposal.")
        return redirect("repair_detail", request_id=job.id)
    estimate.status = "accepted" if decision == "accept" else "declined"
    estimate.decided_at = timezone.now()
    estimate.save(update_fields=["status", "decided_at"])
    create_notification(
        recipient=job.mechanic, title="Customer responded to your estimate",
        message=f"The customer {estimate.get_status_display().lower()} GHS {estimate.amount}.",
        url=reverse("repair_detail", args=[job.id]),
    )
    messages.success(request, "Your decision has been recorded.")
    return redirect("repair_detail", request_id=job.id)


@login_required
@require_POST
@transaction.atomic
def save_review(request, request_id):
    job = get_object_or_404(RescueRequest.objects.select_for_update(), pk=request_id, customer=request.user)
    if job.status != "completed" or not job.mechanic_id:
        messages.error(request, "Only completed repairs can be reviewed.")
        return redirect("repair_detail", request_id=job.id)
    review = RepairReview.objects.filter(job=job).first()
    form = ReviewForm(request.POST, instance=review)
    if not form.is_valid():
        return _detail(request, job, review_form=form, status=400)
    review = form.save(commit=False)
    review.job = job
    review.save()
    messages.success(request, "Your review has been saved.")
    return redirect("repair_detail", request_id=job.id)
