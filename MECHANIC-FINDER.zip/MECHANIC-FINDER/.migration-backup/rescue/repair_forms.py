from django import forms
from .models import RepairEstimate, RepairReview


class EstimateForm(forms.ModelForm):
    class Meta:
        model = RepairEstimate
        fields = ["description", "amount"]
        labels = {"amount": "Total price (GHS)", "description": "Repair work, parts and labour included"}
        widgets = {
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 4}),
            "amount": forms.NumberInput(attrs={"class": "form-control", "min": ".01", "step": ".01"}),
        }


class ReviewForm(forms.ModelForm):
    class Meta:
        model = RepairReview
        fields = ["rating", "comment"]
        widgets = {
            "rating": forms.Select(choices=[(n, f"{n} / 5") for n in range(1, 6)], attrs={"class": "form-select"}),
            "comment": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }
