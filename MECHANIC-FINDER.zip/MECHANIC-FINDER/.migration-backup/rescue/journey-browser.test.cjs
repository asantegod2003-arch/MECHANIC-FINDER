const {test} = require("node:test");
const assert = require("node:assert/strict");
const vm = require("node:vm");
const fs = require("node:fs");
const source = fs.readFileSync("mechanicfinder/static/journey-sharing.js", "utf8");

function page() {
    const elements = {};
    for (const id of ["start-journey-sharing", "stop-journey-sharing", "journey-capture-status"]) {
        elements[id] = {listeners: {}, addEventListener(type, fn) {this.listeners[type] = fn;}};
    }
    elements["tracking-data"] = {textContent: JSON.stringify({
        isMechanic: true, status: "on_the_way", journeyUrl: "/rescue/tracking/1/journey/",
    })};
    const calls = [];
    const intervals = [];
    const events = {};
    const state = {watch: null, cleared: false, freshGpsRequests: 0};
    const document = {
        currentScript: {dataset: {csrfToken: "test"}},
        getElementById: id => elements[id],
        addEventListener(type, fn) {events[type] = fn;},
        hidden: false,
    };
    vm.runInNewContext(source, {
        document, URLSearchParams, Date,
        window: {
            setInterval(fn) {intervals.push(fn); return 1;}, clearInterval() {},
            addEventListener(type, fn) {events[type] = fn;},
        },
        navigator: {geolocation: {
            watchPosition(success, error, options) {state.watch = {success, error, options}; return 1;},
            clearWatch() {state.cleared = true;},
            getCurrentPosition() {state.freshGpsRequests++;},
        }},
        fetch: async (url, options) => {
            calls.push({url, body: options.body.toString()});
            return {ok: true, redirected: false};
        },
    });
    return {elements, calls, state, intervals, events, document};
}

test("live journey is never captured automatically and requires the mechanic to start sharing", async () => {
    const p = page();
    assert.equal(p.state.watch, null);
    p.elements["start-journey-sharing"].listeners.click();
    assert.equal(p.state.watch.options.maximumAge, 0);
    await p.state.watch.success({coords: {latitude: 5.65, longitude: -0.25, accuracy: 8}});
    assert.match(p.calls[0].body, /latitude=5\.65/);
    assert.match(p.calls[0].url, /journey/);
    assert.doesNotMatch(p.calls[0].body, /mechanic_latitude|customer_latitude/);
    p.intervals[0]();
    assert.equal(p.state.freshGpsRequests, 1);
});

test("stop sharing clears GPS capture and tells the server", async () => {
    const p = page();
    p.elements["start-journey-sharing"].listeners.click();
    await p.elements["stop-journey-sharing"].listeners.click();
    assert.equal(p.state.cleared, true);
    assert.equal(p.calls.at(-1).body, "action=stop");
});

test("leaving or hiding the page stops location sharing", async () => {
    const p = page();
    p.elements["start-journey-sharing"].listeners.click();
    p.document.hidden = true;
    p.events.visibilitychange();
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(p.state.cleared, true);
    assert.equal(p.calls.at(-1).body, "action=stop");
});
