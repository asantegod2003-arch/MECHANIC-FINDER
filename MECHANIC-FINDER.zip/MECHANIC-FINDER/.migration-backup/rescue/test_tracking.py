from django.contrib.auth.models import User
from django.test import TestCase, override_settings
from django.utils import timezone

from accounts.models import Profile
from .models import RescueRequest
from .views import _coordinates


class TrackingLocationTests(TestCase):
    def setUp(self):
        self.customer = User.objects.create_user(username="tracking-customer")
        Profile.objects.create(user=self.customer, role="customer")
        self.mechanic = User.objects.create_user(username="tracking-mechanic")
        self.profile = Profile.objects.create(user=self.mechanic, role="mechanic")
        self.job = RescueRequest.objects.create(
            customer=self.customer, mechanic=self.mechanic, status="accepted",
            vehicle_problem="Battery", location="Accra", phone_number="0000000000",
        )
        self.client.force_login(self.customer)
        self.url = f"/rescue/tracking/{self.job.pk}/"
        self.location_url = self.url + "location/"
        self.customer_url = self.url + "customer-location/"

    @override_settings(GOOGLE_MAPS_API_KEY="")
    def test_map_has_key_free_google_fallback_and_null_customer_not_zero(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'id="tracking-embedded-map"')
        self.assertContains(response, "Use my current location")
        self.assertNotContains(response, "maps.googleapis.com/maps/api/js")
        self.assertIsNone(response.context["tracking_data"]["customer"])
        self.assertContains(response, '"customer": null')

    @override_settings(GOOGLE_MAPS_API_KEY="test-placeholder")
    def test_configured_live_map_can_still_fall_back(self):
        response = self.client.get(self.url)
        self.assertContains(response, "callback=initRescueMap")
        self.assertContains(response, "useEmbeddedRescueMap")
        self.assertContains(response, 'id="tracking-embedded-map"')

    def test_missing_positions_are_returned_as_null(self):
        data = self.client.get(self.location_url).json()
        self.assertIsNone(data["latitude"])
        self.assertIsNone(data["longitude"])
        self.assertIsNone(data["customer"])

    def test_request_coordinates_used_if_profile_has_no_gps(self):
        self.job.mechanic_latitude = 5.61
        self.job.mechanic_longitude = -0.18
        self.job.save()
        data = self.client.get(self.location_url).json()
        self.assertEqual(data["latitude"], 5.61)
        self.assertEqual(data["longitude"], -0.18)
        self.assertIsNone(data["location_updated_at"])

    def test_profile_location_never_substitutes_for_missing_acceptance_capture(self):
        self.profile.latitude = 5.62
        self.profile.longitude = -0.19
        self.profile.location_updated_at = timezone.now()
        self.profile.save()
        data = self.client.get(self.location_url).json()
        self.assertIsNone(data["latitude"])
        self.assertIsNone(data["longitude"])
        self.assertIsNone(data["location_updated_at"])

    def test_customer_can_share_location_and_mechanic_receives_it(self):
        response = self.client.post(self.customer_url, {"latitude": 5.60, "longitude": -0.20})
        self.assertEqual(response.status_code, 200)
        self.job.refresh_from_db()
        self.assertEqual(self.job.customer_latitude, 5.60)
        self.client.force_login(self.mechanic)
        data = self.client.get(self.location_url).json()
        self.assertEqual(data["customer"], {"lat": 5.60, "lng": -0.20})

    def test_other_users_cannot_read_or_change_private_locations(self):
        stranger = User.objects.create_user(username="tracking-stranger")
        self.client.force_login(stranger)
        self.assertEqual(self.client.get(self.url).status_code, 403)
        self.assertEqual(self.client.get(self.location_url).status_code, 403)
        self.assertEqual(self.client.post(
            self.customer_url, {"latitude": 5, "longitude": 0}
        ).status_code, 404)
        self.client.force_login(self.mechanic)
        self.assertEqual(self.client.post(
            self.customer_url, {"latitude": 5, "longitude": 0}
        ).status_code, 404)

    def test_invalid_or_missing_coordinates_are_rejected(self):
        for latitude, longitude in [
            ("", ""), ("nan", "0"), ("inf", "0"), ("91", "0"), ("0", "-181"),
        ]:
            response = self.client.post(self.customer_url, {
                "latitude": latitude, "longitude": longitude,
            })
            self.assertEqual(response.status_code, 400)
        self.job.refresh_from_db()
        self.assertIsNone(self.job.customer_latitude)
        self.assertIsNone(self.job.customer_longitude)
        self.assertIsNone(_coordinates(None, None))
        self.assertIsNone(_coordinates("", ""))
        self.assertEqual(_coordinates(0, 0), {"lat": 0.0, "lng": 0.0})

    def test_closed_job_cannot_have_location_changed(self):
        for status in ("completed", "cancelled"):
            self.job.status = status
            self.job.save()
            self.assertEqual(self.client.post(self.customer_url, {
                "latitude": 5.6, "longitude": -0.2,
            }).status_code, 400)

    def test_customer_location_endpoint_requires_login_and_post(self):
        self.assertEqual(self.client.get(self.customer_url).status_code, 405)
        self.client.logout()
        self.assertEqual(self.client.post(self.customer_url).status_code, 302)

    def test_request_and_acceptance_capture_fresh_coordinates_for_this_job(self):
        response = self.client.post("/rescue/create/", {
            "vehicle_problem": "Flat tyre", "location": "Accra",
            "phone_number": "0000000000",
            "customer_latitude": "5.603717", "customer_longitude": "-0.187023",
            "customer_location_accuracy": "7",
        })
        self.assertEqual(response.status_code, 302)
        job = RescueRequest.objects.exclude(pk=self.job.pk).get()
        self.assertEqual(job.customer_latitude, 5.603717)
        self.assertEqual(job.customer_longitude, -0.187023)
        self.assertEqual(job.customer_location_accuracy, 7)
        self.assertIsNotNone(job.customer_location_captured_at)
        self.profile.available = True
        self.profile.latitude, self.profile.longitude = 8, -2
        self.profile.save()
        self.client.force_login(self.mechanic)
        response = self.client.post(f"/rescue/accept/{job.pk}/", {
            "latitude": "5.617432", "longitude": "-0.193456", "accuracy": "9",
        })
        self.assertEqual(response.status_code, 302)
        job.refresh_from_db()
        self.assertEqual(job.mechanic_latitude, 5.617432)
        self.assertEqual(job.mechanic_longitude, -0.193456)
        self.assertEqual(job.mechanic_location_accuracy, 9)
        self.assertIsNotNone(job.mechanic_location_captured_at)
        data = self.client.get(f"/rescue/tracking/{job.pk}/location/").json()
        self.assertEqual(data["latitude"], 5.617432)
        self.assertEqual(data["customer"], {"lat": 5.603717, "lng": -0.187023})

    def test_presence_movement_does_not_change_mechanic_acceptance_snapshot(self):
        self.job.mechanic_latitude, self.job.mechanic_longitude = 5.6, -0.2
        self.job.mechanic_location_captured_at = timezone.now()
        self.job.save()
        captured_at = self.job.mechanic_location_captured_at
        self.client.force_login(self.mechanic)
        response = self.client.post(f"/rescue/update-location/{self.job.pk}/", {
            "latitude": "6.9", "longitude": "-1.6",
        })
        self.assertEqual(response.status_code, 200)
        self.profile.refresh_from_db()
        self.assertEqual(self.profile.latitude, 6.9)
        self.job.refresh_from_db()
        self.assertEqual(self.job.mechanic_latitude, 5.6)
        self.assertEqual(self.job.mechanic_longitude, -0.2)
        self.assertEqual(self.job.mechanic_location_captured_at, captured_at)
        data = self.client.get(self.location_url).json()
        self.assertEqual(data["latitude"], 5.6)
        self.assertEqual(data["longitude"], -0.2)

    def test_customer_request_position_cannot_be_overwritten_later(self):
        self.job.customer_latitude, self.job.customer_longitude = 5.6, -0.2
        self.job.save()
        response = self.client.post(self.customer_url, {"latitude": 7, "longitude": -1})
        self.assertEqual(response.status_code, 409)
        self.job.refresh_from_db()
        self.assertEqual(self.job.customer_latitude, 5.6)
        self.assertEqual(self.job.customer_longitude, -0.2)
        self.assertNotContains(self.client.get(self.url), 'id="share-customer-location"')

    def test_new_request_cannot_be_submitted_without_valid_gps(self):
        for latitude, longitude in (("", ""), ("nan", "0"), ("91", "0")):
            response = self.client.post("/rescue/create/", {
                "vehicle_problem": "Flat tyre", "location": "Accra",
                "phone_number": "0000000000",
                "customer_latitude": latitude, "customer_longitude": longitude,
            })
            self.assertEqual(response.status_code, 200)
        self.assertEqual(RescueRequest.objects.count(), 1)

    def test_acceptance_requires_post_fresh_gps_and_preserves_winning_capture(self):
        self.job.mechanic = None
        self.job.status = "pending"
        self.job.save()
        self.profile.available = True
        self.profile.save()
        self.client.force_login(self.mechanic)
        url = f"/rescue/accept/{self.job.pk}/"
        self.assertEqual(self.client.get(url).status_code, 405)
        for data in ({}, {"latitude": "nan", "longitude": 0}, {"latitude": 5, "longitude": 190}):
            self.assertEqual(self.client.post(url, data).status_code, 302)
            self.job.refresh_from_db()
            self.assertEqual(self.job.status, "pending")
        self.assertEqual(self.client.post(url, {"latitude": 5.6, "longitude": -0.2}).status_code, 302)
        self.assertEqual(self.client.post(url, {"latitude": 6.5, "longitude": -1.5}).status_code, 404)
        self.job.refresh_from_db()
        self.assertEqual(self.job.mechanic_latitude, 5.6)

    def test_dashboard_acceptance_uses_gps_post_not_a_get_link(self):
        self.job.mechanic = None
        self.job.status = "pending"
        self.job.save()
        self.profile.available = True
        self.profile.save()
        self.client.force_login(self.mechanic)
        response = self.client.get("/mechanic/dashboard/")
        self.assertContains(response, f'action="/rescue/accept/{self.job.pk}/"')
        self.assertContains(response, "data-capture-gps")
        self.assertNotContains(response, f'href="/rescue/accept/{self.job.pk}/"')
