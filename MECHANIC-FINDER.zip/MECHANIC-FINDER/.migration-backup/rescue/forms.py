from django import forms
from .models import RescueRequest
import math


class RescueRequestForm(forms.ModelForm):
    customer_latitude = forms.FloatField(
        required=True, min_value=-90, max_value=90, widget=forms.HiddenInput(),
        error_messages={"required": "Allow location access so your request includes your GPS position."},
    )
    customer_longitude = forms.FloatField(
        required=True, min_value=-180, max_value=180, widget=forms.HiddenInput(),
        error_messages={"required": "Your GPS longitude is missing. Please capture your location again."},
    )

    def clean(self):
        data = super().clean()
        for name in ("customer_latitude", "customer_longitude", "customer_location_accuracy"):
            value = data.get(name)
            if value is not None and (not math.isfinite(value) or (name.endswith("accuracy") and value < 0)):
                self.add_error(name, "Capture a valid GPS location again.")
        return data

    class Meta:
        model = RescueRequest

        fields = [
            "vehicle_problem",
            "location",
            "phone_number",
            "customer_latitude",
            "customer_longitude",
            "customer_location_accuracy",
        ]

        widgets = {
            "vehicle_problem": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "e.g. Flat tyre, Engine won't start",
                }
            ),

            "location": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Town, landmark or street",
                }
            ),

            "phone_number": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "e.g. 0241234567",
                }
            ),

            "customer_latitude": forms.HiddenInput(),
            "customer_longitude": forms.HiddenInput(),
            "customer_location_accuracy": forms.HiddenInput(),
        }