const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const source = fs.readFileSync("mechanicfinder/static/rescue-tracking.js", "utf8");

async function page(customer, payload, overrides = {}) {
    const elements = new Map();
    const element = id => {
        if (!elements.has(id)) elements.set(id, {
            hidden: false, disabled: false, textContent: "", dataset: {}, listeners: {},
            setAttribute(key, value) { this[key] = value; },
            removeAttribute(key) { delete this[key]; },
            addEventListener(type, callback) { this.listeners[type] = callback; },
        });
        return elements.get(id);
    };
    element("tracking-data").textContent = JSON.stringify({
        customer, pollUrl: "/poll/", customerLocationUrl: "/customer-location/",
    });
    const window = {
        location: {pathname: "/tracking/1/", assign() {}}, setInterval() {},
    };
    const context = {
        document: {
            currentScript: {dataset: {csrfToken: "test"}},
            getElementById: element, hidden: false,
        },
        window, navigator: {}, URLSearchParams, Date, console,
        fetch: async () => ({ok: true, json: async () => payload}),
        ...overrides,
    };
    vm.runInNewContext(source, context);
    await new Promise(resolve => setImmediate(resolve));
    return {element, window};
}

test("missing GPS does not create a zero-degree iframe or link", async () => {
    const {element} = await page(null, {
        success: true, latitude: null, longitude: null, customer: null, status: "accepted",
    });
    assert.equal(element("tracking-embedded-map").hidden, true);
    assert.equal(element("tracking-embedded-map").src, undefined);
    assert.equal(element("customer-map-link").hidden, true);
    assert.match(element("tracking-status").textContent, /No mechanic acceptance GPS/);
});

test("valid mechanic GPS loads embedded Google map with no API dependency", async () => {
    const {element, window} = await page(null, {
        success: true, latitude: 5.61, longitude: -0.18, customer: null,
        location_updated_at: new Date().toISOString(), status: "accepted",
    });
    assert.match(element("tracking-embedded-map").src, /q=5\.61%2C-0\.18/);
    assert.equal(element("tracking-embedded-map").hidden, false);
    assert.match(element("tracking-status").textContent, /captured at acceptance/);
    window.gm_authFailure();
    assert.equal(element("map").hidden, true);
    assert.match(element("map-notice").textContent, /could not authorize/);
    assert.match(element("tracking-embedded-map").src, /q=5\.61%2C-0\.18/);
});

test("customer and mechanic switches show their actual pins and directions", async () => {
    const customer = {lat: 5.6, lng: -0.2};
    const {element} = await page(customer, {
        success: true, latitude: 5.61, longitude: -0.18, customer, status: "on_the_way",
    });
    element("show-mechanic").listeners.click();
    assert.match(element("tracking-embedded-map").src, /q=5\.61%2C-0\.18/);
    element("show-customer").listeners.click();
    assert.match(element("tracking-embedded-map").src, /q=5\.6%2C-0\.2/);
    assert.match(element("directions-link").href, /origin=5\.61%2C-0\.18&destination=5\.6%2C-0\.2/);
    assert.match(element("tracking-status").textContent, /older job/);
});

test("out-of-range mechanic coordinates never load an invalid map", async () => {
    const {element} = await page(null, {
        success: true, latitude: 100, longitude: 500, customer: null, status: "accepted",
    });
    assert.equal(element("tracking-embedded-map").src, undefined);
    assert.equal(element("mechanic-map-link").hidden, true);
});

test("network failure is shown rather than claiming a successful update", async () => {
    const {element} = await page(null, null, {
        fetch: async () => { throw new Error("offline"); },
    });
    assert.match(element("tracking-status").textContent, /Could not refresh request details/);
});

test("live journey marker is separate and cannot replace captured request/acceptance pins", async () => {
    const customer = {lat: 5.6, lng: -0.2};
    const {element} = await page(customer, {
        success: true, latitude: 5.7, longitude: -0.3, customer, status: "on_the_way",
        live: {lat: 5.65, lng: -0.25}, live_sharing: true, live_fresh: true,
        live_updated_at: new Date().toISOString(), live_accuracy: 8,
    });
    element("show-live").listeners.click();
    assert.match(element("tracking-embedded-map").src, /q=5\.65%2C-0\.25/);
    assert.match(element("map-caption").textContent, /Live mechanic journey/);
    element("show-mechanic").listeners.click();
    assert.match(element("tracking-embedded-map").src, /q=5\.7%2C-0\.3/);
    element("show-customer").listeners.click();
    assert.match(element("tracking-embedded-map").src, /q=5\.6%2C-0\.2/);
});

test("stale live GPS is not shown as a current journey pin", async () => {
    const {element} = await page(null, {
        success: true, latitude: 5.7, longitude: -0.3, customer: null, status: "on_the_way",
        live: {lat: 5.65, lng: -0.25}, live_sharing: true, live_fresh: false,
    });
    assert.equal(element("show-live").disabled, true);
    assert.equal(element("live-map-link").hidden, true);
    assert.match(element("journey-status").textContent, /paused/);
});
