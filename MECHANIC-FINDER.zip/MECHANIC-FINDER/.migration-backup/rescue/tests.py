from django.test import TestCase
from django.contrib.auth.models import User

from accounts.models import Profile
from accounts.models import Notification
from accounts.notifications import notify_nearby_mechanics
from .models import RescueRequest
from django.utils import timezone


class RescueRequestLocationPreviewTests(TestCase):
    def test_customer_sees_location_preview_before_sending_request(self):
        customer = User.objects.create_user(
            username="mobile-customer",
            password="test-password-123",
        )
        Profile.objects.create(user=customer, role="customer")
        self.client.force_login(customer)

        response = self.client.get("/rescue/create/")

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Use my location")
        self.assertContains(response, 'id="location-map"')
        self.assertContains(response, "https://www.google.com/maps?q=")


class NearbyMechanicNotificationTests(TestCase):
    def test_only_available_mechanics_within_25_km_are_notified(self):
        from django.contrib.auth.models import User

        nearby = User.objects.create_user(username="nearby")
        Profile.objects.create(
            user=nearby,
            role="mechanic",
            available=True,
            latitude=5.61,
            longitude=-0.18,
            location_updated_at=timezone.now(),
        )
        far_away = User.objects.create_user(username="far-away")
        Profile.objects.create(
            user=far_away,
            role="mechanic",
            available=True,
            latitude=0,
            longitude=0,
            location_updated_at=timezone.now(),
        )
        offline = User.objects.create_user(username="offline")
        Profile.objects.create(
            user=offline,
            role="mechanic",
            available=False,
            latitude=5.60,
            longitude=-0.18,
            location_updated_at=timezone.now(),
        )
        customer = User.objects.create_user(username="requester")
        Profile.objects.create(user=customer, role="customer")
        rescue_request = RescueRequest.objects.create(
            customer=customer,
            vehicle_problem="Flat tyre",
            location="Accra",
            phone_number="0240000000",
            customer_latitude=5.60,
            customer_longitude=-0.18,
        )

        notified_count = notify_nearby_mechanics(rescue_request)

        self.assertEqual(notified_count, 1)
        self.assertEqual(nearby.app_notifications.count(), 1)
        self.assertEqual(far_away.app_notifications.count(), 0)
        self.assertEqual(offline.app_notifications.count(), 0)

    def test_accepting_request_notifies_customer(self):
        from django.contrib.auth.models import User

        customer = User.objects.create_user(username="accept-customer")
        Profile.objects.create(user=customer, role="customer")
        mechanic = User.objects.create_user(username="accept-mechanic")
        Profile.objects.create(user=mechanic, role="mechanic", available=True)
        rescue_request = RescueRequest.objects.create(
            customer=customer,
            vehicle_problem="Battery issue",
            location="Accra",
            phone_number="0240000000",
        )
        self.client.force_login(mechanic)

        response = self.client.post(f"/rescue/accept/{rescue_request.id}/", {
            "latitude": 5.6, "longitude": -0.18, "accuracy": 8,
        })

        self.assertEqual(response.status_code, 302)
        rescue_request.refresh_from_db()
        self.assertEqual(rescue_request.mechanic, mechanic)
        self.assertTrue(
            customer.app_notifications.filter(
                title="Your rescue request was accepted"
            ).exists()
        )
