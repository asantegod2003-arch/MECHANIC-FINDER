from django.contrib import admin
from .models import RescueRequest, RepairReview, RepairEstimate


@admin.register(RescueRequest)
class RescueRequestAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "customer",
        "mechanic",
        "vehicle_problem",
        "location",
        "status",
        "created_at",
    )
    list_filter = ("status", "created_at")
    search_fields = (
        "customer__username",
        "mechanic__username",
        "location",
        "vehicle_problem",
        "phone_number",
    )


@admin.register(RepairReview)
class RepairReviewAdmin(admin.ModelAdmin):
    list_display = ["job", "rating", "created_at"]
    readonly_fields = ["job", "rating", "comment", "created_at", "updated_at"]

    def has_add_permission(self, request):
        return False


@admin.register(RepairEstimate)
class RepairEstimateAdmin(admin.ModelAdmin):
    list_display = ["job", "amount", "currency", "status", "created_at"]
    readonly_fields = ["job", "amount", "currency", "description", "status", "created_at", "decided_at"]

    def has_add_permission(self, request):
        return False
