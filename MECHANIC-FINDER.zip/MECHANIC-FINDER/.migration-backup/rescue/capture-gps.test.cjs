const {test} = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const script = fs.readFileSync("mechanicfinder/static/capture-request-gps.js", "utf8");

function setup({fail = false, customer = false} = {}) {
    let submitted = 0, options;
    const names = customer ? ["customer_latitude", "customer_longitude", "customer_location_accuracy"] :
        ["latitude", "longitude", "accuracy"];
    const fields = Object.fromEntries(names.map(name => [name, {value: ""}]));
    const button = {disabled: false};
    const status = {textContent: ""};
    const form = {
        dataset: customer ? {
            gpsStatus: "status", latitudeField: names[0], longitudeField: names[1], accuracyField: names[2],
        } : {gpsStatus: "status"},
        elements: {namedItem: name => fields[name]},
        querySelector: () => button,
        addEventListener(type, callback) {this.submitHandler = callback;},
    };
    vm.runInNewContext(script, {
        document: {querySelectorAll: () => [form], getElementById: () => status},
        HTMLFormElement: {prototype: {submit() {submitted++;}}},
        navigator: {geolocation: {getCurrentPosition(success, error, config) {
            options = config;
            if (fail) error({code: 1});
            else success({coords: {latitude: 5.603717, longitude: -0.187023, accuracy: 8}});
        }}},
    });
    form.submitHandler({preventDefault() {}});
    return {submitted, options, fields, button, status};
}

test("submission and acceptance save the actual fresh device coordinates", () => {
    for (const customer of [true, false]) {
        const result = setup({customer});
        assert.equal(result.submitted, 1);
        assert.equal(result.options.maximumAge, 0);
        assert.equal(result.options.enableHighAccuracy, true);
        assert.equal(result.fields[customer ? "customer_latitude" : "latitude"].value, 5.603717);
        assert.equal(result.fields[customer ? "customer_longitude" : "longitude"].value, -0.187023);
        assert.equal(result.fields[customer ? "customer_location_accuracy" : "accuracy"].value, 8);
    }
});

test("denied GPS never submits or accepts a request with stale or invented coordinates", () => {
    const result = setup({fail: true});
    assert.equal(result.submitted, 0);
    assert.equal(result.button.disabled, false);
    assert.match(result.status.textContent, /permission is blocked/);
    assert.equal(result.fields.latitude.value, "");
});
