from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("rescue", "0004_alter_rescuerequest_location")]
    operations = [
        migrations.AddField(
            model_name="rescuerequest", name="customer_location_captured_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="rescuerequest", name="mechanic_location_captured_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="rescuerequest", name="customer_location_accuracy",
            field=models.FloatField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="rescuerequest", name="mechanic_location_accuracy",
            field=models.FloatField(blank=True, null=True),
        ),
    ]
