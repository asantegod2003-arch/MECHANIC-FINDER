from decimal import Decimal
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [("rescue", "0005_rescuerequest_location_capture")]
    operations = [
        migrations.AddField(model_name="rescuerequest", name="live_tracking_enabled", field=models.BooleanField(default=False)),
        migrations.AddField(model_name="rescuerequest", name="live_latitude", field=models.FloatField(blank=True, null=True)),
        migrations.AddField(model_name="rescuerequest", name="live_longitude", field=models.FloatField(blank=True, null=True)),
        migrations.AddField(model_name="rescuerequest", name="live_accuracy", field=models.FloatField(blank=True, null=True)),
        migrations.AddField(model_name="rescuerequest", name="live_location_updated_at", field=models.DateTimeField(blank=True, null=True)),
        migrations.CreateModel(
            name="RepairEstimate",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("description", models.TextField(max_length=2000)),
                ("amount", models.DecimalField(decimal_places=2, max_digits=10, validators=[MinValueValidator(Decimal("0.01"))])),
                ("currency", models.CharField(default="GHS", editable=False, max_length=3)),
                ("status", models.CharField(choices=[
                    ("proposed", "Awaiting customer approval"), ("accepted", "Approved"),
                    ("declined", "Declined"), ("superseded", "Replaced by a newer estimate"),
                ], default="proposed", max_length=12)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("decided_at", models.DateTimeField(blank=True, null=True)),
                ("job", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="estimates", to="rescue.rescuerequest")),
            ],
            options={"ordering": ["-id"], "constraints": [
                models.CheckConstraint(condition=models.Q(amount__gt=0), name="estimate_amount_positive"),
            ]},
        ),
        migrations.CreateModel(
            name="RepairReview",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("rating", models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])),
                ("comment", models.TextField(blank=True, max_length=1000)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("job", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name="review", to="rescue.rescuerequest")),
            ],
            options={"ordering": ["-created_at"], "constraints": [
                models.CheckConstraint(condition=models.Q(rating__gte=1, rating__lte=5), name="review_rating_one_to_five"),
            ]},
        ),
    ]
