from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from decimal import Decimal


class RescueRequest(models.Model):

    STATUS_CHOICES = (

        ("pending", "Pending"),

        ("accepted", "Accepted"),

        ("on_the_way", "On The Way"),

        ("arrived", "Arrived"),

        ("completed", "Completed"),

        ("cancelled", "Cancelled"),

    )


    customer = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="rescue_requests"
    )


    mechanic = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="assigned_jobs"
    )


    vehicle_problem = models.CharField(
        max_length=200
    )


   
    location = models.CharField(
    max_length=255,
    help_text="Town, landmark or street"
)


    phone_number = models.CharField(
        max_length=20
    )


    # ==========================
    # GPS LOCATION
    # ==========================

    customer_latitude = models.FloatField(
        null=True,
        blank=True
    )

    customer_longitude = models.FloatField(
        null=True,
        blank=True
    )

    mechanic_latitude = models.FloatField(
        null=True,
        blank=True
    )

    mechanic_longitude = models.FloatField(
        null=True,
        blank=True
    )

    customer_location_captured_at = models.DateTimeField(null=True, blank=True)
    mechanic_location_captured_at = models.DateTimeField(null=True, blank=True)
    customer_location_accuracy = models.FloatField(null=True, blank=True)
    mechanic_location_accuracy = models.FloatField(null=True, blank=True)
    live_tracking_enabled = models.BooleanField(default=False)
    live_latitude = models.FloatField(null=True, blank=True)
    live_longitude = models.FloatField(null=True, blank=True)
    live_accuracy = models.FloatField(null=True, blank=True)
    live_location_updated_at = models.DateTimeField(null=True, blank=True)

    # ==========================
    # STATUS
    # ==========================

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="pending"
    )


    created_at = models.DateTimeField(
        auto_now_add=True
    )


    updated_at = models.DateTimeField(
        auto_now=True
    )


    def __str__(self):
        return f"{self.customer.username} - {self.status}"


class RepairEstimate(models.Model):
    job = models.ForeignKey(RescueRequest, on_delete=models.CASCADE, related_name="estimates")
    description = models.TextField(max_length=2000)
    amount = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    currency = models.CharField(max_length=3, default="GHS", editable=False)
    status = models.CharField(max_length=12, default="proposed", choices=[
        ("proposed", "Awaiting customer approval"), ("accepted", "Approved"),
        ("declined", "Declined"), ("superseded", "Replaced by a newer estimate"),
    ])
    created_at = models.DateTimeField(auto_now_add=True)
    decided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-id"]
        constraints = [models.CheckConstraint(condition=models.Q(amount__gt=0), name="estimate_amount_positive")]


class RepairReview(models.Model):
    job = models.OneToOneField(RescueRequest, on_delete=models.CASCADE, related_name="review")
    rating = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField(max_length=1000, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        constraints = [models.CheckConstraint(
            condition=models.Q(rating__gte=1, rating__lte=5), name="review_rating_one_to_five"
        )]