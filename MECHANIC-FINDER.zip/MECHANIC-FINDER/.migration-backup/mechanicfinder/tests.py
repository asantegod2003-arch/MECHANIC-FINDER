from xml.etree import ElementTree
import tomllib

from django.conf import settings
from django.contrib.staticfiles import finders
from django.test import TestCase


class PublicDiscoveryTests(TestCase):
    def test_production_startup_does_not_repeat_managed_schema_migrations(self):
        with (settings.BASE_DIR / ".replit").open("rb") as config_file:
            deployment = tomllib.load(config_file)["deployment"]
        command = " ".join(deployment["run"])
        self.assertNotIn("manage.py migrate", command)
        self.assertIn("gunicorn", command)
        self.assertIn("DJANGO_DEBUG=False", command)

    def test_homepage_has_brand_metadata_and_replacement_image(self):
        response = self.client.get("/")
        self.assertContains(response, "Mechanic Finder Ghana")
        self.assertContains(response, 'name="robots" content="index, follow"')
        self.assertContains(response, f'rel="canonical" href="{settings.PUBLIC_SITE_URL}/"')
        self.assertContains(response, "/static/images/hero.jpg")
        self.assertContains(response, "/static/images/favicon-96.png")
        self.assertNotContains(response, "images/hero.png")

    def test_signup_is_not_a_search_landing_page(self):
        response = self.client.get("/signup/")
        self.assertContains(response, 'name="robots" content="noindex, nofollow"')

    def test_sitemap_contains_only_public_landing_pages(self):
        response = self.client.get("/sitemap.xml")
        self.assertEqual(response.status_code, 200)
        root = ElementTree.fromstring(response.content)
        locations = [
            node.text
            for node in root.findall("{http://www.sitemaps.org/schemas/sitemap/0.9}url/"
                                     "{http://www.sitemaps.org/schemas/sitemap/0.9}loc")
        ]
        self.assertEqual(locations, [
            settings.PUBLIC_SITE_URL + "/",
            settings.PUBLIC_SITE_URL + "/mechanics/",
        ])

    def test_robots_lists_public_sitemap(self):
        response = self.client.get("/robots.txt")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, f"Sitemap: {settings.PUBLIC_SITE_URL}/sitemap.xml")

    def test_brand_assets_exist_and_root_favicon_resolves(self):
        for asset in ("hero.jpg", "app-icon.svg", "favicon-96.png",
                      "apple-touch-icon.png", "favicon.ico"):
            with self.subTest(asset=asset):
                self.assertIsNotNone(finders.find("images/" + asset))
        self.assertRedirects(
            self.client.get("/favicon.ico"),
            "/static/images/favicon.ico",
            status_code=301,
            fetch_redirect_response=False,
        )
