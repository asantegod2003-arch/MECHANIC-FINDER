from django.conf import settings


def google_maps_api(request):
    return {
        "GOOGLE_MAPS_API_KEY": settings.GOOGLE_MAPS_API_KEY,
        "PUBLIC_SITE_URL": settings.PUBLIC_SITE_URL,
        "CANONICAL_URL": settings.PUBLIC_SITE_URL + request.path,
        "PAGE_ROBOTS": (
            "index, follow" if request.path in ("/", "/mechanics/")
            else "noindex, nofollow"
        ),
    }