from xml.sax.saxutils import escape

from django.conf import settings
from django.http import HttpResponse
from django.urls import reverse


def robots_txt(request):
    lines = [
        "User-agent: *",
        "Allow: /",
        "Disallow: /admin/",
        "Disallow: /login/",
        "Disallow: /signup/",
        "Disallow: /customer/",
        "Disallow: /mechanic/",
        "Disallow: /rescue/",
        "Disallow: /chat/",
        "Disallow: /notifications/",
        f"Sitemap: {settings.PUBLIC_SITE_URL}/sitemap.xml",
    ]
    return HttpResponse("\n".join(lines) + "\n", content_type="text/plain")


def sitemap_xml(request):
    locations = [
        settings.PUBLIC_SITE_URL + reverse(name)
        for name in ("home", "mechanic_directory")
    ]
    entries = "".join(f"<url><loc>{escape(url)}</loc></url>" for url in locations)
    return HttpResponse(
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        + entries + "</urlset>",
        content_type="application/xml",
    )
