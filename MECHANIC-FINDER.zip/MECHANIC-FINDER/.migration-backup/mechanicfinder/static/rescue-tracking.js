/* Missing GPS must stay missing; background polling never invents a location. */
(() => {
    const script = document.currentScript;
    const config = JSON.parse(document.getElementById("tracking-data").textContent);
    const get = id => document.getElementById(id);
    let customer = validPosition(config.customer);
    let mechanic = null;
    let liveMechanic = null;
    let selected = customer ? "customer" : "mechanic";
    let map = null;
    let markers = {};
    let embedded = true;
    let embedPosition = "";
    let lastEmbedUpdate = 0;
    let polling = false;
    let authFailed = false;
    let directionsService = null;
    let directionsRenderer = null;
    let lastRoute = "";
    let lastRouteUpdate = 0;

    function validPosition(value) {
        if (!value || value.lat === null || value.lng === null ||
            value.lat === "" || value.lng === "" ||
            value.lat === undefined || value.lng === undefined) return null;
        const lat = Number(value.lat), lng = Number(value.lng);
        return Number.isFinite(lat) && Number.isFinite(lng) &&
            Math.abs(lat) <= 90 && Math.abs(lng) <= 180 ? {lat, lng} : null;
    }
    const coordinates = position => `${position.lat},${position.lng}`;
    function setLink(id, position) {
        const link = get(id);
        link.hidden = !position;
        if (position) link.href = "https://www.google.com/maps/search/?api=1&query=" +
            encodeURIComponent(coordinates(position));
        else link.removeAttribute("href");
    }
    function render(force = false) {
        setLink("customer-map-link", customer);
        setLink("mechanic-map-link", mechanic);
        setLink("live-map-link", liveMechanic);
        const routeOrigin = selected === "live" ? liveMechanic : mechanic;
        get("directions-link").hidden = !(customer && routeOrigin);
        if (customer && routeOrigin) {
            get("directions-link").href = "https://www.google.com/maps/dir/?api=1&origin=" +
                encodeURIComponent(coordinates(routeOrigin)) + "&destination=" +
                encodeURIComponent(coordinates(customer)) + "&travelmode=driving";
        }
        get("show-customer").disabled = !customer;
        get("show-mechanic").disabled = !mechanic;
        get("show-live").disabled = !liveMechanic;
        get("customer-location-status").textContent = customer ?
            "The customer’s saved request location is available." :
            "No customer GPS location has been shared yet. No estimated pin will be shown.";
        if (!embedded && map) {
            const bounds = new google.maps.LatLngBounds();
            for (const [name, position] of Object.entries({customer, mechanic, live: liveMechanic})) {
                if (!position) {
                    if (markers[name]) markers[name].setMap(null);
                    continue;
                }
                if (!markers[name]) {
                    markers[name] = new google.maps.Marker({
                        map, position,
                        title: name === "customer" ? "Customer request capture" :
                            name === "mechanic" ? "Mechanic acceptance capture" : "Live mechanic journey",
                        label: name === "customer" ? "C" : name === "mechanic" ? "M" : "L",
                    });
                } else {
                    markers[name].setMap(map);
                    markers[name].setPosition(position);
                }
                bounds.extend(position);
            }
            if (customer || mechanic) {
                if ((customer && mechanic) || liveMechanic) map.fitBounds(bounds, 50);
                else { map.setCenter(customer || mechanic); map.setZoom(15); }
            }
            if (customer && routeOrigin && directionsService) {
                const routeKey = coordinates(routeOrigin) + ":" + coordinates(customer);
                if (routeKey !== lastRoute && Date.now() - lastRouteUpdate >= 30000) {
                    lastRoute = routeKey;
                    lastRouteUpdate = Date.now();
                    directionsService.route({
                        origin: routeOrigin, destination: customer, travelMode: "DRIVING",
                    }, (result, status) => {
                        if (status === "OK" && !embedded) {
                            directionsRenderer.setDirections(result);
                        } else if (!embedded) {
                            get("map-notice").textContent =
                                "GPS pins are available. In-map routing is unavailable; use the driving directions link below.";
                        }
                    });
                }
            }
            return;
        }
        let position = selected === "customer" ? customer : selected === "live" ? liveMechanic : mechanic;
        if (!position) {
            selected = customer ? "customer" : "mechanic";
            position = customer || mechanic;
        }
        get("show-customer").setAttribute("aria-pressed", String(selected === "customer"));
        get("show-mechanic").setAttribute("aria-pressed", String(selected === "mechanic"));
        get("show-live").setAttribute("aria-pressed", String(selected === "live"));
        get("map-empty").hidden = Boolean(position);
        get("tracking-embedded-map").hidden = !position;
        if (!position) {
            get("tracking-embedded-map").removeAttribute("src");
            get("map-caption").textContent = "";
            return;
        }
        const key = selected + ":" + coordinates(position);
        // Keep the iframe stable while polling; update moving pins at most every 30 seconds.
        if (force || (key !== embedPosition && Date.now() - lastEmbedUpdate >= 30000)) {
            get("tracking-embedded-map").src = "https://www.google.com/maps?q=" +
                encodeURIComponent(coordinates(position)) + "&ll=" +
                encodeURIComponent(coordinates(position)) + "&z=18&output=embed";
            embedPosition = key;
            lastEmbedUpdate = Date.now();
        }
        get("map-caption").textContent = (selected === "customer" ? "Customer request" :
            selected === "live" ? "Live mechanic journey" : "Mechanic acceptance") +
            " GPS: " + position.lat.toFixed(5) + ", " + position.lng.toFixed(5) +
                (selected === "live" ? ". This moving marker is separate from the saved request/acceptance pins." :
                    ". This is the saved position for this request. Select a location above to switch pins.");
    }
    window.useEmbeddedRescueMap = message => {
        embedded = true;
        get("map").hidden = true;
        get("embedded-map-section").hidden = false;
        get("map-notice").textContent = message ||
            "Showing shared locations with embedded Google Maps. No API key is needed for this view.";
        render(true);
    };
    window.gm_authFailure = () => {
        authFailed = true;
        window.useEmbeddedRescueMap(
            "Google could not authorize the live map. Showing shared locations with an embedded Google map instead."
        );
    };
    window.initRescueMap = () => {
        if (authFailed) return;
        try {
            get("map").hidden = false;
            map = new google.maps.Map(get("map"), {
                center: customer || mechanic || {lat: 5.6037, lng: -0.1870},
                zoom: customer || mechanic ? 15 : 7,
            });
            directionsService = new google.maps.DirectionsService();
            directionsRenderer = new google.maps.DirectionsRenderer({
                map, suppressMarkers: true, preserveViewport: true,
            });
            embedded = false;
            get("embedded-map-section").hidden = true;
            get("map-notice").textContent = "C = customer request · M = mechanic acceptance · L = live journey (when shared).";
            render(true);
        } catch (_) {
            window.useEmbeddedRescueMap("The live map is unavailable. Showing the embedded Google map instead.");
        }
    };
    async function poll() {
        if (polling || document.hidden) return;
        polling = true;
        try {
            const response = await fetch(config.pollUrl, {
                credentials: "same-origin", headers: {Accept: "application/json"}, cache: "no-store",
            });
            if (response.redirected) {
                window.location.assign("/login/?next=" + encodeURIComponent(window.location.pathname));
                return;
            }
            if (!response.ok) throw new Error("Tracking unavailable");
            const data = await response.json();
            if (!data.success) throw new Error("Tracking unavailable");
            customer = validPosition(data.customer);
            mechanic = validPosition({lat: data.latitude, lng: data.longitude});
            liveMechanic = data.live_fresh ? validPosition(data.live) : null;
            get("journey-status").textContent = liveMechanic ?
                "Live mechanic GPS received at " + new Date(data.live_updated_at).toLocaleTimeString() +
                    (data.live_accuracy != null ? " · reported accuracy about " + Math.round(data.live_accuracy) + " metres." : ".") :
                data.live_sharing ? "Live GPS updates have paused. No current journey position is shown." :
                    "Live journey sharing is off. The request and acceptance pins remain unchanged.";
            get("status").textContent = data.status.replaceAll("_", " ");
            const capturedAt = data.mechanic_captured_at || data.location_updated_at;
            const updated = capturedAt ? new Date(capturedAt) : null;
            const captured = updated && Number.isFinite(updated.getTime());
            get("tracking-status").className = "alert " +
                (mechanic && captured ? "alert-success" : "alert-warning");
            get("tracking-status").textContent = !mechanic ?
                "No mechanic acceptance GPS is saved for this request yet." :
                captured ? "Mechanic GPS captured at acceptance on " + updated.toLocaleString() +
                    ". This pin stays at the saved acceptance position." :
                "Showing saved mechanic coordinates for an older job. Its original acceptance position cannot be verified.";
            const details = [];
            if (customer) {
                details.push("Customer GPS: " + coordinates(customer) +
                    (data.customer_captured_at ? " · captured " + new Date(data.customer_captured_at).toLocaleString() : ""));
            }
            if (data.customer_accuracy !== null && data.customer_accuracy !== undefined) {
                details.push("Customer accuracy: about " + Math.round(data.customer_accuracy) + " metres");
            }
            if (mechanic) details.push("Mechanic GPS: " + coordinates(mechanic));
            if (data.mechanic_accuracy !== null && data.mechanic_accuracy !== undefined) {
                details.push("Mechanic accuracy: about " + Math.round(data.mechanic_accuracy) + " metres");
            }
            get("capture-details").textContent = details.join(" · ");
            render();
        } catch (_) {
            get("tracking-status").className = "alert alert-warning";
            get("tracking-status").textContent =
                "Could not refresh request details. Check your connection. Saved GPS pins have not been changed.";
        } finally {
            polling = false;
        }
    }
    get("show-customer").addEventListener("click", () => {selected = "customer"; render(true);});
    get("show-mechanic").addEventListener("click", () => {selected = "mechanic"; render(true);});
    get("show-live").addEventListener("click", () => {selected = "live"; render(true);});
    const share = get("share-customer-location");
    if (share) share.addEventListener("click", () => {
        const status = get("customer-location-status");
        if (!navigator.geolocation) {
            status.textContent = "This browser does not support GPS. Open this page in your phone’s browser.";
            return;
        }
        share.disabled = true;
        status.textContent = "Finding your location. Please allow location access…";
        navigator.geolocation.getCurrentPosition(async result => {
            try {
                const response = await fetch(config.customerLocationUrl, {
                    method: "POST", credentials: "same-origin",
                    headers: {"X-CSRFToken": script.dataset.csrfToken},
                    body: new URLSearchParams({
                        latitude: result.coords.latitude, longitude: result.coords.longitude,
                    }),
                });
                if (response.redirected) {
                    window.location.assign("/login/?next=" + encodeURIComponent(window.location.pathname));
                    return;
                }
                const data = await response.json();
                if (!response.ok || !data.success) throw new Error(data.message || "Could not save your location.");
                customer = validPosition(data.customer);
                selected = "customer";
                render(true);
                status.textContent = "Your GPS has been saved for this older request. It will not move with your phone.";
            } catch (error) {
                status.textContent = error.message || "Could not share location. Please try again.";
            } finally {
                share.disabled = false;
            }
        }, error => {
            status.textContent = error.code === 1 ?
                "Location permission is blocked. Allow location access in your browser’s site settings and try again." :
                "Your phone could not get a GPS fix. Turn on location services and try again.";
            share.disabled = false;
        }, {enableHighAccuracy: true, timeout: 20000, maximumAge: 0});
    });
    window.useEmbeddedRescueMap();
    poll();
    window.setInterval(poll, 5000);
})();
