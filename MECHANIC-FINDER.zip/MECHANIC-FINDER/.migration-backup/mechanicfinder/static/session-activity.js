// Only real interactions renew the session; polling and GPS updates never do.
(() => {
    const script = document.currentScript;
    const url = script.dataset.activityUrl;
    const csrfToken = script.dataset.csrfToken;
    let lastSent = Date.now();
    let sending = false;

    async function onActivity(event) {
        if (window.appSessionLocked || !event.isTrusted || document.visibilityState !== "visible" || sending) return;
        if (Date.now() - lastSent < 60000) return;
        sending = true;
        try {
            const response = await fetch(url, {
                method: "POST",
                headers: { "X-CSRFToken": csrfToken },
                credentials: "same-origin",
            });
            if (response.redirected) {
                window.location.assign("/login/?next=" + encodeURIComponent(
                    window.location.pathname + window.location.search
                ));
                return;
            }
            if (response.ok) lastSent = Date.now();
        } catch (_) {
            // Do not claim the session was renewed when offline.
        } finally {
            sending = false;
        }
    }
    ["pointerdown", "keydown", "scroll"].forEach(type => {
        window.addEventListener(type, onActivity, { passive: true, capture: true });
    });
})();
