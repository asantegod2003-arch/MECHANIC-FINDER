// Explicit, job-specific live sharing. It never updates either captured pin.
(() => {
    const script = document.currentScript;
    const start = document.getElementById("start-journey-sharing");
    const stop = document.getElementById("stop-journey-sharing");
    if (!start || !stop) return;
    const config = JSON.parse(document.getElementById("tracking-data").textContent);
    if (!config.isMechanic || config.status !== "on_the_way") return;
    const status = document.getElementById("journey-capture-status");
    let watchId = null, sending = false, lastSent = 0, session = 0, heartbeat = null;

    async function stopSharing(leaving = false) {
        session++;
        if (watchId !== null) navigator.geolocation.clearWatch(watchId);
        if (heartbeat !== null) window.clearInterval(heartbeat);
        heartbeat = null;
        watchId = null;
        start.disabled = false;
        status.textContent = "Live sharing stopped. Saved capture pins have not changed.";
        try {
            await fetch(config.journeyUrl, {
                method: "POST", credentials: "same-origin", keepalive: leaving,
                headers: {"X-CSRFToken": script.dataset.csrfToken},
                body: new URLSearchParams({action: "stop"}),
            });
        } catch (_) {
            status.textContent = "GPS capture stopped. The last shared journey point expires automatically if the connection is offline.";
        }
    }
    start.addEventListener("click", () => {
        if (watchId !== null) return;
        if (!navigator.geolocation) {
            status.textContent = "GPS is not supported by this browser.";
            return;
        }
        start.disabled = true;
        lastSent = 0;
        const currentSession = ++session;
        status.textContent = "Allow location access to share your journey with this customer…";
        const onPosition = async position => {
            if (currentSession !== session || sending || Date.now() - lastSent < 10000) return;
            sending = true;
            try {
                const response = await fetch(config.journeyUrl, {
                    method: "POST", credentials: "same-origin",
                    headers: {"X-CSRFToken": script.dataset.csrfToken},
                    body: new URLSearchParams({
                        latitude: position.coords.latitude, longitude: position.coords.longitude,
                        accuracy: position.coords.accuracy,
                    }),
                });
                if (response.redirected || !response.ok) throw new Error("Sharing unavailable");
                if (currentSession !== session) {
                    await stopSharing();
                    return;
                }
                lastSent = Date.now();
                status.textContent = "Your live journey is being shared with this customer. You can stop at any time.";
            } catch (_) {
                status.textContent = "Live sharing could not update. Check your connection or stop sharing. A paused GPS point is hidden after one minute.";
            } finally {
                sending = false;
            }
        };
        const onError = () => {
            stopSharing().then(() => {
                status.textContent = "GPS could not be accessed. Enable location permission and try sharing again.";
            });
        };
        const gpsOptions = {enableHighAccuracy: true, maximumAge: 0, timeout: 20000};
        watchId = navigator.geolocation.watchPosition(onPosition, onError, gpsOptions);
        // watchPosition need not fire when stationary; request fresh GPS rather
        // than falsely renewing the timestamp of an old stored reading.
        heartbeat = window.setInterval(() => {
            if (watchId !== null) navigator.geolocation.getCurrentPosition(onPosition, onError, gpsOptions);
        }, 15000);
    });
    stop.addEventListener("click", () => stopSharing());
    window.addEventListener("pagehide", () => {if (watchId !== null) stopSharing(true);});
    document.addEventListener("visibilitychange", () => {
        if (document.hidden && watchId !== null) stopSharing(true);
    });
})();
