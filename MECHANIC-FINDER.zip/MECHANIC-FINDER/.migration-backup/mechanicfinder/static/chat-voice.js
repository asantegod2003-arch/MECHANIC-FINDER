(function () {
    "use strict";

    const feed = document.getElementById("chat-feed");
    const form = document.getElementById("chat-form");
    if (!feed || !form) return;

    const recordButton = document.getElementById("voice-record");
    const stopButton = document.getElementById("voice-stop");
    const sendButton = document.getElementById("voice-send");
    const cancelButton = document.getElementById("voice-cancel");
    const preview = document.getElementById("voice-preview");
    const timer = document.getElementById("voice-timer");
    const timeLabel = document.getElementById("voice-time");
    const status = document.getElementById("voice-status");
    const unavailable = document.getElementById("voice-unavailable");
    const maxSeconds = 120;
    const ownUserId = Number(form.dataset.ownUserId);
    let latestId = Number(feed.dataset.latestId || 0);
    let recorder = null;
    let stream = null;
    let chunks = [];
    let audioBlob = null;
    let previewUrl = null;
    let recordingStartedAt = 0;
    let elapsedSeconds = 0;
    let clockInterval = null;
    let isSending = false;
    let discardWhenStopped = false;

    function setStatus(message) {
        status.textContent = message;
    }

    function releaseMicrophone() {
        if (stream) {
            stream.getTracks().forEach(function (track) {
                track.stop();
            });
            stream = null;
        }
    }

    function clearClock() {
        if (clockInterval !== null) {
            window.clearInterval(clockInterval);
            clockInterval = null;
        }
    }

    function formatTime(totalSeconds) {
        const seconds = Math.max(0, Math.floor(totalSeconds));
        return Math.floor(seconds / 60) + ":" + String(seconds % 60).padStart(2, "0");
    }

    function revokePreview() {
        if (previewUrl) {
            URL.revokeObjectURL(previewUrl);
            previewUrl = null;
        }
        preview.removeAttribute("src");
        preview.load();
    }

    function resetVoice() {
        clearClock();
        releaseMicrophone();
        recorder = null;
        chunks = [];
        audioBlob = null;
        elapsedSeconds = 0;
        discardWhenStopped = false;
        revokePreview();
        preview.hidden = true;
        timer.hidden = true;
        stopButton.hidden = true;
        stopButton.disabled = false;
        sendButton.hidden = true;
        sendButton.disabled = true;
        cancelButton.hidden = true;
        cancelButton.disabled = false;
        recordButton.hidden = false;
        recordButton.disabled = false;
        const recordIcon = document.createElement("i");
        recordIcon.className = "bi bi-mic";
        recordIcon.setAttribute("aria-hidden", "true");
        const recordLabel = document.createElement("span");
        recordLabel.textContent = "Record voice note";
        recordButton.replaceChildren(recordIcon, recordLabel);
        timeLabel.textContent = "0:00";
    }

    function showVoiceError(message) {
        unavailable.textContent = message;
        unavailable.hidden = false;
        setStatus("You can still send a text message below.");
    }

    function negotiateMimeType() {
        if (!window.MediaRecorder || typeof window.MediaRecorder.isTypeSupported !== "function") return "";
        const candidates = [
            "audio/webm;codecs=opus",
            "audio/mp4",
            "audio/ogg;codecs=opus"
        ];
        return candidates.find(function (type) {
            try {
                return window.MediaRecorder.isTypeSupported(type);
            } catch (_) {
                return false;
            }
        }) || "";
    }

    function setRecordingTime() {
        elapsedSeconds = Math.min(maxSeconds, (Date.now() - recordingStartedAt) / 1000);
        timeLabel.textContent = formatTime(elapsedSeconds);
        if (elapsedSeconds >= maxSeconds && recorder && recorder.state === "recording") {
            stopRecording();
        }
    }

    async function startRecording() {
        if (window.appSessionLocked) return;
        unavailable.hidden = true;
        if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== "function" || !window.MediaRecorder) {
            showVoiceError("Voice recording is not supported in this browser. Use the text message field instead.");
            return;
        }
        recordButton.disabled = true;
        setStatus("Requesting microphone access…");
        try {
            stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            if (window.appSessionLocked) {
                releaseMicrophone();
                return;
            }
            const mimeType = negotiateMimeType();
            recorder = mimeType ? new MediaRecorder(stream, { mimeType: mimeType }) : new MediaRecorder(stream);
            chunks = [];
            discardWhenStopped = false;
            recorder.addEventListener("dataavailable", function (event) {
                if (event.data && event.data.size > 0) chunks.push(event.data);
            });
            recorder.addEventListener("error", function () {
                clearClock();
                releaseMicrophone();
                resetVoice();
                showVoiceError("The recording could not be completed. Please try again or send a text message.");
            });
            recorder.addEventListener("stop", function () {
                clearClock();
                releaseMicrophone();
                if (discardWhenStopped) {
                    resetVoice();
                    setStatus("Recording cancelled. Nothing was sent.");
                    return;
                }
                const actualType = recorder && recorder.mimeType ? recorder.mimeType : (chunks[0] && chunks[0].type) || "audio/webm";
                audioBlob = new Blob(chunks, { type: actualType });
                chunks = [];
                if (!audioBlob.size) {
                    resetVoice();
                    showVoiceError("No audio was captured. Please try recording again.");
                    return;
                }
                previewUrl = URL.createObjectURL(audioBlob);
                preview.src = previewUrl;
                preview.hidden = false;
                timer.hidden = true;
                stopButton.hidden = true;
                sendButton.hidden = false;
                sendButton.disabled = false;
                cancelButton.hidden = false;
                recordButton.hidden = true;
                setStatus("Preview your voice note. It will only be shared when you choose Send voice.");
            });
            recorder.start();
            recordingStartedAt = Date.now();
            elapsedSeconds = 0;
            timeLabel.textContent = "0:00";
            timer.hidden = false;
            stopButton.hidden = false;
            cancelButton.hidden = false;
            recordButton.hidden = true;
            setStatus("Recording. Select Stop when you are finished.");
            clockInterval = window.setInterval(setRecordingTime, 250);
        } catch (error) {
            releaseMicrophone();
            recorder = null;
            recordButton.disabled = false;
            if (error && (error.name === "NotAllowedError" || error.name === "PermissionDeniedError")) {
                showVoiceError("Microphone access was not allowed. Enable it in your browser settings or use text.");
            } else if (error && error.name === "NotFoundError") {
                showVoiceError("No microphone was found. Connect one or send a text message.");
            } else {
                showVoiceError("Could not start voice recording. Check microphone access or use text.");
            }
        }
    }

    function stopRecording() {
        if (recorder && recorder.state === "recording") {
            stopButton.disabled = true;
            recorder.stop();
        }
    }

    function cancelRecording() {
        if (recorder && recorder.state === "recording") {
            discardWhenStopped = true;
            clearClock();
            stopButton.disabled = true;
            cancelButton.disabled = true;
            setStatus("Cancelling recording…");
            recorder.stop();
            return;
        }
        resetVoice();
        setStatus("Voice note cancelled. Nothing was sent.");
    }

    function appendMessage(item) {
        const messageId = Number(item.id) || 0;
        if (messageId && feed.querySelector('[data-message-id="' + messageId + '"]')) return;

        const empty = document.getElementById("chat-empty");
        if (empty) empty.remove();
        const article = document.createElement("article");
        const isOwn = Number(item.sender_id) === ownUserId;
        article.className = "chat-message " + (isOwn ? "own" : "theirs");
        if (messageId) article.dataset.messageId = String(messageId);

        if (!isOwn) {
            const sender = document.createElement("strong");
            sender.className = "chat-message-sender";
            sender.textContent = item.sender_name || "Conversation participant";
            article.appendChild(sender);
        }
        if (item.body) {
            const body = document.createElement("div");
            body.className = "chat-message-body";
            body.textContent = item.body;
            article.appendChild(body);
        }
        if (item.audio_url) {
            try {
                const audioUrl = new URL(item.audio_url, window.location.origin);
                if (audioUrl.origin === window.location.origin) {
                    const audio = document.createElement("audio");
                    audio.className = "chat-audio";
                    audio.controls = true;
                    audio.preload = "metadata";
                    audio.setAttribute("aria-label", "Voice note from " + (item.sender_name || "conversation participant"));
                    audio.src = audioUrl.href;
                    article.appendChild(audio);
                    if (item.audio_duration) {
                        const duration = document.createElement("span");
                        duration.className = "small d-block mt-1";
                        duration.textContent = String(item.audio_duration) + " second voice note";
                        article.appendChild(duration);
                    }
                }
            } catch (_) {
                // Ignore malformed audio URLs while keeping the text conversation usable.
            }
        }
        const time = document.createElement("time");
        const parsedDate = new Date(item.created_at);
        time.textContent = Number.isNaN(parsedDate.getTime()) ? "" : parsedDate.toLocaleString();
        article.appendChild(time);
        feed.appendChild(article);
        latestId = Math.max(latestId, messageId);
        feed.dataset.latestId = String(latestId);
    }

    async function sendVoice() {
        if (isSending || !audioBlob || !audioBlob.size) return;
        isSending = true;
        sendButton.disabled = true;
        cancelButton.disabled = true;
        setStatus("Sending voice note…");
        const formData = new FormData(form);
        const extension = audioBlob.type.indexOf("mp4") !== -1 ? "m4a" : audioBlob.type.indexOf("ogg") !== -1 ? "ogg" : "webm";
        formData.set("audio", audioBlob, "voice-note." + extension);
        formData.set("audio_duration", String(Math.max(1, Math.min(maxSeconds, Math.round(elapsedSeconds)))));
        try {
            const response = await fetch(window.location.href, {
                method: "POST",
                body: formData,
                credentials: "same-origin",
                headers: { "Accept": "application/json" }
            });
            let data = {};
            try {
                data = await response.json();
            } catch (_) {
                data = {};
            }
            if (!response.ok) {
                throw new Error(data.error || "Could not send voice note. Please try again.");
            }
            if (!data.message) {
                throw new Error("The server did not confirm the voice note. Please try again.");
            }
            appendMessage(data.message);
            document.getElementById("chat-body").value = "";
            feed.scrollTop = feed.scrollHeight;
            resetVoice();
            setStatus("Voice note sent.");
        } catch (error) {
            setStatus(error && error.message ? error.message : "Could not send voice note. Please try again.");
            sendButton.disabled = false;
            cancelButton.disabled = false;
        } finally {
            isSending = false;
        }
    }

    async function pollMessages() {
        try {
            const url = new URL(feed.dataset.pollUrl, window.location.origin);
            if (url.origin !== window.location.origin) return;
            url.searchParams.set("after", String(latestId));
            const response = await fetch(url.href, {
                headers: { "Accept": "application/json" },
                credentials: "same-origin"
            });
            if (!response.ok) return;
            const data = await response.json();
            (data.messages || []).forEach(appendMessage);
            if (data.messages && data.messages.length) feed.scrollTop = feed.scrollHeight;
        } catch (_) {
            // Poll failures are non-blocking; the user can continue composing.
        }
    }

    recordButton.addEventListener("click", startRecording);
    function releaseOnDeparture() {
        cancelRecording();
        releaseMicrophone();
        revokePreview();
    }
    window.addEventListener("app:session-lock", releaseOnDeparture);
    window.addEventListener("app:background", releaseOnDeparture);
    stopButton.addEventListener("click", stopRecording);
    cancelButton.addEventListener("click", cancelRecording);
    sendButton.addEventListener("click", sendVoice);
    form.addEventListener("submit", function (event) {
        if (isSending || (recorder && recorder.state === "recording")) {
            event.preventDefault();
            setStatus("Finish your recording before sending a text message.");
            return;
        }
        const body = document.getElementById("chat-body");
        if (!body.value.trim()) {
            event.preventDefault();
            body.focus();
        }
    });
    window.addEventListener("beforeunload", function () {
        clearClock();
        releaseMicrophone();
        revokePreview();
    });

    feed.querySelectorAll("[data-message-id]").forEach(function (node) {
        latestId = Math.max(latestId, Number(node.dataset.messageId) || 0);
    });
    feed.dataset.latestId = String(latestId);
    feed.scrollTop = feed.scrollHeight;
    window.setInterval(pollMessages, 4000);
})();
