// Capture at the user's submit/accept action, never from a cached profile.
(() => {
    document.querySelectorAll("form[data-capture-gps]").forEach(form => {
        let capturing = false;
        form.addEventListener("submit", event => {
            event.preventDefault();
            if (typeof window !== "undefined" && window.appSessionLocked) return;
            if (capturing) return;
            const status = document.getElementById(form.dataset.gpsStatus);
            const button = form.querySelector('button[type="submit"]');
            const setStatus = text => { if (status) status.textContent = text; };
            if (!navigator.geolocation) {
                setStatus("GPS is unavailable. Open the app in a phone browser and enable location services.");
                return;
            }
            capturing = true;
            if (button) button.disabled = true;
            setStatus("Capturing your current GPS position. Please allow precise location access…");
            navigator.geolocation.getCurrentPosition(position => {
                if (typeof window !== "undefined" && window.appSessionLocked) return;
                const {latitude, longitude, accuracy} = position.coords;
                if (!Number.isFinite(latitude) || !Number.isFinite(longitude) ||
                    Math.abs(latitude) > 90 || Math.abs(longitude) > 180) {
                    capturing = false;
                    if (button) button.disabled = false;
                    setStatus("The device returned an invalid location. Please try again.");
                    return;
                }
                form.elements.namedItem(form.dataset.latitudeField || "latitude").value = latitude;
                form.elements.namedItem(form.dataset.longitudeField || "longitude").value = longitude;
                const field = form.elements.namedItem(form.dataset.accuracyField || "accuracy");
                if (field) field.value = Number.isFinite(accuracy) ? accuracy : "";
                setStatus("GPS captured. Saving this position for the request…");
                // Native submit avoids capturing a second time through this listener.
                if (typeof window !== "undefined") window.dispatchEvent(new Event("app:internal-navigation"));
                HTMLFormElement.prototype.submit.call(form);
            }, error => {
                capturing = false;
                if (button) button.disabled = false;
                setStatus(error.code === 1 ?
                    "Location permission is blocked. Allow precise location in your browser settings, then try again." :
                    "Could not get a fresh GPS reading. Turn on location services and try again. Nothing was submitted.");
            }, {enableHighAccuracy: true, timeout: 20000, maximumAge: 0});
        });
    });
})();
