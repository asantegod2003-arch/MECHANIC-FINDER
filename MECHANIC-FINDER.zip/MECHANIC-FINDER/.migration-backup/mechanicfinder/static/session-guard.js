// Require re-authentication after ten continuous minutes outside the app.
(() => {
    const script = document.currentScript;
    const pendingKey = "mechanic-finder-reauth-required";
    const awayKey = "mechanic-finder-away-since";
    const awayLimitMs = 10 * 60 * 1000;
    const readAway = () => {
        try {
            const value = Number(window.sessionStorage.getItem(awayKey));
            return Number.isFinite(value) && value > 0 ? value : null;
        } catch (_) { return null; }
    };
    const storeAway = value => {
        try {
            if (value === null) window.sessionStorage.removeItem(awayKey);
            else window.sessionStorage.setItem(awayKey, String(value));
        } catch (_) { /* In-memory timing still works without storage. */ }
    };
    const readPending = () => {
        try { return window.sessionStorage.getItem(pendingKey) === "1"; }
        catch (_) { return false; }
    };
    const setPending = pending => {
        try {
            if (pending) window.sessionStorage.setItem(pendingKey, "1");
            else window.sessionStorage.removeItem(pendingKey);
        } catch (_) { /* The in-memory lock still works without storage. */ }
    };
    if (script.dataset.authenticated !== "true") {
        setPending(false);
        storeAway(null);
        return;
    }

    const screen = document.getElementById("session-lock-screen");
    const message = document.getElementById("session-lock-message");
    const retry = document.getElementById("session-lock-retry");
    let navigatingInternally = false;
    let navigationTimer;
    let ending = null;
    let ended = false;
    let awaySince = readAway();
    let awayTimer;

    function beginAway() {
        if (window.appSessionLocked) return;
        if (awaySince === null) {
            awaySince = Date.now();
            storeAway(awaySince);
            window.dispatchEvent(new Event("app:background"));
        }
        window.clearTimeout(awayTimer);
        const remaining = Math.max(0, awayLimitMs - (Date.now() - awaySince));
        awayTimer = window.setTimeout(() => {
            if (awaySince !== null && Date.now() - awaySince >= awayLimitMs) lock();
        }, remaining);
    }

    function onReturn() {
        window.clearTimeout(awayTimer);
        // Browsers can suspend background timers. Check elapsed wall time too,
        // including after a reload or restored tab, before allowing app use.
        if (window.appSessionLocked || readPending() ||
                (awaySince !== null && Date.now() - awaySince >= awayLimitMs)) {
            lock();
        } else {
            awaySince = null;
            storeAway(null);
        }
    }

    function markInternalNavigation() {
        if (window.appSessionLocked) return;
        navigatingInternally = true;
        window.clearTimeout(navigationTimer);
        // A cancelled navigation must not disable the guard indefinitely.
        navigationTimer = window.setTimeout(() => {
            navigatingInternally = false;
            if (document.visibilityState === "hidden") beginAway();
        }, 1500);
    }

    function goToLogin() {
        if (document.visibilityState !== "visible" || !ended) return;
        const next = window.location.pathname + window.location.search;
        window.location.replace(script.dataset.loginUrl + "?next=" + encodeURIComponent(next));
    }

    async function endSession() {
        if (ended) { goToLogin(); return; }
        if (ending) return ending;
        retry.hidden = true;
        message.textContent = "Your session has ended. Securing your account before returning to login…";
        ending = (async () => {
            try {
                const response = await fetch(script.dataset.leaveUrl, {
                    method: "POST",
                    credentials: "same-origin",
                    headers: {"X-CSRFToken": script.dataset.csrfToken, "Accept": "application/json"},
                    keepalive: true,
                    signal: typeof AbortSignal !== "undefined" && AbortSignal.timeout ?
                        AbortSignal.timeout(10000) : undefined,
                });
                if (!response.ok) throw new Error("Sign-out was not confirmed");
                const data = await response.json();
                if (data.logged_out !== true) throw new Error("Unexpected response");
                ended = true;
                // Keep the marker until a signed-out page is loaded. It also
                // protects a restored/reloaded document after a background kill.
                goToLogin();
            } catch (_) {
                message.textContent = "The app is locked. Connect to the internet and retry so we can sign you out safely.";
                retry.hidden = false;
            } finally {
                ending = null;
            }
        })();
        return ending;
    }

    function lock() {
        if (!window.appSessionLocked) {
            window.appSessionLocked = true;
            setPending(true);
            document.documentElement.classList.add("app-session-locked");
            screen.hidden = false;
            window.dispatchEvent(new Event("app:session-lock"));
        }
        endSession();
    }

    // These events run after page-specific submit/click handlers, so a GPS
    // permission request or prevented AJAX submission is not navigation.
    window.addEventListener("click", event => {
        if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey ||
                event.shiftKey || event.altKey || window.appSessionLocked) return;
        const anchor = event.target.closest && event.target.closest("a[href]");
        if (!anchor || anchor.hasAttribute("download") ||
                (anchor.target && anchor.target !== "_self")) return;
        const destination = new URL(anchor.href, window.location.href);
        const fragmentOnly = destination.pathname === window.location.pathname &&
            destination.search === window.location.search && destination.hash;
        if (destination.origin === window.location.origin && !fragmentOnly) markInternalNavigation();
    });
    window.addEventListener("submit", event => {
        if (event.defaultPrevented) return;
        const form = event.target;
        const destination = new URL(form.action || window.location.href, window.location.href);
        if ((!form.target || form.target === "_self") &&
                destination.origin === window.location.origin) markInternalNavigation();
    });
    window.addEventListener("app:internal-navigation", markInternalNavigation);
    if (window.navigation) {
        window.navigation.addEventListener("navigate", event => {
            if (new URL(event.destination.url).origin === window.location.origin &&
                    !event.hashChange && !event.downloadRequest) markInternalNavigation();
        });
    }
    document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "hidden" && !navigatingInternally) beginAway();
        else if (document.visibilityState === "visible") onReturn();
    });
    window.addEventListener("pageshow", event => {
        navigatingInternally = false;
        if (document.visibilityState === "hidden") beginAway();
        else onReturn();
        if (!window.appSessionLocked && event.persisted) {
            document.documentElement.classList.add("app-session-locked");
            screen.hidden = false;
            message.textContent = "Checking your session…";
            markInternalNavigation();
            window.location.reload();
        }
    });
    window.addEventListener("online", () => {
        if (window.appSessionLocked) endSession();
    });
    retry.addEventListener("click", endSession);
    if (readPending()) lock();
    else if (document.visibilityState === "hidden") beginAway();
    else onReturn();
})();
