from django.contrib import admin
from django.urls import path, include
from django.templatetags.static import static
from django.views.generic import RedirectView

from . import public_views

urlpatterns = [
    path("robots.txt", public_views.robots_txt, name="robots_txt"),
    path("sitemap.xml", public_views.sitemap_xml, name="sitemap_xml"),
    path(
        "favicon.ico",
        RedirectView.as_view(url=static("images/favicon.ico"), permanent=True),
        name="favicon",
    ),
    path("admin/", admin.site.urls),

    path("", include("accounts.urls")),

    path("rescue/", include("rescue.urls")),
]