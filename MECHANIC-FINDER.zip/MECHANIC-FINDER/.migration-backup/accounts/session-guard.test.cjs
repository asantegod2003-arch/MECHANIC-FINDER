const {test} = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const source = fs.readFileSync("mechanicfinder/static/session-guard.js", "utf8");
const settle = () => new Promise(resolve => setImmediate(resolve));

function setup({authenticated = true, pending = false, offline = false, awaySince = null} = {}) {
    const storage = new Map(pending ? [["mechanic-finder-reauth-required", "1"]] : []);
    if (awaySince !== null) storage.set("mechanic-finder-away-since", String(awaySince));
    let now = 1000000, timerId = 0;
    const timers = new Map();
    const winListeners = {}, docListeners = {};
    const screen = {hidden: true};
    const message = {textContent: ""};
    const retry = {hidden: true, addEventListener(type, handler) { this[type] = handler; }};
    const calls = [], redirects = [], signals = [];
    let failures = offline, reloads = 0;
    const classes = new Set();
    const window = {
        sessionStorage: {
            getItem: key => storage.get(key),
            setItem: (key, value) => storage.set(key, value),
            removeItem: key => storage.delete(key),
        },
        location: {
            origin: "https://app.test", href: "https://app.test/customer/dashboard/?view=active",
            pathname: "/customer/dashboard/", search: "?view=active",
            replace: url => redirects.push(url), reload: () => reloads++,
        },
        addEventListener: (type, handler) => { winListeners[type] = handler; },
        dispatchEvent: event => signals.push(event.type),
        setTimeout: (handler, delay) => {
            const id = ++timerId;
            timers.set(id, {handler, at: now + delay});
            return id;
        },
        clearTimeout: id => timers.delete(id),
    };
    const document = {
        currentScript: {dataset: {
            authenticated: String(authenticated), leaveUrl: "/account/leave/",
            loginUrl: "/login/", csrfToken: "csrf-test",
        }},
        visibilityState: "visible",
        documentElement: {classList: {add: name => classes.add(name)}},
        getElementById: id => ({
            "session-lock-screen": screen, "session-lock-message": message, "session-lock-retry": retry,
        })[id],
        addEventListener: (type, handler) => { docListeners[type] = handler; },
    };
    vm.runInNewContext(source, {
        window, document, URL, Date: {now: () => now},
        Event: class { constructor(type) { this.type = type; } },
        fetch: async (url, options) => {
            calls.push({url, options});
            if (failures) throw new Error("offline");
            return {ok: true, json: async () => ({logged_out: true})};
        },
    });
    return {
        window, document, screen, message, retry, calls, redirects, signals, classes, storage,
        reloads: () => reloads, online: () => { failures = false; },
        hide: () => { document.visibilityState = "hidden"; docListeners.visibilitychange(); },
        show: () => { document.visibilityState = "visible"; docListeners.visibilitychange(); },
        emit: (type, event = {}) => winListeners[type](event),
        advance(ms, runTimers = true) {
            now += ms;
            if (runTimers) {
                for (const [id, timer] of [...timers]) {
                    if (timer.at <= now && timers.has(id)) {
                        timers.delete(id);
                        timer.handler();
                    }
                }
            }
        },
    };
}

test("switching apps signs out only after ten continuous minutes away", async () => {
    const app = setup();
    assert.equal(app.calls.length, 0);
    app.hide();
    assert.equal(app.screen.hidden, true);
    assert.equal(app.calls.length, 0);
    assert.deepEqual(app.signals, ["app:background"]);
    app.advance(599999);
    assert.equal(app.calls.length, 0);
    app.advance(1);
    assert.equal(app.window.appSessionLocked, true);
    assert.equal(app.screen.hidden, false);
    assert.ok(app.classes.has("app-session-locked"));
    assert.deepEqual(app.signals, ["app:background", "app:session-lock"]);
    await settle();
    assert.equal(app.calls.length, 1);
    assert.equal(app.calls[0].options.keepalive, true);
    assert.equal(app.calls[0].options.method, "POST");
    assert.equal(app.calls[0].options.headers["X-CSRFToken"], "csrf-test");
    assert.equal(app.redirects.length, 0);
    app.show();
    assert.equal(app.redirects[0], "/login/?next=%2Fcustomer%2Fdashboard%2F%3Fview%3Dactive");
});

test("a short return keeps the user signed in and resets the away period", async () => {
    const app = setup();
    app.hide();
    app.advance(9 * 60000);
    app.show();
    assert.equal(app.storage.has("mechanic-finder-away-since"), false);
    app.advance(5 * 60000);
    assert.equal(app.calls.length, 0);
    app.hide();
    app.advance(9 * 60000);
    app.show();
    await settle();
    assert.equal(app.calls.length, 0);
    assert.equal(app.screen.hidden, true);
    assert.equal(app.redirects.length, 0);
});

test("return checks elapsed time even if the browser suspended all background timers", async () => {
    const app = setup();
    app.hide();
    app.advance(11 * 60000, false);
    assert.equal(app.calls.length, 0);
    app.show();
    assert.equal(app.screen.hidden, false);
    await settle();
    assert.equal(app.calls.length, 1);
    assert.equal(app.redirects.length, 1);
});

test("a reload or restored tab honors the saved away timestamp", async () => {
    const expired = setup({awaySince: 1000000 - 600000});
    await settle();
    assert.equal(expired.redirects.length, 1);
    const short = setup({awaySince: 1000000 - 599999});
    await settle();
    assert.equal(short.calls.length, 0);
    assert.equal(short.storage.has("mechanic-finder-away-since"), false);
});

test("ordinary same-app links and form navigation do not log the user out", () => {
    for (const kind of ["click", "submit", "app:internal-navigation"]) {
        const app = setup();
        const anchor = {
            href: "https://app.test/mechanics/", target: "", hasAttribute: () => false,
        };
        app.emit(kind, kind === "click" ? {
            button: 0, target: {closest: () => anchor},
        } : {target: {action: "https://app.test/rescue/new/", target: ""}});
        app.hide();
        assert.equal(app.calls.length, 0, kind);
        assert.equal(app.screen.hidden, true, kind);
    }
});

test("external map links and prevented GPS submissions use the same ten-minute grace period", async () => {
    const map = setup();
    map.emit("click", {button: 0, target: {closest: () => ({
        href: "https://maps.google.com", target: "_blank", hasAttribute: () => false,
    })}});
    map.hide();
    const gps = setup();
    gps.emit("submit", {defaultPrevented: true});
    gps.hide();
    assert.equal(map.calls.length, 0);
    assert.equal(gps.calls.length, 0);
    map.advance(600000);
    gps.advance(600000);
    await settle();
    assert.equal(map.calls.length, 1);
    assert.equal(gps.calls.length, 1);
});

test("offline sign-out keeps content locked and retries after reconnection", async () => {
    const app = setup({offline: true});
    app.hide();
    app.advance(600000);
    await settle();
    app.show();
    await settle();
    assert.equal(app.redirects.length, 0);
    assert.equal(app.retry.hidden, false);
    assert.equal(app.screen.hidden, false);
    app.online();
    app.emit("online");
    await settle();
    assert.equal(app.redirects.length, 1);
});

test("a restored pending tab must sign out, while a signed-out page clears the marker", async () => {
    const restored = setup({pending: true});
    await settle();
    assert.equal(restored.screen.hidden, false);
    assert.equal(restored.redirects.length, 1);
    const loggedOut = setup({authenticated: false, pending: true});
    assert.equal(loggedOut.storage.size, 0);
    assert.equal(loggedOut.calls.length, 0);
});

test("back-forward cache restores revalidate rather than showing saved private content", () => {
    const app = setup();
    app.emit("pageshow", {persisted: true});
    assert.equal(app.reloads(), 1);
});
