"""Recover missing app profiles using existing, unambiguous account history."""
from .models import Profile


def resolve_app_profile(user):
    try:
        profile = user.profile
    except Profile.DoesNotExist:
        profile = None
    if profile is not None:
        return profile if profile.role in ("customer", "mechanic") else None

    # A password alone does not tell us which role someone originally chose.
    # Existing job/chat relationships are evidence; never default all users to
    # customers or grant administrator privileges to a recovered account.
    roles = set()
    if user.customer_chat_threads.exists() or user.rescue_requests.exists():
        roles.add("customer")
    if (user.mechanic_chat_threads.exists() or user.assigned_jobs.exists()
            or hasattr(user, "verification_application")):
        roles.add("mechanic")
    if len(roles) != 1:
        return None

    role = roles.pop()
    profile, _ = Profile.objects.get_or_create(
        user=user, defaults={"role": role, "available": False},
    )
    # Replace the cached missing OneToOne relation on this request's User.
    user.profile = profile
    return profile if profile.role in ("customer", "mechanic") else None
