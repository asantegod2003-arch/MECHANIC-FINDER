from django.contrib import admin
from django import forms
from django.utils import timezone
from django.urls import reverse
from .models import Profile, MechanicVerification
from .notifications import create_notification

admin.site.register(Profile)


class VerificationReviewForm(forms.ModelForm):
    class Meta:
        model = MechanicVerification
        fields = "__all__"

    def clean(self):
        data = super().clean()
        if data.get("status") == "verified" and not (
            data.get("identity_checked") and data.get("contact_checked")
            and data.get("qualifications_checked") and data.get("review_notes", "").strip()
        ):
            raise forms.ValidationError("Verify identity, contact and qualifications and record the evidence before approving.")
        if data.get("status") == "rejected" and not data.get("public_feedback", "").strip():
            raise forms.ValidationError("Explain the required changes in public feedback.")
        if data.get("user") and getattr(getattr(data["user"], "profile", None), "role", None) != "mechanic":
            raise forms.ValidationError("Only mechanics can be verified.")
        return data


@admin.register(MechanicVerification)
class MechanicVerificationAdmin(admin.ModelAdmin):
    form = VerificationReviewForm
    list_display = ["business_name", "user", "status", "reviewed_by", "reviewed_at"]
    list_filter = ["status"]
    search_fields = ["business_name", "user__username"]
    readonly_fields = ["user", "reviewed_by", "reviewed_at", "updated_at"]

    def has_add_permission(self, request):
        return False

    def save_model(self, request, obj, form, change):
        previous = MechanicVerification.objects.get(pk=obj.pk)
        if obj.status in ("verified", "rejected"):
            obj.reviewed_by = request.user
            obj.reviewed_at = timezone.now()
        super().save_model(request, obj, form, change)
        if previous.status != obj.status:
            create_notification(
                recipient=obj.user, title="Mechanic verification updated",
                message="Your verification is approved." if obj.status == "verified" else "Open your verification page for the review outcome.",
                url=reverse("mechanic_verification"),
            )