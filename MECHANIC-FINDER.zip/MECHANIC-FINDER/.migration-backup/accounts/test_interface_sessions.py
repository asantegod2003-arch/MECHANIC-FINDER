from django.contrib.auth.models import User
from django.test import Client, TestCase

from accounts.models import Profile
from rescue.models import RescueRequest


class InterfaceSessionTests(TestCase):
    def setUp(self):
        self.customer = User.objects.create_user(username="screen-driver", password="Road#Safe2026")
        self.mechanic = User.objects.create_user(username="screen-mechanic", password="Road#Safe2026")
        Profile.objects.create(user=self.customer, role="customer")
        Profile.objects.create(user=self.mechanic, role="mechanic")

    def test_leaving_invalidates_the_server_session_for_both_roles(self):
        for user in (self.customer, self.mechanic):
            with self.subTest(role=user.profile.role):
                self.client.force_login(user)
                old_cookie = self.client.cookies["sessionid"].value
                response = self.client.post("/account/leave/")
                self.assertEqual(response.json(), {"logged_out": True})
                self.assertNotIn("_auth_user_id", self.client.session)
                replay = Client()
                replay.cookies["sessionid"] = old_cookie
                self.assertEqual(replay.get(f"/{user.profile.role}/dashboard/").status_code, 302)

    def test_leaving_stops_only_this_mechanics_live_sharing_without_moving_saved_pins(self):
        job = RescueRequest.objects.create(
            customer=self.customer, mechanic=self.mechanic, status="on_the_way",
            vehicle_problem="Engine", location="Accra", phone_number="private",
            customer_latitude=5.6, customer_longitude=-0.18,
            mechanic_latitude=5.7, mechanic_longitude=-0.2,
            live_tracking_enabled=True, live_latitude=5.65, live_longitude=-0.19,
        )
        self.client.force_login(self.customer)
        self.client.post("/account/leave/")
        job.refresh_from_db()
        self.assertTrue(job.live_tracking_enabled)
        self.client.force_login(self.mechanic)
        self.client.post("/account/leave/")
        job.refresh_from_db()
        self.assertFalse(job.live_tracking_enabled)
        self.assertEqual((job.customer_latitude, job.mechanic_latitude), (5.6, 5.7))
        self.assertEqual(job.status, "on_the_way")

    def test_leave_requires_post_and_csrf_but_is_idempotent_for_signed_out_users(self):
        self.assertEqual(self.client.get("/account/leave/").status_code, 405)
        self.assertEqual(self.client.post("/account/leave/").json(), {"logged_out": True})
        protected = Client(enforce_csrf_checks=True)
        protected.force_login(self.customer)
        self.assertEqual(protected.post("/account/leave/").status_code, 403)
        self.assertIn("_auth_user_id", protected.session)
        protected.get("/customer/dashboard/")
        token = protected.cookies["csrftoken"].value
        self.assertEqual(protected.post("/account/leave/", HTTP_X_CSRFTOKEN=token).status_code, 200)

    def test_internal_navigation_does_not_end_session_and_private_pages_are_not_cached(self):
        self.client.force_login(self.customer)
        for path in ("/customer/dashboard/", "/mechanics/", "/rescue/create/"):
            response = self.client.get(path)
            self.assertEqual(response.status_code, 200)
            self.assertIn("_auth_user_id", self.client.session)
            self.assertIn("no-store", response["Cache-Control"])
        self.assertTrue(self.client.session.get_expire_at_browser_close())

    def test_fresh_login_has_browser_session_cookie(self):
        response = self.client.post("/login/", {
            "username": self.customer.username, "password": "Road#Safe2026",
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.cookies["sessionid"]["expires"], "")
        self.assertEqual(response.cookies["sessionid"]["max-age"], "")
