import subprocess
import tempfile
from pathlib import Path
from unittest.mock import patch

from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import IntegrityError
from django.test import Client, TestCase
from django.urls import reverse

from rescue.models import RescueRequest
from .models import ChatMessage, ChatThread, Notification, Profile


class VoiceChatTests(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "test.webm"
            subprocess.run([
                "ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=0.5",
                "-c:a", "libopus", str(path),
            ], check=True, capture_output=True, timeout=15)
            cls.audio_bytes = path.read_bytes()
            path = Path(directory) / "test.m4a"
            subprocess.run([
                "ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=0.5",
                "-c:a", "aac", str(path),
            ], check=True, capture_output=True, timeout=15)
            cls.mp4_bytes = path.read_bytes()

    def setUp(self):
        self.customer = User.objects.create_user(username="voice-customer")
        self.mechanic = User.objects.create_user(username="voice-mechanic")
        Profile.objects.create(user=self.customer, role="customer")
        Profile.objects.create(user=self.mechanic, role="mechanic", available=True)
        self.thread = ChatThread.objects.create(customer=self.customer, mechanic=self.mechanic)
        self.url = reverse("chat_thread", args=[self.mechanic.pk])
        self.client.force_login(self.customer)

    def upload(self, data=None, content_type="audio/webm"):
        return SimpleUploadedFile(
            "../../untrusted-name.webm",
            self.audio_bytes if data is None else data,
            content_type=content_type,
        )

    def send(self, **changes):
        data = {"audio": self.upload(), "audio_duration": "1"}
        data.update(changes)
        return self.client.post(self.url, data, HTTP_ACCEPT="application/json")

    @patch("accounts.views.store_voice", return_value="private-voice/development/test.webm")
    def test_customer_voice_is_saved_and_mechanic_can_receive_it(self, store):
        response = self.send()
        self.assertEqual(response.status_code, 201)
        message = ChatMessage.objects.get()
        self.assertEqual(message.body, "")
        self.assertTrue(message.is_voice)
        self.assertEqual(message.audio_mime, "audio/webm")
        self.assertEqual(message.audio_duration, 1)
        self.assertTrue(Notification.objects.filter(recipient=self.mechanic).exists())
        self.assertNotIn("audio_object_key", response.json()["message"])
        self.client.force_login(self.mechanic)
        response = self.client.get(reverse("poll_chat_messages", args=[self.customer.pk]))
        self.assertEqual(response.json()["messages"][0]["audio_url"],
                         reverse("voice_message_audio", args=[message.pk]))
        self.assertContains(self.client.get(reverse("chat_thread", args=[self.customer.pk])), "<audio")
        store.assert_called_once()

    @patch("accounts.views.store_voice", return_value="private-voice/test.m4a")
    def test_mechanic_can_reply_with_safari_mp4_recording(self, store):
        self.client.force_login(self.mechanic)
        response = self.client.post(reverse("chat_thread", args=[self.customer.pk]), {
            "audio": self.upload(self.mp4_bytes, content_type="audio/mp4"),
            "audio_duration": "1",
        }, HTTP_ACCEPT="application/json")
        self.assertEqual(response.status_code, 201)
        self.assertEqual(ChatMessage.objects.get().sender, self.mechanic)
        self.assertTrue(Notification.objects.filter(recipient=self.customer).exists())
        self.assertEqual(ChatMessage.objects.get().audio_mime, "audio/mp4")

    @patch("accounts.views.store_voice")
    def test_invalid_audio_is_rejected_without_creating_message(self, store):
        for content_type, data in (
            ("audio/webm", b"this is not audio"),
            ("text/html", b"<script>alert(1)</script>"),
            ("audio/mp4", self.audio_bytes),
        ):
            response = self.send(audio=self.upload(data, content_type))
            self.assertEqual(response.status_code, 400)
            self.assertIn("error", response.json())
        store.assert_not_called()
        self.assertEqual(ChatMessage.objects.count(), 0)

    @patch("accounts.views.store_voice")
    def test_missing_invalid_and_oversized_uploads_are_rejected(self, store):
        for duration in ("", "nan", "-1", "0", "121"):
            self.assertEqual(self.send(audio_duration=duration).status_code, 400)
        self.assertEqual(self.send(audio=self.upload(b"")).status_code, 400)
        self.assertEqual(self.send(audio=self.upload(b"x" * (8 * 1024 * 1024 + 1))).status_code, 400)
        store.assert_not_called()

    @patch("accounts.views.store_voice", side_effect=RuntimeError("storage unavailable"))
    def test_storage_failure_is_reported_and_no_message_or_notification_created(self, store):
        response = self.send()
        self.assertEqual(response.status_code, 503)
        self.assertIn("could not be sent", response.json()["error"])
        self.assertEqual(ChatMessage.objects.count(), 0)
        self.assertEqual(Notification.objects.count(), 0)

    @patch("accounts.views.remove_voice")
    @patch("accounts.views.create_notification", side_effect=IntegrityError)
    @patch("accounts.views.store_voice", return_value="private-voice/test.webm")
    def test_failed_database_write_cleans_up_private_upload(self, store, notification, remove):
        self.assertEqual(self.send().status_code, 503)
        self.assertEqual(ChatMessage.objects.count(), 0)
        remove.assert_called_once_with("private-voice/test.webm")

    def test_text_and_empty_message_paths_are_clear(self):
        response = self.client.post(self.url, {"body": "Hello"}, HTTP_ACCEPT="application/json")
        self.assertEqual(response.status_code, 201)
        self.assertIsNone(response.json()["message"]["audio_url"])
        response = self.client.post(self.url, {"body": ""}, HTTP_ACCEPT="application/json")
        self.assertEqual(response.status_code, 400)
        self.assertIn("record a voice message", response.json()["error"])

    def test_chat_and_playback_require_participation_and_authentication(self):
        message = ChatMessage.objects.create(
            thread=self.thread, sender=self.customer,
            audio_object_key="private-voice/test.webm", audio_mime="audio/webm",
        )
        audio_url = reverse("voice_message_audio", args=[message.pk])
        stranger = User.objects.create_user(username="not-a-participant")
        Profile.objects.create(user=stranger, role="customer")
        self.client.force_login(stranger)
        with patch("accounts.chat_views.read_voice") as reader:
            self.assertEqual(self.client.get(audio_url).status_code, 404)
            reader.assert_not_called()
        self.client.logout()
        self.assertEqual(self.client.get(audio_url).status_code, 302)
        self.assertEqual(self.client.get(self.url).status_code, 302)

    @patch("accounts.chat_views.read_voice", return_value=b"0123456789")
    def test_playback_supports_private_range_requests_and_seeking(self, reader):
        message = ChatMessage.objects.create(
            thread=self.thread, sender=self.customer,
            audio_object_key="private-voice/test.webm", audio_mime="audio/webm",
        )
        url = reverse("voice_message_audio", args=[message.pk])
        response = self.client.get(url)
        self.assertEqual(response.content, b"0123456789")
        self.assertEqual(response["Cache-Control"], "private, no-store")
        self.assertEqual(response["Content-Type"], "audio/webm")
        response = self.client.get(url, HTTP_RANGE="bytes=2-5")
        self.assertEqual(response.status_code, 206)
        self.assertEqual(response.content, b"2345")
        self.assertEqual(response["Content-Range"], "bytes 2-5/10")
        self.assertEqual(self.client.get(url, HTTP_RANGE="bytes=-3").content, b"789")
        self.assertEqual(self.client.get(url, HTTP_RANGE="bytes=20-30").status_code, 416)

    def test_missing_storage_has_friendly_playback_error(self):
        message = ChatMessage.objects.create(
            thread=self.thread, sender=self.customer,
            audio_object_key="private-voice/test.webm", audio_mime="audio/webm",
        )
        with patch("accounts.chat_views.read_voice", side_effect=RuntimeError):
            response = self.client.get(reverse("voice_message_audio", args=[message.pk]))
        self.assertEqual(response.status_code, 503)
        self.assertIn("temporarily unavailable", response.json()["error"])

    def test_csrf_is_required_when_sending_voice(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.customer)
        self.assertEqual(client.post(self.url, {"audio": self.upload(), "audio_duration": "1"}).status_code, 403)

    def test_inbox_visible_for_both_roles_and_relevant_contacts_only(self):
        self.assertContains(self.client.get("/customer/dashboard/"), 'href="/messages/"')
        self.assertContains(self.client.get("/messages/"), "voice-mechanic")
        self.client.force_login(self.mechanic)
        response = self.client.get("/messages/")
        self.assertContains(response, "voice-customer")
        self.assertContains(self.client.get("/mechanic/dashboard/"), 'href="/messages/"')

    def test_mechanic_can_start_chat_from_assigned_request_and_customer_from_directory(self):
        RescueRequest.objects.create(
            customer=self.customer, mechanic=self.mechanic, status="accepted",
            vehicle_problem="Tyre", location="Accra", phone_number="0000000000",
        )
        self.client.force_login(self.mechanic)
        response = self.client.get("/mechanic/dashboard/")
        self.assertContains(response, reverse("chat_thread", args=[self.customer.pk]))
        response = self.client.get("/messages/")
        self.assertIn(self.customer, response.context["contacts"])
        self.client.force_login(self.customer)
        self.assertContains(self.client.get("/mechanics/"), self.url)
