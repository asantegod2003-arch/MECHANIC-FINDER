import logging
from datetime import timedelta

from django.conf import settings
from django.http import HttpResponseRedirect
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.models import User
from django.contrib.auth.views import PasswordResetView
from django.db import transaction
from django.urls import reverse_lazy
from django.utils import timezone
from django.utils.crypto import salted_hmac

from .models import RecoveryRateLimit

logger = logging.getLogger(__name__)


def _allow(scope, identifier, limit):
    key = salted_hmac("password-reset-" + scope, identifier.lower(), algorithm="sha256").hexdigest()
    with transaction.atomic():
        entry, _ = RecoveryRateLimit.objects.get_or_create(
            key=key, defaults={"window_started": timezone.now()},
        )
        entry = RecoveryRateLimit.objects.select_for_update().get(pk=entry.pk)
        if entry.window_started < timezone.now() - timedelta(hours=1):
            entry.window_started, entry.count = timezone.now(), 0
        if entry.count >= limit:
            return False
        entry.count += 1
        entry.save()
    return True


class UniqueEmailPasswordResetForm(PasswordResetForm):
    def get_users(self, email):
        users = list(User.objects.filter(email__iexact=email, is_active=True)[:2])
        # Legacy shared addresses must not reset an arbitrarily chosen account.
        return (user for user in users if len(users) == 1 and user.has_usable_password())

    def send_mail(self, *args, **kwargs):
        # Django's standard implementation logs the email address on failure.
        # Render the token email without logging its recipient or token.
        from django.core.mail import EmailMultiAlternatives
        from django.template.loader import render_to_string
        subject_template_name, email_template_name, context, from_email, to_email = args[:5]
        subject = "".join(render_to_string(subject_template_name, context).splitlines())
        body = render_to_string(email_template_name, context)
        EmailMultiAlternatives(subject, body, from_email, [to_email]).send()


class RecoveryView(PasswordResetView):
    form_class = UniqueEmailPasswordResetForm
    template_name = "accounts/password_reset_form.html"
    email_template_name = "accounts/password_reset_email.txt"
    subject_template_name = "accounts/password_reset_subject.txt"
    success_url = reverse_lazy("password_reset_done")

    def get_context_data(self, **kwargs):
        return {
            **super().get_context_data(**kwargs),
            "email_delivery_configured": bool(settings.DEFAULT_FROM_EMAIL and settings.RESEND_API_KEY),
            "email_setup_message": "Password recovery email setup is not yet complete. Please contact the site administrator.",
        }

    def form_valid(self, form):
        if not (settings.DEFAULT_FROM_EMAIL and settings.RESEND_API_KEY):
            form.add_error(None, "Password recovery email is not configured yet. Please contact the site administrator.")
            return self.form_invalid(form)
        email = form.cleaned_data["email"]
        # REMOTE_ADDR is trusted server metadata; do not trust arbitrary forwarding headers.
        ip = self.request.META.get("REMOTE_ADDR", "unknown")
        if not (_allow("ip", ip, 20) and _allow("email", email, 3)):
            return HttpResponseRedirect(self.get_success_url())
        try:
            form.save(
                request=self.request, use_https=True,
                domain_override=settings.PUBLIC_SITE_URL.removeprefix("https://").removeprefix("http://").rstrip("/"),
                from_email=settings.DEFAULT_FROM_EMAIL,
                token_generator=self.token_generator,
                email_template_name=self.email_template_name,
                subject_template_name=self.subject_template_name,
            )
        except Exception as error:
            logger.error("Password recovery delivery failed: %s", type(error).__name__)
            # Same public result whether an account exists or a provider fails.
            # The done page does not guarantee delivery and explains how to get help.
        return HttpResponseRedirect(self.get_success_url())
