from unittest.mock import patch

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .models import ChatMessage, ChatThread, Notification, Profile


class HistoricalChatAccessTests(TestCase):
    def setUp(self):
        self.customer = User.objects.create_user(username="history-driver")
        self.mechanic = User.objects.create_user(username="history-mechanic")
        Profile.objects.create(user=self.customer, role="customer")
        Profile.objects.create(user=self.mechanic, role="mechanic", available=False)
        self.thread = ChatThread.objects.create(customer=self.customer, mechanic=self.mechanic)
        self.message = ChatMessage.objects.create(
            thread=self.thread, sender=self.customer, body="Please check my old battery message",
        )
        self.url = reverse("chat_thread", args=[self.mechanic.pk])
        self.poll_url = reverse("poll_chat_messages", args=[self.mechanic.pk])
        self.client.force_login(self.customer)

    def test_missing_counterpart_profile_does_not_block_old_messages_or_replies(self):
        self.mechanic.profile.delete()
        self.assertContains(self.client.get(self.url), self.message.body)
        self.assertEqual(self.client.get(self.poll_url).json()["messages"][0]["id"], self.message.pk)
        self.assertRedirects(self.client.post(self.url, {"body": "Can we continue?"}), self.url)
        self.assertTrue(self.thread.messages.filter(body="Can we continue?").exists())
        self.assertTrue(Notification.objects.filter(recipient=self.mechanic).exists())
        # Access to our history does not silently edit the other user's profile.
        self.assertFalse(Profile.objects.filter(user=self.mechanic).exists())

    def test_both_sides_can_read_old_text_and_voice_without_profiles(self):
        Profile.objects.filter(user__in=[self.customer, self.mechanic]).delete()
        voice = ChatMessage.objects.create(
            thread=self.thread, sender=self.mechanic, audio_object_key="private-test-voice",
            audio_mime="audio/webm", audio_duration=2,
        )
        for user, other in ((self.customer, self.mechanic), (self.mechanic, self.customer)):
            self.client.force_login(user)
            response = self.client.get(reverse("chat_thread", args=[other.pk]))
            self.assertContains(response, self.message.body)
            self.assertContains(response, reverse("voice_message_audio", args=[voice.pk]))
            self.assertContains(response, 'id="voice-record"')
            with patch("accounts.chat_views.read_voice", return_value=b"voice-test"):
                self.assertEqual(
                    self.client.get(reverse("voice_message_audio", args=[voice.pk])).status_code, 200,
                )

    def test_same_current_roles_do_not_hide_an_existing_conversation(self):
        Profile.objects.filter(user=self.mechanic).update(role="customer")
        self.assertContains(self.client.get(self.url), self.message.body)
        self.assertRedirects(self.client.post(self.url, {"body": "Same people, same conversation"}), self.url)
        self.assertEqual(ChatThread.objects.count(), 1)
        self.assertEqual(self.thread.messages.count(), 2)

    def test_reverse_legacy_threads_show_all_history_and_one_inbox_entry(self):
        reverse_thread = ChatThread.objects.create(customer=self.mechanic, mechanic=self.customer)
        reverse_message = ChatMessage.objects.create(
            thread=reverse_thread, sender=self.mechanic, body="A reply stored in the reverse thread",
        )
        response = self.client.get(self.url)
        self.assertContains(response, self.message.body)
        self.assertContains(response, reverse_message.body)
        messages = self.client.get(self.poll_url).json()["messages"]
        self.assertEqual([item["id"] for item in messages], [self.message.pk, reverse_message.pk])
        inbox = self.client.get(reverse("messages_inbox"))
        self.assertEqual(len(inbox.context["conversations"]), 1)
        self.assertContains(inbox, reverse_message.body)
        self.assertEqual(ChatThread.objects.count(), 2)

    def test_mixed_history_without_profile_can_open_inbox_and_existing_chats(self):
        ChatThread.objects.create(customer=self.mechanic, mechanic=self.customer)
        self.customer.profile.delete()
        response = self.client.get(reverse("messages_inbox"))
        self.assertContains(response, self.message.body)
        self.assertContains(response, "Restore account type")
        self.assertContains(self.client.get(self.url), self.message.body)
        self.assertFalse(Profile.objects.filter(user=self.customer).exists())

    def test_unrelated_user_cannot_read_poll_or_post_to_other_peoples_history(self):
        outsider = User.objects.create_user(username="history-outsider")
        Profile.objects.create(user=outsider, role="customer")
        self.client.force_login(outsider)
        # A valid new customer/mechanic pair may open its own empty thread,
        # never the historical thread between two different users.
        response = self.client.get(self.url)
        self.assertNotContains(response, self.message.body)
        self.assertEqual(self.client.get(self.poll_url).json()["messages"], [])
        self.client.post(self.url, {"body": "My separate thread", "thread_id": self.thread.pk})
        self.assertEqual(self.thread.messages.count(), 1)
        Profile.objects.filter(user=self.mechanic).update(role="customer")
        # The outsider may still access their own separate conversation after
        # a role change, but never the original pair's messages.
        self.assertNotContains(self.client.get(self.url), self.message.body)
        stranger = User.objects.create_user(username="another-outsider")
        Profile.objects.create(user=stranger, role="customer")
        self.client.force_login(stranger)
        self.assertEqual(self.client.get(self.url).status_code, 403)
        self.assertEqual(self.client.get(self.poll_url).status_code, 403)
        self.assertEqual(self.client.post(self.url, {"body": "Denied"}).status_code, 403)

    def test_new_same_role_and_self_chats_are_still_rejected(self):
        other = User.objects.create_user(username="another-driver")
        Profile.objects.create(user=other, role="customer")
        for other_id in (other.pk, self.customer.pk):
            url = reverse("chat_thread", args=[other_id])
            self.assertEqual(self.client.get(url).status_code, 403)
            self.assertEqual(self.client.post(url, {"body": "Not allowed"}).status_code, 403)
        self.assertEqual(ChatThread.objects.count(), 1)

    def test_dashboards_keep_history_visible_if_current_role_differs_from_thread_role(self):
        Profile.objects.filter(user=self.customer).update(role="mechanic")
        self.assertContains(self.client.get(reverse("mechanic_dashboard")), self.mechanic.username)
        self.assertContains(
            self.client.get(reverse("mechanic_dashboard")),
            reverse("chat_thread", args=[self.mechanic.pk]),
        )
        Profile.objects.filter(user=self.mechanic).update(role="customer")
        self.client.force_login(self.mechanic)
        self.assertContains(self.client.get(reverse("customer_dashboard")), self.customer.username)
