"""Conversation membership is stored on the thread, not inferred from profiles."""
from django.db.models import OuterRef, Q, Subquery

from .models import ChatMessage, ChatThread


def threads_for(user, other_user_id=None):
    if other_user_id is None:
        members = Q(customer=user) | Q(mechanic=user)
    else:
        if user.pk == other_user_id:
            return ChatThread.objects.none()
        members = (
            Q(customer=user, mechanic_id=other_user_id)
            | Q(mechanic=user, customer_id=other_user_id)
        )
    return ChatThread.objects.filter(members)


def conversation_summaries(user, limit=None):
    threads = threads_for(user).select_related("customer", "mechanic").annotate(
        latest_id=Subquery(
            ChatMessage.objects.filter(thread=OuterRef("pk")).order_by("-id").values("id")[:1]
        ),
    )
    if limit is not None:
        threads = threads[:limit]
    threads = list(threads)
    latest = ChatMessage.objects.in_bulk([thread.latest_id for thread in threads if thread.latest_id])
    conversations = {}
    for thread in threads:
        other = thread.mechanic if thread.customer_id == user.pk else thread.customer
        if other.pk == user.pk:
            continue
        message = latest.get(thread.latest_id)
        existing = conversations.get(other.pk)
        if existing is None:
            conversations[other.pk] = {
                "thread": thread, "other_person": other, "latest_message": message,
            }
        elif message and (existing["latest_message"] is None or message.id > existing["latest_message"].id):
            existing.update(thread=thread, latest_message=message)
    return sorted(conversations.values(), key=lambda item: (
        item["latest_message"].created_at if item["latest_message"] else item["thread"].updated_at
    ), reverse=True)
