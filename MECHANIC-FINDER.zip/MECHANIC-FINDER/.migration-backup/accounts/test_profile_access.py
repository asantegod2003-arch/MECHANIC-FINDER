from django.contrib.auth.models import User
from django.test import Client, TestCase
from django.urls import reverse

from .models import ChatThread, Profile
from rescue.models import RescueRequest


class MissingProfileRecoveryTests(TestCase):
    password = "Roadside#Safe2026"

    def setUp(self):
        self.user = User.objects.create_user(
            username="legacy-account", email="legacy@example.test", password=self.password,
        )
        self.peer = User.objects.create_user(username="existing-mechanic")
        Profile.objects.create(user=self.peer, role="mechanic")

    def login(self, **changes):
        data = {"username": self.user.username, "password": self.password}
        data.update(changes)
        return self.client.post(reverse("login"), data)

    def test_valid_password_without_profile_goes_to_account_setup_not_login_error(self):
        response = self.login()
        self.assertRedirects(response, reverse("account_setup"))
        self.assertIn("_auth_user_id", self.client.session)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())
        self.assertContains(self.client.get(reverse("account_setup")), "Restore account access")

    def test_wrong_password_cannot_enter_setup_or_create_a_profile(self):
        self.assertContains(self.login(password="incorrect"), "Incorrect username")
        self.assertNotIn("_auth_user_id", self.client.session)
        self.assertEqual(self.client.get(reverse("account_setup")).status_code, 302)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_restore_both_roles_preserves_password_and_ignores_privilege_or_user_injection(self):
        for role in ("customer", "mechanic"):
            with self.subTest(role=role):
                self.client.force_login(self.user)
                response = self.client.post(reverse("account_setup"), {
                    "role": role, "user": self.peer.pk, "is_superuser": "1", "is_verified": "1",
                })
                self.assertRedirects(response, reverse(f"{role}_dashboard"))
                self.user.refresh_from_db()
                self.assertEqual(self.user.profile.role, role)
                self.assertFalse(self.user.is_superuser)
                self.assertTrue(self.user.check_password(self.password))
                self.assertFalse(self.user.profile.is_verified)
                self.assertFalse(self.user.profile.available)
                self.user.profile.delete()
                self.user = User.objects.get(pk=self.user.pk)
        self.peer.refresh_from_db()
        self.assertEqual(self.peer.profile.role, "mechanic")

    def test_existing_account_cannot_change_role_via_setup(self):
        Profile.objects.create(user=self.user, role="customer")
        self.client.force_login(self.user)
        self.assertRedirects(self.client.post(reverse("account_setup"), {"role": "mechanic"}),
                             reverse("customer_dashboard"))
        self.user.refresh_from_db()
        self.assertEqual(self.user.profile.role, "customer")

    def test_setup_validates_role_and_checks_csrf(self):
        self.client.force_login(self.user)
        self.assertContains(self.client.post(reverse("account_setup"), {"role": "admin"}),
                            "Select a valid choice")
        self.assertContains(self.client.post(reverse("account_setup"), {}), "This field is required")
        secured = Client(enforce_csrf_checks=True)
        secured.force_login(self.user)
        self.assertEqual(secured.post(reverse("account_setup"), {"role": "mechanic"}).status_code, 403)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_existing_customer_history_recovers_customer_role_automatically(self):
        ChatThread.objects.create(customer=self.user, mechanic=self.peer)
        self.assertRedirects(self.login(username=self.user.email.upper()), reverse("customer_dashboard"))
        self.assertEqual(Profile.objects.get(user=self.user).role, "customer")
        self.assertEqual(self.user.customer_chat_threads.count(), 1)

    def test_existing_mechanic_history_recovers_mechanic_without_publishing_presence(self):
        customer = User.objects.create_user(username="past-customer")
        RescueRequest.objects.create(
            customer=customer, mechanic=self.user, vehicle_problem="Engine",
            location="Accra", phone_number="private", status="completed",
        )
        self.assertRedirects(self.login(), reverse("mechanic_dashboard"))
        profile = Profile.objects.get(user=self.user)
        self.assertEqual(profile.role, "mechanic")
        self.assertFalse(profile.available)
        self.assertEqual(self.user.assigned_jobs.count(), 1)

    def test_conflicting_history_requires_the_owner_to_choose(self):
        ChatThread.objects.create(customer=self.user, mechanic=self.peer)
        ChatThread.objects.create(customer=self.peer, mechanic=self.user)
        self.assertRedirects(self.login(), reverse("account_setup"))
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_signed_in_missing_profile_redirects_from_dashboards_home_and_chat(self):
        self.client.force_login(self.user)
        for path in ("/", "/customer/dashboard/", "/mechanic/dashboard/"):
            response = self.client.get(path)
            self.assertEqual(response.status_code, 302)
            self.assertTrue(response.url.startswith(reverse("account_setup") + "?next="))
        self.assertContains(self.client.get("/messages/"), "Restore account type")
        response = self.client.get("/notifications/poll/", HTTP_ACCEPT="application/json")
        self.assertEqual(response.status_code, 409)
        self.assertTrue(response.json()["setup_required"])
        # Leaving must stay available even when the account has no profile.
        self.assertEqual(self.client.post(reverse("leave_interface")).status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_setup_restores_own_invalid_role_without_erasing_other_profile_fields(self):
        Profile.objects.create(user=self.user, role="obsolete", service_area="Tema")
        self.client.force_login(self.user)
        self.assertRedirects(self.client.post(reverse("account_setup"), {"role": "customer"}),
                             reverse("customer_dashboard"))
        self.user.refresh_from_db()
        self.assertEqual(self.user.profile.service_area, "Tema")
        self.assertEqual(self.user.profile.role, "customer")

    def test_recovery_preserves_safe_destination_and_rejects_external_redirects(self):
        response = self.login(next="/messages/")
        self.assertIn("next=%2Fmessages%2F", response.url)
        self.assertRedirects(self.client.post(reverse("account_setup"), {
            "role": "customer", "next": "/messages/",
        }), "/messages/")
        self.assertRedirects(self.client.get(reverse("account_setup"), {
            "next": "https://attacker.example/",
        }), reverse("customer_dashboard"))

    def test_staff_without_an_app_profile_can_still_use_admin(self):
        self.user.is_staff = True
        self.user.save(update_fields=["is_staff"])
        self.client.force_login(self.user)
        self.assertEqual(self.client.get("/admin/").status_code, 200)
