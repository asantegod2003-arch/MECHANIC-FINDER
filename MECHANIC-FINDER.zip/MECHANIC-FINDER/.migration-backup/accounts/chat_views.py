import logging
import re

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, render
from django.views.decorators.http import require_GET

from .models import ChatMessage
from .conversations import conversation_summaries
from .profile_access import resolve_app_profile
from .voice_storage import read_voice


logger = logging.getLogger(__name__)


def serialize_message(message):
    from django.urls import reverse
    return {
        "id": message.id,
        "sender_id": message.sender_id,
        "sender_name": message.sender.get_full_name() or message.sender.username,
        "body": message.body,
        "created_at": message.created_at.isoformat(),
        "audio_url": reverse("voice_message_audio", args=[message.id]) if message.is_voice else None,
        "audio_duration": message.audio_duration,
    }


@login_required
@require_GET
def messages_inbox(request):
    conversations = conversation_summaries(request.user, limit=100)
    profile = resolve_app_profile(request.user)
    role = profile.role if profile else None
    if role == "customer":
        contacts = User.objects.filter(profile__role="mechanic", profile__available=True, is_active=True)
    elif role == "mechanic":
        contacts = User.objects.filter(
            rescue_requests__mechanic=request.user, profile__role="customer", is_active=True,
        ).distinct()
    else:
        contacts = User.objects.none()
    return render(request, "accounts/messages_inbox.html", {
        "conversations": conversations, "contacts": contacts.order_by("username")[:50],
        "needs_account_setup": role is None,
    })


@login_required
@require_GET
def voice_message_audio(request, message_id):
    message = get_object_or_404(
        ChatMessage.objects.select_related("thread").filter(
            Q(thread__customer=request.user) | Q(thread__mechanic=request.user)
        ),
        pk=message_id,
    )
    if not message.is_voice:
        return HttpResponse(status=404)
    try:
        audio = read_voice(message.audio_object_key)
    except Exception as error:
        logger.warning("Voice playback unavailable: %s", type(error).__name__)
        return JsonResponse({"error": "Voice recording is temporarily unavailable. Please try again."}, status=503)
    total = len(audio)
    start, end, status = 0, total - 1, 200
    range_header = request.headers.get("Range")
    if range_header:
        match = re.fullmatch(r"bytes=(\d{0,20})-(\d{0,20})", range_header)
        if not match or not any(match.groups()):
            response = HttpResponse(status=416)
            response["Content-Range"] = f"bytes */{total}"
            return response
        first, last = match.groups()
        if first:
            start = int(first)
            end = min(int(last), total - 1) if last else total - 1
        else:
            start = max(0, total - int(last))
        if start >= total or start > end:
            response = HttpResponse(status=416)
            response["Content-Range"] = f"bytes */{total}"
            return response
        status = 206
    response = HttpResponse(audio[start:end + 1], content_type=message.audio_mime, status=status)
    response["Accept-Ranges"] = "bytes"
    response["Content-Length"] = end - start + 1
    response["Cache-Control"] = "private, no-store"
    response["X-Content-Type-Options"] = "nosniff"
    response["Content-Disposition"] = 'inline; filename="voice-message.' + message.audio_object_key.rsplit(".", 1)[-1] + '"'
    if status == 206:
        response["Content-Range"] = f"bytes {start}-{end}/{total}"
    return response
