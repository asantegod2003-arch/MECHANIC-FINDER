from django.db import models
from django.contrib.auth.models import User


class Profile(models.Model):

    ROLE_CHOICES = (
        ("customer", "Customer"),
        ("mechanic", "Mechanic"),
    )

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE
    )

    role = models.CharField(
        max_length=20,
        choices=ROLE_CHOICES
    )

    # Public directory details entered and maintained by the mechanic.
    service_area = models.CharField(max_length=150, blank=True)
    repair_specialties = models.CharField(max_length=500, blank=True)

    # ==========================
    # MECHANIC LIVE LOCATION
    # ==========================

    latitude = models.FloatField(
        null=True,
        blank=True
    )

    longitude = models.FloatField(
        null=True,
        blank=True
    )

    location_updated_at = models.DateTimeField(
        null=True,
        blank=True
    )

    # Whether the mechanic is available to receive jobs
    available = models.BooleanField(
        default=True
    )

    def __str__(self):
        return f"{self.user.username} ({self.role})"

    @property
    def is_verified(self):
        application = getattr(self.user, "verification_application", None)
        return bool(application and application.status == "verified")


class Notification(models.Model):
    recipient = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="app_notifications",
    )
    title = models.CharField(max_length=120)
    message = models.CharField(max_length=300)
    url = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    read_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [
            models.Index(fields=["recipient", "read_at", "id"]),
        ]

    @property
    def is_read(self):
        return self.read_at is not None

    def __str__(self):
        return f"{self.recipient.username}: {self.title}"


class ChatThread(models.Model):
    customer = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="customer_chat_threads",
    )
    mechanic = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="mechanic_chat_threads",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-updated_at", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["customer", "mechanic"],
                name="unique_customer_mechanic_chat",
            ),
        ]

    def __str__(self):
        return f"{self.customer.username} ↔ {self.mechanic.username}"


class ChatMessage(models.Model):
    thread = models.ForeignKey(
        ChatThread,
        on_delete=models.CASCADE,
        related_name="messages",
    )
    sender = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="sent_chat_messages",
    )
    body = models.TextField(max_length=2000, blank=True)
    audio_object_key = models.CharField(max_length=255, blank=True, default="")
    audio_mime = models.CharField(max_length=80, blank=True, default="")
    audio_duration = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at", "id"]

    def __str__(self):
        return f"Message from {self.sender.username} in chat {self.thread_id}"

    @property
    def is_voice(self):
        return bool(self.audio_object_key)


class MechanicVerification(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="verification_application")
    business_name = models.CharField(max_length=150)
    contact_number = models.CharField(max_length=30)
    service_area = models.CharField(max_length=150)
    experience = models.TextField(max_length=2000)
    credential_reference = models.CharField(max_length=255)
    status = models.CharField(max_length=12, default="pending", choices=[
        ("pending", "Awaiting review"), ("verified", "Verified"), ("rejected", "Changes needed"),
    ])
    identity_checked = models.BooleanField(default=False)
    contact_checked = models.BooleanField(default=False)
    qualifications_checked = models.BooleanField(default=False)
    review_notes = models.TextField(blank=True, help_text="Private evidence of checks performed; never displayed publicly.")
    public_feedback = models.CharField(max_length=500, blank=True, help_text="Feedback shown to this mechanic.")
    reviewed_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    reviewed_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.business_name} — {self.get_status_display()}"


class RecoveryRateLimit(models.Model):
    key = models.CharField(max_length=64, primary_key=True)
    window_started = models.DateTimeField()
    count = models.PositiveIntegerField(default=0)