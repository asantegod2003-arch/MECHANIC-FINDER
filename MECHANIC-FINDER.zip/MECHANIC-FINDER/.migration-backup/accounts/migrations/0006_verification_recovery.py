from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ("accounts", "0005_chatmessage_voice_notes"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel(
            name="RecoveryRateLimit",
            fields=[
                ("key", models.CharField(max_length=64, primary_key=True, serialize=False)),
                ("window_started", models.DateTimeField()),
                ("count", models.PositiveIntegerField(default=0)),
            ],
        ),
        migrations.CreateModel(
            name="MechanicVerification",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("business_name", models.CharField(max_length=150)),
                ("contact_number", models.CharField(max_length=30)),
                ("service_area", models.CharField(max_length=150)),
                ("experience", models.TextField(max_length=2000)),
                ("credential_reference", models.CharField(max_length=255)),
                ("status", models.CharField(choices=[
                    ("pending", "Awaiting review"), ("verified", "Verified"), ("rejected", "Changes needed"),
                ], default="pending", max_length=12)),
                ("identity_checked", models.BooleanField(default=False)),
                ("contact_checked", models.BooleanField(default=False)),
                ("qualifications_checked", models.BooleanField(default=False)),
                ("review_notes", models.TextField(blank=True, help_text="Private evidence of checks performed; never displayed publicly.")),
                ("public_feedback", models.CharField(blank=True, max_length=500, help_text="Feedback shown to this mechanic.")),
                ("reviewed_at", models.DateTimeField(blank=True, null=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("reviewed_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="+", to=settings.AUTH_USER_MODEL)),
                ("user", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name="verification_application", to=settings.AUTH_USER_MODEL)),
            ],
        ),
    ]
