from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("accounts", "0006_verification_recovery"),
    ]

    operations = [
        migrations.AddField(
            model_name="profile",
            name="service_area",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.AddField(
            model_name="profile",
            name="repair_specialties",
            field=models.CharField(blank=True, max_length=500),
        ),
    ]
