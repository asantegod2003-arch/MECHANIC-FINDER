from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("accounts", "0004_profile_location_updated_at")]
    operations = [
        migrations.AlterField(
            model_name="chatmessage", name="body",
            field=models.TextField(blank=True, max_length=2000),
        ),
        migrations.AddField(
            model_name="chatmessage", name="audio_object_key",
            field=models.CharField(blank=True, default="", max_length=255),
        ),
        migrations.AddField(
            model_name="chatmessage", name="audio_mime",
            field=models.CharField(blank=True, default="", max_length=80),
        ),
        migrations.AddField(
            model_name="chatmessage", name="audio_duration",
            field=models.PositiveSmallIntegerField(default=0),
        ),
    ]
