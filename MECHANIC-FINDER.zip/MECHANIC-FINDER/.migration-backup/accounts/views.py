import logging
import time

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db import IntegrityError, transaction
from django.db.models import Q, Avg, Count
from django.contrib.auth.models import User
from django.http import JsonResponse, HttpResponseForbidden
from django.shortcuts import get_object_or_404
from django.urls import reverse
from django.utils.http import url_has_allowed_host_and_scheme
from django.utils import timezone
from django.views.decorators.http import require_GET, require_http_methods
from urllib.parse import urlencode, urlsplit

from .models import ChatMessage, ChatThread, Notification, Profile
from .forms import AccountRoleForm, PublicMechanicProfileForm, SignUpForm
from .profile_access import resolve_app_profile
from .conversations import conversation_summaries, threads_for
from .notifications import create_notification
from django.core.exceptions import ValidationError
from .chat_views import serialize_message
from .voice_storage import remove_voice, store_voice, validate_audio

from rescue.models import RescueRequest


logger = logging.getLogger(__name__)



# ==========================
# HOME PAGE
# ==========================

def home(request):

    if request.user.is_authenticated and request.GET.get("info") != "1":

        try:

            role = request.user.profile.role

            if role == "customer":
                return redirect("customer_dashboard")

            elif role == "mechanic":
                return redirect("mechanic_dashboard")


        except Profile.DoesNotExist:

            pass


    return render(
        request,
        "accounts/home.html"
    )


def mechanic_directory(request):
    query = request.GET.get("q", "").strip()[:100]
    service_area = request.GET.get("area", "").strip()[:150]
    specialty = request.GET.get("specialty", "").strip()[:100]
    mechanics = Profile.objects.filter(
        role="mechanic",
        available=True,
    ).select_related("user", "user__verification_application").annotate(
        average_rating=Avg("user__assigned_jobs__review__rating", filter=Q(user__assigned_jobs__status="completed")),
        review_count=Count("user__assigned_jobs__review", filter=Q(user__assigned_jobs__status="completed"), distinct=True),
    )

    if query:
        mechanics = mechanics.filter(
            Q(user__username__icontains=query)
            | Q(user__first_name__icontains=query)
            | Q(user__last_name__icontains=query)
        )

    if service_area:
        mechanics = mechanics.filter(service_area__icontains=service_area)
    if specialty:
        mechanics = mechanics.filter(repair_specialties__icontains=specialty)

    page = Paginator(mechanics.order_by("user__username"), 30).get_page(
        request.GET.get("page")
    )
    return render(
        request,
        "accounts/mechanic_directory.html",
        {
            "mechanics": page,
            "query": query,
            "service_area": service_area,
            "specialty": specialty,
            "has_filters": bool(query or service_area or specialty),
        },
    )




# ==========================
# SIGN UP
# ==========================

def signup(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)

        if form.is_valid():
            try:
                with transaction.atomic():
                    user = form.save(commit=False)
                    user.set_password(form.cleaned_data["password"])
                    user.save()

                    Profile.objects.create(
                        user=user,
                        role=form.cleaned_data["role"],
                    )
                    create_notification(
                        recipient=user,
                        title="Welcome to Mechanic Finder",
                        message="Your account is ready. You can now find help or accept nearby jobs.",
                        url=reverse("home"),
                    )
            except IntegrityError:
                if User.objects.filter(
                    username__iexact=form.cleaned_data.get("username", "")
                ).exists():
                    form.add_error(
                        "username",
                        "That username is already in use. Please choose another.",
                    )
                    logger.info("Signup rejected by a username uniqueness constraint.")
                else:
                    form.add_error(
                        None,
                        "We couldn’t finish creating your account. Please try again.",
                    )
                    logger.error("Signup database transaction could not be completed.")
            else:
                messages.success(
                    request,
                    "Account created successfully. You can now log in.",
                )
                return redirect("login")
        else:
            # Record only which fields failed; never log submitted credentials.
            logger.info(
                "Signup form validation failed for fields: %s",
                ", ".join(form.errors.keys()),
            )

    else:
        form = SignUpForm()

    return render(request, "accounts/signup.html", {"form": form})



# ==========================
# LOGIN
# ==========================

def login_view(request):


    if request.method == "POST":


        identifier = request.POST.get("username", "").strip()
        matches = list(User.objects.filter(
            Q(username__iexact=identifier) | Q(email__iexact=identifier)
        ).exclude(username="").order_by("pk")[:2]) if identifier else []
        # Ambiguous legacy email addresses must never select an arbitrary account.
        password = request.POST.get("password")
        if len(matches) == 1:
            user = authenticate(request, username=matches[0].username, password=password)
        else:
            # Match password-hashing work without trying any ambiguous account.
            User().set_password(password or "")
            user = None



        if user is not None:


            login(request, user)
            request.session["last_user_activity"] = time.time()
            request.session.set_expiry(0)

            profile = resolve_app_profile(user)
            if profile is None:
                setup_url = reverse("account_setup")
                next_url = safe_account_next(request)
                if next_url:
                    setup_url += "?" + urlencode({"next": next_url})
                return redirect(setup_url)

            next_url = safe_account_next(request)
            if next_url:
                return redirect(next_url)

            return redirect("mechanic_dashboard" if profile.role == "mechanic" else "customer_dashboard")

        else:


            messages.error(

                request,

                "Incorrect username, email address or password. Please check your details and try again."

            )



    return render(

        request,

        "accounts/login.html",
        {"next": request.POST.get("next", request.GET.get("next", ""))},

    )


def safe_account_next(request):
    candidate = request.POST.get("next") or request.GET.get("next", "")
    if candidate and url_has_allowed_host_and_scheme(
        candidate, allowed_hosts={request.get_host()}, require_https=request.is_secure(),
    ):
        # Avoid authentication loops and POST-only endpoints as destinations.
        path = urlsplit(candidate).path
        if path not in {reverse("login"), reverse("logout"), reverse("leave_interface"), reverse("account_setup")}:
            return candidate
    return ""


@login_required
@require_http_methods(["GET", "POST"])
def account_setup(request):
    profile = resolve_app_profile(request.user)
    if profile is not None:
        return redirect(safe_account_next(request) or (
            "mechanic_dashboard" if profile.role == "mechanic" else "customer_dashboard"
        ))
    form = AccountRoleForm(request.POST if request.method == "POST" else None)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            # Serialize duplicate submissions without changing an existing role.
            User.objects.select_for_update().get(pk=request.user.pk)
            profile = Profile.objects.filter(user=request.user).first()
            if profile is None:
                profile = Profile.objects.create(
                    user=request.user, role=form.cleaned_data["role"], available=False,
                )
            elif profile.role not in ("customer", "mechanic"):
                profile.role = form.cleaned_data["role"]
                profile.save(update_fields=["role"])
            request.user.profile = profile
        messages.success(request, "Your account access has been restored. Your password has not changed.")
        return redirect(safe_account_next(request) or (
            "mechanic_dashboard" if profile.role == "mechanic" else "customer_dashboard"
        ))
    return render(request, "accounts/account_setup.html", {
        "form": form, "next": safe_account_next(request),
    })


@require_http_methods(["POST"])
@login_required
def session_activity(request):
    """An interaction-only heartbeat; never called by background polling."""
    return JsonResponse({"active": True})


@require_http_methods(["POST"])
def leave_interface(request):
    """Idempotent, CSRF-protected sign-out when the signed-in UI is backgrounded."""
    if request.user.is_authenticated:
        RescueRequest.objects.filter(
            mechanic=request.user, live_tracking_enabled=True,
        ).update(live_tracking_enabled=False)
    logout(request)
    return JsonResponse({"logged_out": True})






# ==========================
# LOGOUT
# ==========================

def logout_view(request):


    logout(request)



    messages.success(

        request,

        "You have been logged out successfully."

    )



    return redirect("home")

# ==========================
# CUSTOMER DASHBOARD
# ==========================

@login_required
def customer_dashboard(request):

    # Only customers can access this dashboard

    if request.user.profile.role != "customer":

        return redirect("mechanic_dashboard")



    requests = RescueRequest.objects.filter(

        customer=request.user

    ).order_by("-created_at")
    chat_threads = _dashboard_chat_threads(request.user)



    return render(

        request,

        "dashboard/customer_dashboard.html",

        {
            "requests": requests,
            "chat_threads": chat_threads,
        }

    )





# ==========================
# MECHANIC DASHBOARD
# ==========================

@login_required
def mechanic_dashboard(request):


    # Only mechanics can access this dashboard

    if request.user.profile.role != "mechanic":

        return redirect("customer_dashboard")

    profile = request.user.profile

    if request.method == "POST" and "toggle_available" in request.POST:
        profile.available = not profile.available
        profile.save(update_fields=["available"])
        return redirect("mechanic_dashboard")

    public_profile_form = PublicMechanicProfileForm(instance=profile)
    if request.method == "POST" and "save_public_profile" in request.POST:
        public_profile_form = PublicMechanicProfileForm(request.POST, instance=profile)
        if public_profile_form.is_valid():
            public_profile_form.save()
            messages.success(request, "Your public service details have been updated.")
            return redirect("mechanic_dashboard")

    # Requests waiting for mechanics

    available_requests = RescueRequest.objects.none()

    if profile.available:
        available_requests = RescueRequest.objects.filter(
            status="pending"
        ).order_by("-created_at")






    # Jobs accepted by this mechanic

    my_jobs = RescueRequest.objects.filter(

        mechanic=request.user

    ).order_by("-created_at")

    chat_threads = _dashboard_chat_threads(request.user)





    return render(

        request,

        "dashboard/mechanic_dashboard.html",

        {
            "available_requests": available_requests,
            "my_jobs": my_jobs,
            "chat_threads": chat_threads,
            "profile": profile,
            "public_profile_form": public_profile_form,
        }

    )


@login_required
@require_http_methods(["POST"])
def update_presence_location(request):
    if not hasattr(request.user, "profile") or request.user.profile.role != "mechanic":
        return JsonResponse({"success": False, "message": "Not allowed."}, status=403)
    profile = request.user.profile
    if not profile.available:
        return JsonResponse({"success": False, "message": "Go online to update your location."}, status=403)

    try:
        latitude = float(request.POST.get("latitude"))
        longitude = float(request.POST.get("longitude"))
    except (TypeError, ValueError):
        return JsonResponse({"success": False, "message": "Invalid location."}, status=400)
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        return JsonResponse({"success": False, "message": "Invalid location."}, status=400)

    profile.latitude = latitude
    profile.longitude = longitude
    profile.location_updated_at = timezone.now()
    profile.save(update_fields=["latitude", "longitude", "location_updated_at"])
    return JsonResponse({"success": True})


def _dashboard_chat_threads(user):
    threads = []
    for conversation in conversation_summaries(user):
        thread = conversation["thread"]
        thread.other_person = conversation["other_person"]
        thread.latest_message = conversation["latest_message"]
        threads.append(thread)
    return threads


def _chat_participants(current_user, other_user_id):
    if current_user.pk == other_user_id:
        return None, None
    other_user = get_object_or_404(
        User.objects.select_related("profile"),
        pk=other_user_id,
    )
    existing = threads_for(current_user, other_user_id).select_related("customer", "mechanic").first()
    if existing is not None:
        # Existing private history belongs to these two users even if a role
        # profile is missing, recovered differently, offline, or later changed.
        return existing.customer, existing.mechanic
    try:
        current_profile = resolve_app_profile(current_user)
        current_role = current_profile.role if current_profile else None
        other_role = other_user.profile.role
    except Profile.DoesNotExist:
        return None, None

    if current_role == "customer" and other_role == "mechanic":
        return current_user, other_user
    if current_role == "mechanic" and other_role == "customer":
        return other_user, current_user
    return None, None


@login_required
@require_http_methods(["GET", "POST"])
def chat_thread(request, other_user_id):
    customer, mechanic = _chat_participants(request.user, other_user_id)
    if customer is None:
        return HttpResponseForbidden("Chat is only available between a customer and a mechanic.")

    thread, _ = ChatThread.objects.get_or_create(
        customer=customer,
        mechanic=mechanic,
    )
    conversation_url = reverse("chat_thread", args=[other_user_id])
    form_error = ""
    draft_body = ""

    if request.method == "POST":
        body = request.POST.get("body", "").strip()
        draft_body = body
        audio = request.FILES.get("audio")
        audio_key, mime, duration = "", "", 0
        json_request = "application/json" in request.headers.get("Accept", "")
        error_status = 400
        try:
            if not body and not audio:
                raise ValidationError("Write a message or record a voice message before sending.")
            if len(body) > 2000:
                raise ValidationError("Messages must be 2,000 characters or fewer.")
            if audio:
                data, mime, duration, extension = validate_audio(audio, request.POST.get("audio_duration"))
                audio_key = store_voice(data, extension)
            with transaction.atomic():
                message = ChatMessage.objects.create(
                    thread=thread, sender=request.user, body=body,
                    audio_object_key=audio_key, audio_mime=mime, audio_duration=duration,
                )
                thread.save(update_fields=["updated_at"])
                recipient = mechanic if request.user == customer else customer
                create_notification(
                    recipient=recipient,
                    title=f"New message from {request.user.get_full_name() or request.user.username}",
                    message=body or "Sent you a voice message. Open the chat to listen.",
                    url=reverse("chat_thread", args=[request.user.id]),
                )
        except ValidationError as error:
            form_error = " ".join(error.messages)
        except Exception as error:
            error_status = 503
            form_error = "Your message could not be sent. Please try again. Voice recording storage may need setup."
            logger.warning("Chat send unavailable: %s", type(error).__name__)
        else:
            if json_request:
                return JsonResponse({"message": serialize_message(message)}, status=201)
            return redirect("chat_thread", other_user_id=other_user_id)
        if audio_key:
            try:
                remove_voice(audio_key)
            except Exception as error:
                logger.warning("Unused voice upload cleanup failed: %s", type(error).__name__)
        if json_request:
            return JsonResponse({"error": form_error}, status=error_status)

    Notification.objects.filter(
        recipient=request.user,
        url=conversation_url,
        read_at__isnull=True,
    ).update(read_at=timezone.now())

    # Role changes can have produced a reverse-oriented legacy thread. Show
    # both histories to the same two participants without deleting/merging rows.
    chat_messages = list(ChatMessage.objects.filter(
        thread__in=threads_for(request.user, other_user_id),
    ).select_related("sender").order_by("id"))
    return render(
        request,
        "accounts/chat_thread.html",
        {
            "thread": thread,
            "chat_messages": chat_messages,
            "other_person": mechanic if request.user == customer else customer,
            "latest_message_id": chat_messages[-1].id if chat_messages else 0,
            "form_error": form_error,
            "draft_body": draft_body,
        },
    )


@login_required
@require_GET
def poll_chat_messages(request, other_user_id):
    customer, mechanic = _chat_participants(request.user, other_user_id)
    if customer is None:
        return HttpResponseForbidden("Not allowed.")
    try:
        after_id = max(0, int(request.GET.get("after", "0")))
    except (TypeError, ValueError):
        after_id = 0

    new_messages = ChatMessage.objects.filter(
        thread__in=threads_for(request.user, other_user_id), id__gt=after_id,
    ).select_related("sender").order_by("id")[:50]
    return JsonResponse({
        "messages": [
            serialize_message(message)
            for message in new_messages
        ]
    })


@login_required
@require_GET
def notification_list(request):
    notifications = Notification.objects.filter(recipient=request.user)
    notifications.filter(read_at__isnull=True).update(read_at=timezone.now())
    return render(
        request,
        "accounts/notifications.html",
        {"notifications": notifications[:100]},
    )


@login_required
@require_GET
def poll_notifications(request):
    try:
        after_id = max(0, int(request.GET.get("after", "0")))
    except (TypeError, ValueError):
        after_id = 0

    notifications = Notification.objects.filter(
        recipient=request.user,
        read_at__isnull=True,
        id__gt=after_id,
    ).order_by("id")[:20]
    items = [
        {
            "id": item.id,
            "title": item.title,
            "message": item.message,
            "url": item.url or reverse("home"),
        }
        for item in notifications
    ]
    return JsonResponse({
        "notifications": items,
        "unread_count": Notification.objects.filter(
            recipient=request.user,
            read_at__isnull=True,
        ).count(),
    })



