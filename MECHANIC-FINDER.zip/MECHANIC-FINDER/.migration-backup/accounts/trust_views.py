from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Avg, Count
from django.db import transaction
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods, require_GET

from rescue.models import RepairReview
from .models import MechanicVerification
from .trust_forms import VerificationForm


@login_required
@require_http_methods(["GET", "POST"])
@transaction.atomic
def mechanic_verification(request):
    if getattr(getattr(request.user, "profile", None), "role", None) != "mechanic":
        return HttpResponseForbidden("Only mechanics can apply for verification.")
    application = MechanicVerification.objects.select_for_update().filter(user=request.user).first()
    form = VerificationForm(request.POST or None, instance=application)
    if request.method == "POST":
        if application and application.status == "verified":
            messages.info(request, "Your verification is already approved. Contact an administrator to change reviewed details.")
            return redirect("mechanic_verification")
        if form.is_valid():
            application = form.save(commit=False)
            application.user = request.user
            application.status = "pending"
            application.identity_checked = application.contact_checked = application.qualifications_checked = False
            application.reviewed_by = None
            application.reviewed_at = None
            application.save()
            messages.success(request, "Application submitted. A site administrator must review your details before you receive a badge.")
            return redirect("mechanic_verification")
    return render(request, "accounts/verification.html", {"form": form, "application": application})


@require_GET
def mechanic_detail(request, mechanic_id):
    mechanic = get_object_or_404(
        User.objects.select_related("profile", "verification_application"),
        pk=mechanic_id, profile__role="mechanic", is_active=True,
    )
    reviews = RepairReview.objects.filter(
        job__mechanic=mechanic, job__status="completed",
    ).select_related("job__customer")
    aggregate = reviews.aggregate(average_rating=Avg("rating"), review_count=Count("id"))
    verification = getattr(mechanic, "verification_application", None) if mechanic.profile.is_verified else None
    return render(request, "accounts/mechanic_detail.html", {
        "mechanic": mechanic, "profile": mechanic.profile, "verification": verification,
        "reviews": reviews[:50], **aggregate,
    })
