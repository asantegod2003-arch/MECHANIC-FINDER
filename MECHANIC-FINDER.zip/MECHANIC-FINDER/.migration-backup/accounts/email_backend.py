"""Resend mail delivery using a key stored only in the project's Secrets."""
import json
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from django.conf import settings
from django.core.mail.backends.base import BaseEmailBackend
from django.core.exceptions import ImproperlyConfigured


class EmailDeliveryError(RuntimeError):
    """A safe delivery error that contains no key, recipient or reset token."""


class ResendEmailBackend(BaseEmailBackend):
    def send_messages(self, email_messages):
        if not settings.RESEND_API_KEY:
            raise ImproperlyConfigured("Configure the private Resend key before enabling email delivery.")
        sent = 0
        for message in email_messages:
            if not message.from_email or not settings.DEFAULT_FROM_EMAIL:
                raise ImproperlyConfigured("Configure a verified Resend sender before enabling recovery email.")
            if not message.recipients():
                continue
            if message.attachments:
                raise NotImplementedError("This recovery-mail backend does not support attachments.")
            payload = {
                "from": message.from_email, "to": message.to,
                "subject": message.subject, "text": message.body,
            }
            for name, value in (("cc", message.cc), ("bcc", message.bcc), ("reply_to", message.reply_to)):
                if value:
                    payload[name] = value
            for content, mimetype in getattr(message, "alternatives", []):
                if mimetype != "text/html":
                    raise NotImplementedError("Only plain text and HTML recovery messages are supported.")
                payload["html"] = content
            request = Request(
                "https://api.resend.com/emails", method="POST",
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Authorization": "Bearer " + settings.RESEND_API_KEY,
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "User-Agent": "MechanicFinderGhana/1.0",
                },
            )
            try:
                with urlopen(request, timeout=20) as response:
                    result = json.load(response)
                if not isinstance(result, dict) or not result.get("id"):
                    raise EmailDeliveryError("Resend did not acknowledge email delivery.")
            except HTTPError as error:
                # Do not expose provider response bodies or request headers.
                raise EmailDeliveryError(f"Resend email delivery failed (HTTP {error.code}).") from None
            except (URLError, OSError, ValueError):
                raise EmailDeliveryError("Resend email delivery could not be completed.") from None
            sent += 1
        return sent
