import time
from unittest.mock import patch

from django.contrib.auth.models import User
from django.test import TestCase

from .models import Profile


class EmailAccountTests(TestCase):
    password = "Roadside#Safe2026"

    def data(self, **changes):
        data = {
            "username": "", "email": "new@example.test", "role": "customer",
            "password": self.password, "confirm_password": self.password,
        }
        data.update(changes)
        return data

    def test_email_only_signup_and_login_for_both_roles(self):
        for role in ("customer", "mechanic"):
            email = f"{role}@example.test"
            self.assertRedirects(
                self.client.post("/signup/", self.data(email=email, role=role)), "/login/"
            )
            user = User.objects.get(email=email)
            self.assertEqual(user.profile.role, role)
            self.assertTrue(user.check_password(self.password))
            response = self.client.post("/login/", {
                "username": email.upper(), "password": self.password,
            })
            self.assertRedirects(response, f"/{role}/dashboard/")
            self.client.logout()

    def test_username_only_still_works(self):
        self.assertRedirects(self.client.post("/signup/", self.data(
            username="existing-style", email=""
        )), "/login/")
        self.assertRedirects(self.client.post("/login/", {
            "username": "existing-style", "password": self.password,
        }), "/customer/dashboard/")

    def test_duplicate_email_is_case_insensitive_and_does_not_create_user(self):
        User.objects.create_user(username="existing", email="NEW@example.test")
        response = self.client.post("/signup/", self.data())
        self.assertContains(response, "This email address is already in use.")
        self.assertEqual(User.objects.count(), 1)

    def test_email_or_username_required(self):
        response = self.client.post("/signup/", self.data(email=""))
        self.assertContains(response, "Enter an email address or choose a username.")
        self.assertEqual(User.objects.count(), 0)

    def test_invalid_email_is_explained(self):
        response = self.client.post("/signup/", self.data(email="invalid"))
        self.assertContains(response, "Enter a valid email address.")
        self.assertEqual(User.objects.count(), 0)

    def test_legacy_duplicate_email_is_not_used_to_select_any_account(self):
        for username in ("first", "second"):
            User.objects.create_user(username=username, email="shared@example.test",
                                     password=self.password)
        response = self.client.post("/login/", {
            "username": "shared@example.test", "password": self.password,
        })
        self.assertContains(response, "Incorrect username, email address or password")
        self.assertNotIn("_auth_user_id", self.client.session)
        # Legacy users can still use their distinct username.
        self.assertTrue(self.client.login(username="first", password=self.password))

    def test_inactive_account_and_wrong_password_cannot_login(self):
        user = User.objects.create_user(username="driver", email="driver@example.test",
                                       password=self.password, is_active=False)
        for password in (self.password, "incorrect"):
            response = self.client.post("/login/", {
                "username": user.email, "password": password,
            })
            self.assertContains(response, "Incorrect username, email address or password")
            self.assertNotIn("_auth_user_id", self.client.session)

    def test_identifier_cannot_conflict_with_another_accounts_email(self):
        User.objects.create_user(username="owner", email="name@example.test")
        response = self.client.post("/signup/", self.data(
            username="NAME@example.test", email="other@example.test",
        ))
        self.assertContains(response, "This username is already in use.")
        self.assertEqual(User.objects.count(), 1)


class IdleSessionTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="idle-user", password="Safe#Road2026")
        Profile.objects.create(user=self.user, role="customer")
        self.client.force_login(self.user)
        self.now = time.time()
        session = self.client.session
        session["last_user_activity"] = self.now
        session.save()

    def test_expired_session_cannot_access_dashboard(self):
        with patch("accounts.middleware.time.time", return_value=self.now + 10800):
            response = self.client.get("/customer/dashboard/")
        self.assertRedirects(response, "/login/?next=/customer/dashboard/", fetch_redirect_response=False)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_active_request_renews_session_for_three_hours(self):
        with patch("accounts.middleware.time.time", return_value=self.now + 7200):
            self.assertEqual(self.client.get("/customer/dashboard/").status_code, 200)
        self.assertEqual(self.client.session["last_user_activity"], self.now + 7200)
        self.assertEqual(self.client.session.get_expiry_age(), 10800)

    def test_background_requests_do_not_renew_idle_timer(self):
        for path, method in (
            ("/notifications/poll/", "get"),
            ("/chat/999/messages/", "get"),
            ("/mechanic/location/", "post"),
            ("/rescue/update-location/999/", "post"),
            ("/rescue/tracking/999/location/", "get"),
        ):
            with patch("accounts.middleware.time.time", return_value=self.now + 7200):
                getattr(self.client, method)(path)
            self.assertEqual(self.client.session["last_user_activity"], self.now)

    def test_interaction_heartbeat_renews_session_but_not_after_expiry(self):
        with patch("accounts.middleware.time.time", return_value=self.now + 100):
            self.assertEqual(self.client.post("/account/activity/").status_code, 200)
        self.assertEqual(self.client.session["last_user_activity"], self.now + 100)
        with patch("accounts.middleware.time.time", return_value=self.now + 10900):
            self.assertEqual(self.client.post("/account/activity/").status_code, 302)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_activity_endpoint_requires_post_and_authentication(self):
        self.assertEqual(self.client.get("/account/activity/").status_code, 405)
        self.client.logout()
        self.assertEqual(self.client.post("/account/activity/").status_code, 302)

    def test_login_sets_initial_activity_time(self):
        self.client.logout()
        self.client.post("/login/", {"username": "idle-user", "password": "Safe#Road2026"})
        self.assertAlmostEqual(self.client.session["last_user_activity"], time.time(), delta=5)
