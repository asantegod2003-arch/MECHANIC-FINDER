from math import asin, cos, radians, sin, sqrt
from datetime import timedelta

from django.urls import reverse
from django.utils import timezone

from .models import Notification, Profile


NEARBY_REQUEST_RADIUS_KM = 25


def create_notification(recipient, title, message, url=""):
    return Notification.objects.create(
        recipient=recipient,
        title=title,
        message=message[:300],
        url=url[:300],
    )


def _distance_km(latitude_a, longitude_a, latitude_b, longitude_b):
    earth_radius_km = 6371
    lat_delta = radians(latitude_b - latitude_a)
    lng_delta = radians(longitude_b - longitude_a)
    haversine = (
        sin(lat_delta / 2) ** 2
        + cos(radians(latitude_a))
        * cos(radians(latitude_b))
        * sin(lng_delta / 2) ** 2
    )
    return 2 * earth_radius_km * asin(sqrt(min(1, haversine)))


def notify_nearby_mechanics(rescue_request):
    latitude = rescue_request.customer_latitude
    longitude = rescue_request.customer_longitude
    if latitude is None or longitude is None:
        return 0
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        return 0

    profiles = Profile.objects.filter(
        role="mechanic",
        available=True,
        latitude__isnull=False,
        longitude__isnull=False,
        location_updated_at__gte=timezone.now() - timedelta(minutes=10),
    ).select_related("user")

    notified = 0
    for profile in profiles:
        if not (-90 <= profile.latitude <= 90 and -180 <= profile.longitude <= 180):
            continue
        distance = _distance_km(
            latitude,
            longitude,
            profile.latitude,
            profile.longitude,
        )
        if distance > NEARBY_REQUEST_RADIUS_KM:
            continue

        create_notification(
            recipient=profile.user,
            title="Nearby rescue request",
            message=(
                f"A driver nearby needs help with "
                f"{rescue_request.vehicle_problem}."
            ),
            url=reverse("mechanic_dashboard"),
        )
        notified += 1

    return notified
