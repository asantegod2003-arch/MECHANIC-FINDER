from django.test import TestCase
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
from django.db import IntegrityError
from unittest.mock import patch

from .models import ChatMessage, ChatThread, Notification, Profile


class SignupRegressionTests(TestCase):
    def signup_data(self, **overrides):
        data = {
            "first_name": "Test",
            "last_name": "Driver",
            "username": "registration-driver",
            "email": "driver@example.test",
            "role": "customer",
            "password": "Roadside#Safe2026",
            "confirm_password": "Roadside#Safe2026",
        }
        data.update(overrides)
        return data

    def test_invalid_signup_explains_error_and_keeps_non_password_details(self):
        response = self.client.post(
            "/signup/", self.signup_data(password="short", confirm_password="short")
        )
        self.assertContains(response, "We couldn’t create your account yet.")
        self.assertContains(response, "at least 8 characters")
        self.assertContains(response, 'value="registration-driver"')
        self.assertContains(response, 'value="driver@example.test"')
        self.assertNotContains(response, 'value="short"')
        self.assertFalse(User.objects.filter(username="registration-driver").exists())

    def test_password_mismatch_is_explained_without_creating_user(self):
        response = self.client.post(
            "/signup/", self.signup_data(confirm_password="Different#Password2026")
        )
        self.assertContains(response, "Passwords do not match.")
        self.assertFalse(User.objects.filter(username="registration-driver").exists())

    def test_both_account_roles_can_signup_and_login(self):
        for role in ("customer", "mechanic"):
            username = f"registered-{role}"
            response = self.client.post(
                "/signup/", self.signup_data(
                    username=username, role=role, email=f"{role}@example.test"
                )
            )
            self.assertRedirects(response, "/login/")
            user = User.objects.get(username=username)
            self.assertEqual(user.profile.role, role)
            self.assertTrue(self.client.login(username=username, password="Roadside#Safe2026"))
            self.client.logout()

    def test_failed_database_transaction_does_not_leave_partial_account(self):
        with patch("accounts.views.create_notification", side_effect=IntegrityError):
            response = self.client.post("/signup/", self.signup_data())
        self.assertContains(response, "We couldn’t finish creating your account.")
        self.assertFalse(User.objects.filter(username="registration-driver").exists())

    def test_password_whitespace_is_not_silently_changed(self):
        password = " Roadside#Safe2026 "
        response = self.client.post(
            "/signup/", self.signup_data(password=password, confirm_password=password)
        )
        self.assertRedirects(response, "/login/")
        self.assertTrue(User.objects.get(username="registration-driver").check_password(password))


class StartupSmokeTests(TestCase):
    def test_public_pages_load(self):
        for path in ("/", "/login/", "/signup/", "/mechanics/"):
            with self.subTest(path=path):
                self.assertEqual(self.client.get(path).status_code, 200)

    def test_dashboards_require_login(self):
        for path in ("/customer/dashboard/", "/mechanic/dashboard/"):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, 302)
                self.assertTrue(response.url.startswith("/login/"))

    def test_mechanic_directory_only_lists_available_mechanics(self):
        from django.contrib.auth.models import User

        from .models import Profile

        available = User.objects.create_user(username="online-mechanic")
        Profile.objects.create(user=available, role="mechanic", available=True)

        offline = User.objects.create_user(username="offline-mechanic")
        Profile.objects.create(user=offline, role="mechanic", available=False)

        customer = User.objects.create_user(username="private-customer")
        Profile.objects.create(user=customer, role="customer", available=True)

        response = self.client.get("/mechanics/")

        self.assertContains(response, "online-mechanic")
        self.assertNotContains(response, "offline-mechanic")
        self.assertNotContains(response, "private-customer")

    def test_mechanic_directory_search_filters_results(self):
        from django.contrib.auth.models import User

        from .models import Profile

        mechanic = User.objects.create_user(username="searchable-mechanic")
        Profile.objects.create(user=mechanic, role="mechanic", available=True)

        response = self.client.get("/mechanics/", {"q": "searchable"})

        self.assertContains(response, "searchable-mechanic")

    def test_mechanic_directory_filters_public_service_area_and_specialty(self):
        from .models import MechanicVerification

        mechanic = User.objects.create_user(username="accra-auto-tech")
        Profile.objects.create(
            user=mechanic,
            role="mechanic",
            available=True,
            service_area="Accra and Tema",
            repair_specialties="Engine repair, brakes",
            latitude=5.6037,
            longitude=-0.1870,
        )
        MechanicVerification.objects.create(
            user=mechanic,
            business_name="Accra Auto",
            contact_number="+233200000000",
            service_area="Private verification area",
            experience="Private verification details",
            credential_reference="Private reference",
        )
        other_mechanic = User.objects.create_user(username="kumasi-electrician")
        Profile.objects.create(
            user=other_mechanic,
            role="mechanic",
            available=True,
            service_area="Kumasi",
            repair_specialties="Electrical",
        )

        response = self.client.get(
            "/mechanics/", {"area": "Accra", "specialty": "brakes"}
        )

        self.assertContains(response, "accra-auto-tech")
        self.assertContains(response, "Accra and Tema")
        self.assertContains(response, "Engine repair, brakes")
        self.assertNotContains(response, "kumasi-electrician")
        self.assertNotContains(response, "5.6037")
        self.assertNotContains(response, "-0.187")
        self.assertNotContains(response, "+233200000000")
        self.assertNotContains(response, "Private verification area")

    def test_mechanic_can_edit_public_directory_details(self):
        mechanic = User.objects.create_user(username="profile-mechanic", password="safe-pass")
        profile = Profile.objects.create(user=mechanic, role="mechanic")
        self.client.force_login(mechanic)

        response = self.client.post(
            "/mechanic/dashboard/",
            {
                "save_public_profile": "1",
                "service_area": "  Cape Coast  ",
                "repair_specialties": "  Tyres, brakes, , ",
            },
        )

        self.assertRedirects(response, "/mechanic/dashboard/")
        profile.refresh_from_db()
        self.assertEqual(profile.service_area, "Cape Coast")
        self.assertEqual(profile.repair_specialties, "Tyres, brakes")


class AccountAndMessagingTests(TestCase):
    def create_user_with_profile(self, username, role, password="Roadside#Safe2026"):
        user = User.objects.create_user(username=username, password=password)
        Profile.objects.create(user=user, role=role)
        return user

    def test_signup_creates_welcome_notification(self):
        response = self.client.post(
            "/signup/",
            {
                "first_name": "Ama",
                "last_name": "Driver",
                "username": "new-driver",
                "email": "ama@example.com",
                "role": "customer",
                "password": "Roadside#Safe2026",
                "confirm_password": "Roadside#Safe2026",
            },
        )

        self.assertRedirects(response, "/login/")
        user = User.objects.get(username="new-driver")
        self.assertTrue(user.app_notifications.filter(title="Welcome to Mechanic Finder").exists())

    def test_signup_reports_username_already_in_use(self):
        self.create_user_with_profile("taken-name", "customer")

        response = self.client.post(
            "/signup/",
            {
                "username": "TAKEN-NAME",
                "email": "new@example.com",
                "role": "customer",
                "password": "Roadside#Safe2026",
                "confirm_password": "Roadside#Safe2026",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "This username is already in use.")

    def test_login_shows_clear_invalid_credentials_feedback(self):
        response = self.client.post(
            "/login/",
            {"username": "missing-user", "password": "incorrect"},
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Incorrect username, email address or password")
        self.assertContains(response, "alert-danger")

    def test_customer_can_message_mechanic_and_mechanic_gets_notification(self):
        customer = self.create_user_with_profile("chat-customer", "customer")
        mechanic = self.create_user_with_profile("chat-mechanic", "mechanic")
        self.client.force_login(customer)

        response = self.client.post(
            reverse("chat_thread", args=[mechanic.id]),
            {"body": "Can you help with a flat tyre?"},
        )

        self.assertRedirects(response, reverse("chat_thread", args=[mechanic.id]))
        message = ChatMessage.objects.get()
        self.assertEqual(message.sender, customer)
        self.assertEqual(message.body, "Can you help with a flat tyre?")
        self.assertTrue(mechanic.app_notifications.filter(title__startswith="New message").exists())

        chat_response = self.client.get(reverse("chat_thread", args=[mechanic.id]))
        self.assertEqual(chat_response.status_code, 200)
        self.assertContains(chat_response, "Can you help with a flat tyre?")
        poll_response = self.client.get(
            reverse("poll_chat_messages", args=[mechanic.id]),
            {"after": "0"},
        )
        self.assertEqual(poll_response.status_code, 200)
        self.assertEqual(poll_response.json()["messages"][0]["body"], message.body)

    def test_notification_page_marks_alerts_as_read(self):
        customer = self.create_user_with_profile("notification-customer", "customer")
        notification = Notification.objects.create(
            recipient=customer,
            title="Rescue update",
            message="A mechanic accepted your request.",
            url="/customer/dashboard/",
        )
        self.client.force_login(customer)

        poll_response = self.client.get(reverse("poll_notifications"))
        self.assertEqual(poll_response.status_code, 200)
        self.assertEqual(poll_response.json()["unread_count"], 1)
        self.assertEqual(
            poll_response.json()["notifications"][0]["title"],
            "Rescue update",
        )

        response = self.client.get(reverse("notification_list"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "A mechanic accepted your request.")
        notification.refresh_from_db()
        self.assertIsNotNone(notification.read_at)

    def test_mechanic_dashboard_lists_customer_conversations(self):
        customer = self.create_user_with_profile("dashboard-customer", "customer")
        mechanic = self.create_user_with_profile("dashboard-mechanic", "mechanic")
        ChatThread.objects.create(customer=customer, mechanic=mechanic)
        self.client.force_login(mechanic)

        response = self.client.get(reverse("mechanic_dashboard"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Customer messages")
        self.assertContains(response, "dashboard-customer")