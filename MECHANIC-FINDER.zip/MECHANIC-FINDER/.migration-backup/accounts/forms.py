from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from uuid import uuid4

from .models import Profile


class AccountRoleForm(forms.Form):
    role = forms.ChoiceField(
        label="Your original account type",
        choices=[("", "Choose your account type"), *Profile.ROLE_CHOICES],
        widget=forms.Select(attrs={"class": "form-select"}),
    )


class PublicMechanicProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ["service_area", "repair_specialties"]
        labels = {
            "service_area": "Service area",
            "repair_specialties": "Repair specialties",
        }
        help_texts = {
            "service_area": "For example: Accra, Tema, or Kasoa.",
            "repair_specialties": "List services separated by commas, such as engine repair, brakes, or electrical.",
        }
        widgets = {
            "service_area": forms.TextInput(attrs={
                "class": "form-control",
                "maxlength": "150",
                "placeholder": "e.g. Accra, Tema",
            }),
            "repair_specialties": forms.TextInput(attrs={
                "class": "form-control",
                "maxlength": "500",
                "placeholder": "e.g. engine repair, brakes, electrical",
            }),
        }

    def clean_service_area(self):
        return self.cleaned_data.get("service_area", "").strip()

    def clean_repair_specialties(self):
        specialties = self.cleaned_data.get("repair_specialties", "").strip()
        return ", ".join(part.strip() for part in specialties.split(",") if part.strip())


class SignUpForm(forms.ModelForm):

    username = forms.CharField(
        max_length=150,
        required=False,
        label="Username (optional with email)",
        help_text="Use an email address, a username, or both to create your account.",
        error_messages={"unique": "This username is already in use."},
        widget=forms.TextInput(attrs={
            "class": "form-control",
            "autocomplete": "username",
            "placeholder": "Choose a username",
        }),
    )
    password = forms.CharField(
        label="Password",
        strip=False,
        widget=forms.PasswordInput(attrs={
            "class": "form-control",
            "autocomplete": "new-password",
            "placeholder": "Create a password",
        })
    )

    confirm_password = forms.CharField(
        label="Confirm password",
        strip=False,
        widget=forms.PasswordInput(attrs={
            "class": "form-control",
            "autocomplete": "new-password",
            "placeholder": "Enter your password again",
        })
    )

    ROLE_CHOICES = [
        ("customer", "Customer"),
        ("mechanic", "Mechanic"),
    ]

    role = forms.ChoiceField(
        choices=ROLE_CHOICES,
        widget=forms.Select(attrs={"class": "form-select"})
    )

    class Meta:
        model = User
        labels = {
            "first_name": "First name",
            "last_name": "Last name",
            "username": "Username",
            "email": "Email address",
        }
        fields = [
            "first_name",
            "last_name",
            "username",
            "email",
            "password",
        ]

        widgets = {
            "first_name": forms.TextInput(attrs={
                "class": "form-control",
                "autocomplete": "given-name",
                "placeholder": "First name",
            }),
            "last_name": forms.TextInput(attrs={
                "class": "form-control",
                "autocomplete": "family-name",
                "placeholder": "Last name",
            }),
            "username": forms.TextInput(attrs={
                "class": "form-control",
                "autocomplete": "username",
                "placeholder": "Choose a username",
            }),
            "email": forms.EmailInput(attrs={
                "class": "form-control",
                "autocomplete": "email",
                "placeholder": "you@example.com",
            }),
        }

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        if username and (
            User.objects.filter(username__iexact=username).exists()
            or User.objects.filter(email__iexact=username).exists()
        ):
            raise forms.ValidationError("This username is already in use.")
        return username

    def clean_email(self):
        email = self.cleaned_data.get("email", "").strip().lower()
        if email and (
            User.objects.filter(email__iexact=email).exists()
            or User.objects.filter(username__iexact=email).exists()
        ):
            raise forms.ValidationError("This email address is already in use. Please log in instead.")
        return email

    def clean(self):

        cleaned_data = super().clean()

        if not cleaned_data.get("username") and not cleaned_data.get("email"):
            if "username" not in self.errors and "email" not in self.errors:
                self.add_error("email", "Enter an email address or choose a username.")
        elif not cleaned_data.get("username") and "username" not in self.errors:
            # Keep Django's existing user model and role relationships intact.
            cleaned_data["username"] = "member_" + uuid4().hex

        password = cleaned_data.get("password")
        confirm = cleaned_data.get("confirm_password")

        if password != confirm:
            self.add_error("confirm_password", "Passwords do not match.")
        if password:
            try:
                validate_password(password, user=User(
                    username=cleaned_data.get("username", ""),
                    email=cleaned_data.get("email", ""),
                    first_name=cleaned_data.get("first_name", ""),
                    last_name=cleaned_data.get("last_name", ""),
                ))
            except ValidationError as error:
                self.add_error("password", error)

        return cleaned_data