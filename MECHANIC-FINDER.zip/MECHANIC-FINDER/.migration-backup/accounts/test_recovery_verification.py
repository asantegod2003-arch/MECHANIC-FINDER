from datetime import timedelta
from unittest.mock import patch

from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.tokens import default_token_generator
from django.core import mail
from django.test import TestCase, RequestFactory, override_settings
from django.urls import reverse
from django.utils import timezone
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode

from .admin import VerificationReviewForm
from .models import MechanicVerification, Profile, RecoveryRateLimit


@override_settings(EMAIL_BACKEND="django.core.mail.backends.locmem.EmailBackend",
                   DEFAULT_FROM_EMAIL="recovery@example.test", RESEND_API_KEY="test-only-placeholder")
class PasswordRecoveryTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="recoverable", email="driver@example.test", password="Original#Safe2026"
        )

    def test_reset_email_uses_canonical_site_and_not_untrusted_request_host(self):
        response = self.client.post("/password/reset/", {"email": self.user.email}, HTTP_HOST="untrusted.example")
        self.assertRedirects(response, "/password/reset/sent/")
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("https://mechanic-finder.replit.app/password/reset/", mail.outbox[0].body)
        self.assertNotIn("untrusted.example", mail.outbox[0].body)

    def test_unknown_email_and_legacy_duplicate_email_have_same_public_response(self):
        known = self.client.post("/password/reset/", {"email": self.user.email})
        unknown = self.client.post("/password/reset/", {"email": "absent@example.test"})
        self.assertEqual(known.url, unknown.url)
        User.objects.create_user(username="legacy-duplicate", email=self.user.email, password="Password#2026")
        mail.outbox.clear()
        self.client.post("/password/reset/", {"email": self.user.email})
        self.assertEqual(len(mail.outbox), 0)

    def test_reset_link_changes_password_and_cannot_be_reused(self):
        uid = urlsafe_base64_encode(force_bytes(self.user.pk))
        token = default_token_generator.make_token(self.user)
        url = reverse("password_reset_confirm", args=[uid, token])
        first = self.client.get(url)
        self.assertEqual(first.status_code, 302)
        response = self.client.post(first.url, {
            "new_password1": "Changed#RoadSafe2026", "new_password2": "Changed#RoadSafe2026",
        })
        self.assertRedirects(response, "/password/reset/complete/")
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password("Changed#RoadSafe2026"))
        response = self.client.get(url, follow=True)
        self.assertFalse(response.context["validlink"])

    def test_expired_reset_token_is_rejected(self):
        uid = urlsafe_base64_encode(force_bytes(self.user.pk))
        from datetime import datetime
        with patch.object(default_token_generator, "_now", return_value=datetime.now() - timedelta(hours=2)):
            token = default_token_generator.make_token(self.user)
        response = self.client.get(reverse("password_reset_confirm", args=[uid, token]))
        self.assertFalse(response.context["validlink"])

    def test_recovery_email_is_rate_limited_without_exposing_address_in_storage(self):
        for _ in range(5):
            self.client.post("/password/reset/", {"email": self.user.email})
        self.assertEqual(len(mail.outbox), 3)
        for entry in RecoveryRateLimit.objects.all():
            self.assertNotIn(self.user.email, entry.key)

    @override_settings(DEFAULT_FROM_EMAIL="")
    def test_unconfigured_sender_fails_explicitly_instead_of_claiming_email_sent(self):
        response = self.client.post("/password/reset/", {"email": self.user.email})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "not configured")

    @override_settings(RESEND_API_KEY="")
    def test_missing_key_does_not_claim_recovery_is_available(self):
        response = self.client.post("/password/reset/", {"email": self.user.email})
        self.assertFalse(response.context["email_delivery_configured"])
        self.assertContains(response, "not configured")

    def test_provider_failure_is_logged_and_does_not_expose_account_existence(self):
        with patch("accounts.recovery.UniqueEmailPasswordResetForm.send_mail", side_effect=RuntimeError):
            response = self.client.post("/password/reset/", {"email": self.user.email})
        self.assertRedirects(response, "/password/reset/sent/")


class VerificationTests(TestCase):
    def setUp(self):
        self.mechanic = User.objects.create_user(username="reviewed-mechanic")
        self.customer = User.objects.create_user(username="verification-customer")
        Profile.objects.create(user=self.mechanic, role="mechanic")
        Profile.objects.create(user=self.customer, role="customer")
        self.data = {
            "business_name": "Roadside Workshop", "contact_number": "0000000000",
            "service_area": "Accra", "experience": "Engine repair training and experience",
            "credential_reference": "Training certificate available for administrator review",
        }
        self.client.force_login(self.mechanic)

    def test_application_cannot_self_approve_or_inject_reviewer_fields(self):
        response = self.client.post("/mechanic/verification/", {
            **self.data, "status": "verified", "identity_checked": "on",
            "contact_checked": "on", "qualifications_checked": "on",
        })
        self.assertRedirects(response, "/mechanic/verification/")
        application = MechanicVerification.objects.get()
        self.assertEqual(application.status, "pending")
        self.assertFalse(self.mechanic.profile.is_verified)
        self.assertFalse(application.identity_checked)


    def test_customer_cannot_submit_verification(self):
        self.client.force_login(self.customer)
        self.assertEqual(self.client.post("/mechanic/verification/", self.data).status_code, 403)

    def test_admin_cannot_approve_without_all_checks_and_evidence(self):
        application = MechanicVerification.objects.create(user=self.mechanic, **self.data)
        form = VerificationReviewForm({
            **self.data, "user": self.mechanic.id, "status": "verified",
        }, instance=application)
        self.assertFalse(form.is_valid())
        self.assertIn("Verify identity", str(form.errors))

    def test_administrator_review_publishes_badge_but_never_private_evidence(self):
        application = MechanicVerification.objects.create(user=self.mechanic, **self.data)
        staff = User.objects.create_superuser(username="verification-admin", password="Admin#Safe2026")
        request = RequestFactory().post("/")
        request.user = staff
        application.status = "verified"
        application.identity_checked = application.contact_checked = application.qualifications_checked = True
        application.review_notes = "PRIVATE-EVIDENCE-MUST-NOT-APPEAR"
        admin.site._registry[MechanicVerification].save_model(request, application, None, True)
        self.mechanic.refresh_from_db()
        self.assertTrue(self.mechanic.profile.is_verified)
        response = self.client.get(reverse("mechanic_detail", args=[self.mechanic.id]))
        self.assertEqual(response.context["verification"].status, "verified")
        self.assertNotContains(response, "PRIVATE-EVIDENCE-MUST-NOT-APPEAR")
        self.assertEqual(MechanicVerification.objects.get().reviewed_by, staff)

    def test_rejected_application_can_be_resubmitted_without_retaining_checks(self):
        MechanicVerification.objects.create(
            user=self.mechanic, status="rejected", identity_checked=True, **self.data,
        )
        self.client.post("/mechanic/verification/", self.data)
        application = MechanicVerification.objects.get()
        self.assertEqual(application.status, "pending")
        self.assertFalse(application.identity_checked)


@override_settings(DEFAULT_FROM_EMAIL="recovery@example.test", RESEND_API_KEY="test-only-placeholder")
class ResendBackendTests(TestCase):
    def test_secret_authenticated_request_sends_recovery_content(self):
        import json
        from unittest.mock import MagicMock
        from django.core.mail import EmailMessage
        from .email_backend import ResendEmailBackend
        response = MagicMock()
        response.__enter__.return_value.read.return_value = b'{"id":"test-email-id"}'
        with patch("accounts.email_backend.urlopen", return_value=response) as send:
            count = ResendEmailBackend().send_messages([
                EmailMessage("Password reset", "A reset link", "recovery@example.test", ["recipient@example.test"])
            ])
        self.assertEqual(count, 1)
        request = send.call_args.args[0]
        self.assertEqual(request.full_url, "https://api.resend.com/emails")
        self.assertEqual(request.get_header("Authorization"), "Bearer test-only-placeholder")
        self.assertTrue(request.get_header("User-agent"))
        payload = json.loads(request.data)
        self.assertEqual(payload["to"], ["recipient@example.test"])
        self.assertNotIn("api_key", payload)

    def test_rejected_key_raises_sanitized_error_instead_of_claiming_delivery(self):
        from urllib.error import HTTPError
        from django.core.mail import EmailMessage
        from .email_backend import ResendEmailBackend
        error = HTTPError("https://api.resend.com/emails", 401, "Unauthorized", {}, None)
        with patch("accounts.email_backend.urlopen", side_effect=error):
            with self.assertRaisesRegex(RuntimeError, r"HTTP 401"):
                ResendEmailBackend().send_messages([
                    EmailMessage("Password reset", "A reset link", "recovery@example.test", ["recipient@example.test"])
                ])

    def test_network_failure_never_counts_as_sent(self):
        from urllib.error import URLError
        from django.core.mail import EmailMessage
        from .email_backend import ResendEmailBackend
        with patch("accounts.email_backend.urlopen", side_effect=URLError("offline")):
            with self.assertRaisesRegex(RuntimeError, "could not be completed"):
                ResendEmailBackend().send_messages([
                    EmailMessage("Password reset", "A reset link", "recovery@example.test", ["recipient@example.test"])
                ])
