const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const source = fs.readFileSync("mechanicfinder/static/chat-voice.js", "utf8");

function setup({permissionDenied = false, supported = true, sendFails = false} = {}) {
    const elements = new Map();
    const events = {};
    const intervals = [];
    let trackStopped = 0, uploads = 0, revoked = 0;
    const node = id => {
        if (!elements.has(id)) elements.set(id, {
            dataset: {}, listeners: {}, children: [], hidden: false, value: "",
            textContent: "", disabled: false,
            addEventListener(type, callback) { this.listeners[type] = callback; },
            setAttribute(key, value) { this[key] = value; },
            removeAttribute(key) { delete this[key]; },
            appendChild(child) { this.children.push(child); },
            replaceChildren(...children) { this.children = children; },
            querySelector() { return null; }, querySelectorAll() { return []; },
            focus() {}, load() {}, remove() {},
        });
        return elements.get(id);
    };
    node("chat-feed").dataset = {latestId: "0", pollUrl: "/chat/2/messages/"};
    node("chat-form").dataset = {ownUserId: "1"};
    class Recorder {
        static isTypeSupported(type) { return type.startsWith("audio/webm"); }
        constructor() { this.listeners = {}; this.state = "inactive"; this.mimeType = "audio/webm"; }
        addEventListener(type, callback) { this.listeners[type] = callback; }
        start() { this.state = "recording"; }
        stop() {
            this.state = "inactive";
            this.listeners.dataavailable({data: new Blob(["test audio"])});
            this.listeners.stop();
        }
    }
    class BrowserURL extends URL {
        static createObjectURL() { return "blob:preview"; }
        static revokeObjectURL() { revoked++; }
    }
    const window = {
        location: {origin: "https://app.test", href: "https://app.test/chat/2/"},
        setInterval(callback, duration) { intervals.push({callback, duration}); return intervals.length; },
        clearInterval() {}, addEventListener(type, callback) { events[type] = callback; },
        MediaRecorder: supported ? Recorder : undefined,
    };
    const context = {
        window, MediaRecorder: supported ? Recorder : undefined,
        document: {getElementById: node, createElement: tag => node(tag + elements.size)},
        navigator: {mediaDevices: {getUserMedia: async () => {
            if (permissionDenied) throw Object.assign(new Error("denied"), {name: "NotAllowedError"});
            return {getTracks: () => [{stop() { trackStopped++; }}]};
        }}},
        URL: BrowserURL, Blob, Date, console,
        FormData: class { set() {} },
        fetch: async (url, options) => {
            if (options.method !== "POST") return {ok: true, json: async () => ({messages: []})};
            uploads++;
            if (sendFails) return {ok: false, json: async () => ({error: "Storage unavailable"})};
            return {ok: true, json: async () => ({
                message: {id: 1, sender_id: 1, body: "", audio_url: "/messages/voice/1/",
                          created_at: new Date().toISOString(), audio_duration: 1},
            })};
        },
    };
    vm.runInNewContext(source, context);
    return {node, intervals, events, window, stats: () => ({trackStopped, uploads, revoked})};
}

test("leaving the interface cancels recording and releases the microphone without uploading", async () => {
    const page = setup();
    await page.node("voice-record").listeners.click();
    page.window.appSessionLocked = true;
    page.events["app:session-lock"]();
    assert.equal(page.stats().trackStopped, 1);
    assert.equal(page.stats().uploads, 0);
    assert.equal(page.node("voice-preview").hidden, true);
});

test("record, stop and preview never upload until Send is chosen", async () => {
    const {node, stats} = setup();
    await node("voice-record").listeners.click();
    assert.equal(node("voice-stop").hidden, false);
    assert.equal(stats().uploads, 0);
    node("voice-stop").listeners.click();
    assert.equal(node("voice-preview").src, "blob:preview");
    assert.equal(node("voice-send").disabled, false);
    assert.equal(stats().trackStopped, 1);
    assert.equal(stats().uploads, 0);
    await node("voice-send").listeners.click();
    assert.equal(stats().uploads, 1);
    assert.equal(stats().revoked, 1);
    assert.match(node("voice-status").textContent, /sent/);
});

test("cancelling recording releases microphone without sending", async () => {
    const {node, stats} = setup();
    await node("voice-record").listeners.click();
    node("voice-cancel").listeners.click();
    assert.equal(stats().trackStopped, 1);
    assert.equal(stats().uploads, 0);
    assert.match(node("voice-status").textContent, /cancelled/);
    assert.equal(node("voice-record").disabled, false);
});

test("permission denied and unsupported browsers have explicit text fallback", async () => {
    for (const options of [{permissionDenied: true}, {supported: false}]) {
        const {node, stats} = setup(options);
        await node("voice-record").listeners.click();
        assert.equal(node("voice-unavailable").hidden, false);
        assert.match(node("voice-status").textContent, /text message/);
        assert.equal(stats().uploads, 0);
    }
});

test("failed send preserves preview for retry instead of pretending success", async () => {
    const {node} = setup({sendFails: true});
    await node("voice-record").listeners.click();
    node("voice-stop").listeners.click();
    await node("voice-send").listeners.click();
    assert.match(node("voice-status").textContent, /Storage unavailable/);
    assert.equal(node("voice-preview").src, "blob:preview");
    assert.equal(node("voice-send").disabled, false);
});

test("repeat Send while uploading does not upload twice", async () => {
    const {node, stats} = setup();
    await node("voice-record").listeners.click();
    node("voice-stop").listeners.click();
    await Promise.all([node("voice-send").listeners.click(), node("voice-send").listeners.click()]);
    assert.equal(stats().uploads, 1);
});
