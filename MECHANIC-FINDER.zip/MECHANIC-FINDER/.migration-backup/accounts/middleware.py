import time

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import logout
from django.http import JsonResponse
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.deprecation import MiddlewareMixin
from urllib.parse import urlencode

from .profile_access import resolve_app_profile


class AppProfileMiddleware(MiddlewareMixin):
    """Route incomplete authenticated accounts to recovery instead of a 500."""

    def process_view(self, request, view_func, view_args, view_kwargs):
        if not request.user.is_authenticated:
            return None
        match = request.resolver_match
        if match.namespace == "admin" or match.url_name in {
            "account_setup", "login", "logout", "leave_interface",
            "password_reset", "password_reset_done", "password_reset_confirm",
            "password_reset_complete",
        }:
            return None
        # Resource-specific permission checks (for example private tracking and
        # voice playback) must still return their own 403/404 to nonparticipants.
        # Intercept only app entry points and views which need a role profile.
        if match.url_name not in {
            "home", "customer_dashboard", "mechanic_dashboard",
            "mechanic_directory", "create_request", "mechanic_requests",
            "mechanic_verification", "poll_notifications",
            "notification_list", "session_activity", "update_presence_location",
        }:
            return None
        if resolve_app_profile(request.user) is not None:
            return None
        setup_url = reverse("account_setup")
        if "application/json" in request.headers.get("Accept", ""):
            return JsonResponse({
                "error": "Choose your account type to restore access.",
                "setup_required": True, "setup_url": setup_url,
            }, status=409)
        return redirect(setup_url + "?" + urlencode({"next": request.get_full_path()}))


class IdleSessionMiddleware:
    """Enforce server-side idle expiry even when a browser keeps polling."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        now = time.time()
        was_authenticated = request.user.is_authenticated
        if request.user.is_authenticated:
            last_activity = request.session.get("last_user_activity")
            if last_activity is not None and now - last_activity >= settings.SESSION_COOKIE_AGE:
                logout(request)
                messages.info(request, "Your session expired after 3 hours of inactivity. Please log in again.")
            else:
                # URL resolution happens after middleware, so inspect the paths here.
                background = (
                    request.path.startswith("/static/")
                    or request.path == "/notifications/poll/"
                    or request.path == "/mechanic/location/"
                    or (request.path.startswith("/chat/") and request.path.endswith("/messages/"))
                    or request.path.startswith("/rescue/update-location/")
                    or (request.path.startswith("/rescue/tracking/") and request.path.endswith("/location/"))
                    or (request.path.startswith("/rescue/tracking/") and request.path.endswith("/journey/"))
                )
                if not background:
                    request.session["last_user_activity"] = now
                    request.session.set_expiry(0)
        response = self.get_response(request)
        if was_authenticated or request.user.is_authenticated:
            # Do not serve a saved private page after the user has signed out.
            response["Cache-Control"] = "private, no-store"
        return response
