import re

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .models import Profile


class VisibleNavigationTests(TestCase):
    def navigation(self, response):
        self.assertEqual(response.status_code, 200)
        markup = response.content.decode()
        navigation = "\n".join(re.findall(r"<nav\b.*?</nav>", markup, flags=re.S))
        self.assertTrue(navigation)
        self.assertNotIn("navbar-toggler", navigation)
        self.assertNotIn('data-bs-toggle="collapse"', navigation)
        return navigation

    def test_visitors_can_reach_main_pages_without_opening_a_menu(self):
        for page in ("home", "login", "signup", "mechanic_directory"):
            with self.subTest(page=page):
                navigation = self.navigation(self.client.get(reverse(page)))
                for target in ("home", "mechanic_directory", "login", "signup"):
                    self.assertIn(f'href="{reverse(target)}"', navigation)

    def test_each_role_has_visible_account_navigation(self):
        for role in ("customer", "mechanic"):
            with self.subTest(role=role):
                user = User.objects.create_user(username=f"mobile-{role}")
                Profile.objects.create(user=user, role=role)
                self.client.force_login(user)
                navigation = self.navigation(
                    self.client.get(reverse(f"{role}_dashboard"))
                )
                for target in (
                    f"{role}_dashboard", "notification_list", "logout",
                    "mechanic_directory",
                ):
                    self.assertIn(f'href="{reverse(target)}"', navigation)
                self.assertNotIn(f'href="{reverse("login")}"', navigation)
                self.assertNotIn(f'href="{reverse("signup")}"', navigation)
                self.assertIn('href="/?info=1#about"', navigation)
                self.assertIn('href="/?info=1#services"', navigation)
                self.assertContains(self.client.get("/?info=1"), 'id="about"')
                self.assertRedirects(
                    self.client.get("/"), reverse(f"{role}_dashboard")
                )
                self.client.logout()
