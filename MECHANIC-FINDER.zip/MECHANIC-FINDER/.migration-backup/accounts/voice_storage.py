"""Private durable voice files. Never use the deployment filesystem for uploads."""
import json
import math
import os
import subprocess
import tempfile
from uuid import uuid4

from django.conf import settings
from django.core.exceptions import ValidationError
from replit.object_storage import Client


MAX_AUDIO_BYTES = 8 * 1024 * 1024
MAX_AUDIO_SECONDS = 120
FORMATS = {
    "audio/webm": ("webm", ("matroska", "webm")),
    "audio/ogg": ("ogg", ("ogg",)),
    "audio/mp4": ("m4a", ("mov", "mp4", "m4a")),
}


def validate_audio(upload, duration):
    mime = upload.content_type.split(";")[0].strip().lower()
    if mime not in FORMATS:
        raise ValidationError("Use a WebM, Ogg or M4A voice recording.")
    if not upload.size or upload.size > MAX_AUDIO_BYTES:
        raise ValidationError("Voice messages must be non-empty and no larger than 8 MB.")
    try:
        claimed_seconds = float(duration)
    except (TypeError, ValueError):
        raise ValidationError("The recording length is missing. Please record your message again.")
    if not math.isfinite(claimed_seconds) or not 0 < claimed_seconds <= MAX_AUDIO_SECONDS:
        raise ValidationError("Voice messages can be up to 2 minutes long.")
    data = upload.read(MAX_AUDIO_BYTES + 1)
    if not data or len(data) > MAX_AUDIO_BYTES:
        raise ValidationError("Voice messages must be non-empty and no larger than 8 MB.")
    extension, allowed_formats = FORMATS[mime]
    # Inspect the actual container and streams, not a user-supplied filename/MIME.
    filename = None
    try:
        with tempfile.NamedTemporaryFile(suffix="." + extension, delete=False) as output:
            output.write(data)
            filename = output.name
        result = subprocess.run(
            ["ffprobe", "-v", "error", "-protocol_whitelist", "file,pipe",
             "-show_entries", "stream=codec_type:format=format_name,duration",
             "-of", "json", filename],
            capture_output=True, timeout=10, check=False,
        )
        metadata = json.loads(result.stdout)
        stream_types = [item.get("codec_type") for item in metadata.get("streams", [])]
        format_data = metadata.get("format", {})
        actual_formats = format_data.get("format_name", "").split(",")
        if (
            result.returncode or not stream_types or any(kind != "audio" for kind in stream_types)
            or not set(actual_formats).intersection(allowed_formats)
        ):
            raise ValidationError("This file is not a supported voice recording.")
        # Browser WebM recordings may omit duration; bounded size and client recording
        # limits still apply. Use actual metadata whenever the container supplies it.
        actual_duration = format_data.get("duration")
        if actual_duration not in (None, "N/A"):
            actual_seconds = float(actual_duration)
            if not math.isfinite(actual_seconds) or actual_seconds <= 0 or actual_seconds > 121:
                raise ValidationError("Voice messages can be up to 2 minutes long.")
            claimed_seconds = min(actual_seconds, MAX_AUDIO_SECONDS)
    except (ValueError, KeyError, subprocess.SubprocessError):
        raise ValidationError("This recording could not be read. Please record it again.")
    finally:
        if filename:
            os.unlink(filename)
    return data, mime, max(1, math.ceil(claimed_seconds)), extension


def store_voice(data, extension):
    environment = "development" if settings.DEBUG else "production"
    key = f"private-voice/{environment}/{uuid4().hex}.{extension}"
    Client().upload_from_bytes(key, data)
    return key


def read_voice(key):
    return Client().download_as_bytes(key)


def remove_voice(key):
    Client().delete(key, ignore_not_found=True)
