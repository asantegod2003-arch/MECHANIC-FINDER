from django import forms
from .models import MechanicVerification


class VerificationForm(forms.ModelForm):
    class Meta:
        model = MechanicVerification
        fields = ["business_name", "contact_number", "service_area", "experience", "credential_reference"]
        help_texts = {
            "credential_reference": "Provide a qualification reference or details the administrator can check. Do not enter ID document numbers.",
            "experience": "Describe your repair experience and training. An administrator will contact you to verify it.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"
