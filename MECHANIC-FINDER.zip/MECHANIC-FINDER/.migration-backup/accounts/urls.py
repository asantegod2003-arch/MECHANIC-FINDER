from django.urls import path
from . import views, chat_views
from . import trust_views, recovery
from django.contrib.auth import views as auth_views

urlpatterns = [
    path("password/reset/", recovery.RecoveryView.as_view(), name="password_reset"),
    path("password/reset/sent/", auth_views.PasswordResetDoneView.as_view(
        template_name="accounts/password_reset_done.html"), name="password_reset_done"),
    path("password/reset/<uidb64>/<token>/", auth_views.PasswordResetConfirmView.as_view(
        template_name="accounts/password_reset_confirm.html"), name="password_reset_confirm"),
    path("password/reset/complete/", auth_views.PasswordResetCompleteView.as_view(
        template_name="accounts/password_reset_complete.html"), name="password_reset_complete"),
    path("mechanic/verification/", trust_views.mechanic_verification, name="mechanic_verification"),
    path("mechanics/<int:mechanic_id>/", trust_views.mechanic_detail, name="mechanic_detail"),

    path("", views.home, name="home"),

    path("mechanics/", views.mechanic_directory, name="mechanic_directory"),

    path("signup/", views.signup, name="signup"),

    path("login/", views.login_view, name="login"),

    path("logout/", views.logout_view, name="logout"),
    path("account/activity/", views.session_activity, name="session_activity"),
    path("account/setup/", views.account_setup, name="account_setup"),
    path("account/leave/", views.leave_interface, name="leave_interface"),
    path("notifications/", views.notification_list, name="notification_list"),
    path("notifications/poll/", views.poll_notifications, name="poll_notifications"),
    path("chat/<int:other_user_id>/", views.chat_thread, name="chat_thread"),
    path("chat/<int:other_user_id>/messages/", views.poll_chat_messages, name="poll_chat_messages"),
    path("messages/", chat_views.messages_inbox, name="messages_inbox"),
    path("messages/voice/<int:message_id>/", chat_views.voice_message_audio, name="voice_message_audio"),
    path("mechanic/location/", views.update_presence_location, name="update_presence_location"),

    path(
        "customer/dashboard/",
        views.customer_dashboard,
        name="customer_dashboard",
    ),

    path(
        "mechanic/dashboard/",
        views.mechanic_dashboard,
        name="mechanic_dashboard",
    ),

]