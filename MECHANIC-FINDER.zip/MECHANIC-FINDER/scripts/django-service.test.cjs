const assert = require("node:assert/strict");
const { spawnSync } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { test, after } = require("node:test");

const app = path.resolve(__dirname, "../artifacts/mechanic-finder");
const launcher = path.join(app, "scripts/service.sh");
const temporary = fs.mkdtempSync(path.join(os.tmpdir(), "mechanic-service-"));
fs.writeFileSync(
  path.join(temporary, "python"),
  '#!/bin/sh\nprintf "cwd=%s\\ndebug=%s\\n" "$PWD" "${DJANGO_DEBUG:-unset}"\nprintf "arg=%s\\n" "$@"\n',
  { mode: 0o755 },
);
after(() => fs.rmSync(temporary, { recursive: true, force: true }));

function launch(mode, overrides = {}) {
  const env = { ...process.env, PATH: `${temporary}:${process.env.PATH}`, PORT: "43210", ...overrides };
  if (overrides.PORT === undefined && "PORT" in overrides) delete env.PORT;
  return spawnSync("bash", [launcher, mode], { cwd: temporary, env, encoding: "utf8" });
}

test("development uses the artifact port and app directory without changing schema", () => {
  const result = launch("development");
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stdout, new RegExp(`cwd=${app}`));
  assert.match(result.stdout, /arg=manage\.py\narg=runserver\narg=0\.0\.0\.0:43210/);
  assert.doesNotMatch(result.stdout, /arg=migrate|db push/);
});

test("production runs Gunicorn with debug disabled and the artifact port", () => {
  const result = launch("production", { DJANGO_DEBUG: "True" });
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stdout, /debug=False/);
  assert.match(result.stdout, /arg=-m\narg=gunicorn/);
  assert.match(result.stdout, /arg=0\.0\.0\.0:43210/);
  assert.match(result.stdout, /arg=mechanicfinder\.wsgi:application/);
  assert.doesNotMatch(result.stdout, /arg=migrate|arg=collectstatic|arg=pip|runserver/);
});

test("build installs existing requirements and collects static files without schema writes", () => {
  const result = launch("build");
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stdout, /arg=pip\narg=install/);
  assert.match(result.stdout, /arg=collectstatic\narg=--noinput/);
  assert.match(result.stdout, /debug=False/);
  assert.doesNotMatch(result.stdout, /arg=migrate|db push|makemigrations/);
});

test("missing port and invalid launch modes fail explicitly", () => {
  for (const mode of ["development", "production"]) {
    const result = launch(mode, { PORT: undefined });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /must supply PORT/);
  }
  assert.equal(launch("unknown").status, 2);
});
