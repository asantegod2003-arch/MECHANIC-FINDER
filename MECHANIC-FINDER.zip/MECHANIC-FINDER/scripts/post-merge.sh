#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
pnpm install --frozen-lockfile
# Preserve the existing Django schema. Never run the empty scaffold's Drizzle
# schema push against this database, or migrate production at service startup.
python -m pip install --disable-pip-version-check -r requirements.txt
python artifacts/mechanic-finder/manage.py check
