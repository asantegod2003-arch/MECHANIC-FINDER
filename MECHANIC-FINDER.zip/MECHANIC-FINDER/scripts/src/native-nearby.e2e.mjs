// Customer homepage regression using only synthetic development identities.
// Browser geolocation is simulated by this test, never by the application.
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { chromium } from "playwright";

if (!process.env.REPLIT_EXPO_DEV_DOMAIN || !process.env.REPLIT_DEV_DOMAIN)
  throw new Error("Start the Expo and Django development workflows first.");
const prefix = `nearby_e2e_${Date.now().toString(36)}`;
const password = "Synthetic-Nearby-Test-728!";
const django = code => execFileSync("python", [
  "artifacts/mechanic-finder/manage.py", "shell", "-c", code,
], { encoding: "utf8" }).trim().split("\n").at(-1);
const fixture = JSON.parse(django(`
import json
from datetime import timedelta
from django.contrib.auth.models import User
from django.utils import timezone
from accounts.models import Profile
c = User.objects.create_user(username="${prefix}_customer", password="${password}")
Profile.objects.update_or_create(user=c, defaults={"role": "customer"})
people = []
for suffix, lat, available, age_minutes in [
    ("near", 5.604, True, 0),
    ("second", 5.65, True, 0),
    ("offline", 5.6038, False, 0),
    ("stale", 5.6039, True, 11),
    ("far", 6.2, True, 0),
]:
    u = User.objects.create_user(username="${prefix}_" + suffix, password="${password}")
    Profile.objects.update_or_create(user=u, defaults={
        "role": "mechanic", "available": available, "latitude": lat,
        "longitude": -0.187, "location_updated_at": timezone.now() - timedelta(minutes=age_minutes),
    })
    people.append(u.pk)
print(json.dumps({"customer": c.pk, "mechanics": people}))
`));
let browser, context, token;
try {
  browser = await chromium.launch({
    executablePath: "/repl/tools/bin/chromium", headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    geolocation: { latitude: 5.6037, longitude: -0.187, accuracy: 7 },
    permissions: ["geolocation"],
  });
  const page = await context.newPage();
  const runtimeErrors = [];
  page.on("pageerror", error => runtimeErrors.push(error.message));
  await page.goto(`https://${process.env.REPLIT_EXPO_DEV_DOMAIN}/`, {
    waitUntil: "domcontentloaded", timeout: 90000,
  });
  await page.getByTestId("login-submit").waitFor({ timeout: 60000 });
  await page.getByLabel("Username or email", { exact: true }).fill(`${prefix}_customer`);
  await page.getByLabel("Password", { exact: true }).fill(password);
  const loginResponse = page.waitForResponse(r =>
    r.url().endsWith("/api/mobile/login/") && r.request().method() === "POST");
  const nearbyResponse = page.waitForResponse(r =>
    r.url().endsWith("/api/mobile/mechanics/nearby/") && r.request().method() === "POST",
  { timeout: 60000 });
  await page.getByTestId("login-submit").click();
  const login = await loginResponse;
  assert.equal(login.status(), 200);
  assert.equal(new URL(login.url()).host, process.env.REPLIT_DEV_DOMAIN);
  token = (await login.json()).token;
  const nearby = await nearbyResponse;
  assert.equal(nearby.status(), 200);
  assert.equal(new URL(nearby.url()).host, process.env.REPLIT_DEV_DOMAIN);
  const body = nearby.request().postDataJSON();
  assert.deepEqual(body, { latitude: 5.6037, longitude: -0.187 });
  assert.ok(!nearby.request().url().includes("latitude="), "Customer location must not be in the URL");
  const results = await nearby.json();
  const ours = results.filter(item => item.mechanic.name.startsWith(prefix));
  assert.deepEqual(ours.map(item => item.mechanic.id), fixture.mechanics.slice(0, 2));
  assert.deepEqual(ours.map(item => item.distance_label), ["Within 1 km", "5–10 km away"]);
  assert.ok(!/latitude|longitude|location_updated_at/.test(JSON.stringify(results)));
  const first = page.getByRole("button", { name: `View ${prefix}_near's profile`, exact: true });
  const second = page.getByRole("button", { name: `View ${prefix}_second's profile`, exact: true });
  await first.waitFor({ state: "visible", timeout: 30000 });
  await second.waitFor({ state: "visible", timeout: 30000 });
  assert.ok((await first.boundingBox()).y < (await second.boundingBox()).y);
  for (const suffix of ["offline", "stale", "far"])
    assert.equal(await page.getByRole("button", { name: `View ${prefix}_${suffix}'s profile` }).count(), 0);
  assert.equal(await page.getByRole("button", { name: "Browse all mechanics by area" }).count(), 1);
  assert.deepEqual(runtimeErrors, []);
  assert.equal(django(`
from rescue.models import RescueRequest
print(RescueRequest.objects.filter(customer_id=${fixture.customer}).count())
`), "0");
  console.log("PASS: Customer sees two sorted nearby mechanics before making any request; offline, stale and distant mechanics are excluded.");
  console.log("PASS: Only approximate distances are returned; customer GPS stays out of the URL and no repair request is created.");
} finally {
  try {
    if (token && context) await context.request.post(
      `https://${process.env.REPLIT_DEV_DOMAIN}/api/mobile/logout/`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
  } finally {
    await browser?.close();
    console.log(django(`
from django.contrib.auth.models import User
q = User.objects.filter(pk__in=[${fixture.customer}, ${fixture.mechanics.join(",")}], username__startswith="${prefix}_")
assert q.count() == 6, "Refusing cleanup without all exact synthetic identities"
q.delete()
print("Six synthetic accounts cleaned up.")
`));
  }
}
