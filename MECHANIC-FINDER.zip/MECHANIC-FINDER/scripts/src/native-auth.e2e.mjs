// Focused native-web authentication regression. Uses synthetic development data
// only; the result records the fixture ID for explicit cleanup, never tokens.
import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
import { chromium } from "playwright";

const domain = process.env.REPLIT_EXPO_DEV_DOMAIN;
if (!domain) throw new Error("The running Expo development domain is required.");
const username = `native_e2e_${Date.now().toString(36)}`;
const email = `${username}@example.test`;
const password = "Preview-Only-728!Test";
const result = { username, userId: null, passed: false, checks: [] };
const errors = [];
await mkdir("generated-artifacts", { recursive: true });
const saveResult = () => writeFile("generated-artifacts/mobile-auth-result.json", JSON.stringify(result, null, 2));
const browser = await chromium.launch({
  executablePath: "/repl/tools/bin/chromium", headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
const page = await context.newPage();
page.on("pageerror", error => errors.push(error.message));
const checked = message => { result.checks.push(message); console.log("PASS:", message); };
const tab = async name => {
  const byRole = page.getByRole("tab", { name: new RegExp(name) });
  await (await byRole.count() ? byRole.first() : page.getByText(name, { exact: true }).last()).click();
};
const apiResponse = name => page.waitForResponse(response =>
  response.url().includes(`/api/mobile/${name}/`) && response.request().method() === "POST"
);
const waitVisible = locator => locator.waitFor({ state: "visible", timeout: 30000 });
try {
  await page.goto(`https://${domain}/`, { waitUntil: "networkidle", timeout: 90000 });
  await waitVisible(page.getByTestId("login-submit"));
  for (const name of ["Home", "Find", "Messages", "Account"])
    assert.ok(await page.getByText(name, { exact: true }).count(), `Missing ${name} navigation`);
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1), false);
  checked("Public sign-in and main navigation fit a phone.");

  await page.getByRole("button", { name: "Create account", exact: true }).first().click();
  await page.getByLabel("First name", { exact: true }).fill("Preview");
  await page.getByLabel("Last name", { exact: true }).fill("Tester");
  await page.getByLabel("Username (optional)", { exact: true }).fill(username);
  await page.getByLabel("Email address (optional)", { exact: true }).fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("Confirm password", { exact: true }).fill("Different confirmation");
  await page.getByTestId("signup-submit").click();
  await waitVisible(page.getByText("Passwords do not match.", { exact: true }));
  assert.equal(await page.getByLabel("Username (optional)", { exact: true }).inputValue(), username);
  assert.equal(await page.getByLabel("Email address (optional)", { exact: true }).inputValue(), email);
  checked("Signup validation explains the error without clearing entered details.");

  await page.getByLabel("Confirm password", { exact: true }).fill(password);
  const signupResponse = apiResponse("signup");
  await page.getByTestId("signup-submit").click();
  const signup = await signupResponse;
  assert.equal(signup.status(), 201);
  const signupData = await signup.json();
  result.userId = signupData.user.id;
  await saveResult();
  assert.equal(signupData.user.role, "customer");
  await waitVisible(page.getByText("Preview Tester", { exact: false }).first());
  checked("A real development account signs up and reaches the customer dashboard.");

  await tab("Account");
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  const logoutResponse = apiResponse("logout");
  await page.getByRole("button", { name: "Confirm sign out", exact: true }).click();
  assert.equal((await logoutResponse).status(), 200);
  await waitVisible(page.getByTestId("login-submit"));
  checked("Logout revokes the native session and restores public sign-in.");

  await page.getByLabel("Username or email", { exact: true }).fill(email);
  await page.getByLabel("Password", { exact: true }).fill("Incorrect password");
  const wrongResponse = apiResponse("login");
  await page.getByTestId("login-submit").click();
  assert.equal((await wrongResponse).status(), 400);
  await waitVisible(page.getByText(/Incorrect username, email address or password/).first());
  assert.equal(await page.getByLabel("Username or email", { exact: true }).inputValue(), email);
  checked("Wrong-password feedback is clear and retains the login identifier.");

  await page.getByLabel("Password", { exact: true }).fill(password);
  const loginResponse = apiResponse("login");
  await page.getByTestId("login-submit").click();
  const login = await loginResponse;
  assert.equal(login.status(), 200);
  assert.equal((await login.json()).user.id, result.userId);
  await tab("Messages");
  await waitVisible(page.getByText("Messages", { exact: true }).first());
  await tab("Account");
  await waitVisible(page.getByText(email, { exact: false }).first());
  checked("Email login restores the same identity and opens private account/messages screens.");
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  const finalLogout = apiResponse("logout");
  await page.getByRole("button", { name: "Confirm sign out", exact: true }).click();
  assert.equal((await finalLogout).status(), 200);
  assert.deepEqual(errors, [], "Unexpected JavaScript runtime error");
  result.passed = true;
} catch (error) {
  console.error("AUTH CHECK FAILED:", error.message);
  console.error("Visible page:", (await page.locator("body").innerText()).slice(0, 2500));
  if (errors.length) console.error("JavaScript errors:", errors);
  process.exitCode = 1;
} finally {
  await saveResult();
  await browser.close();
}
