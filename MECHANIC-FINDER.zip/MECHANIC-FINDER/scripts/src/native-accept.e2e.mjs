// Real UI regression using isolated development fixtures. GPS is emulated by
// the test browser only; application location code is not mocked or bypassed.
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { chromium } from "playwright";

if (!process.env.REPLIT_EXPO_DEV_DOMAIN || !process.env.REPLIT_DEV_DOMAIN)
  throw new Error("Start the Expo and Django development services first.");
const prefix = `accept_e2e_${Date.now().toString(36)}`;
const password = "Synthetic-Accept-Test-728!";
const problem = `${prefix}: synthetic UI test, not a real breakdown`;
const django = code => execFileSync("python", [
  "artifacts/mechanic-finder/manage.py", "shell", "-c", code,
], { encoding: "utf8" }).trim().split("\n").at(-1);
const fixture = JSON.parse(django(`
import json
from django.contrib.auth.models import User
from django.utils import timezone
from accounts.models import Profile
from rescue.models import RescueRequest
c = User.objects.create_user(username="${prefix}_customer", password="${password}")
m = User.objects.create_user(username="${prefix}_mechanic", password="${password}")
Profile.objects.update_or_create(user=c, defaults={"role":"customer"})
Profile.objects.update_or_create(user=m, defaults={"role":"mechanic", "available":True})
j = RescueRequest.objects.create(customer=c, vehicle_problem="${problem}", location="Synthetic test location",
    phone_number="0200000000", customer_latitude=5.6, customer_longitude=-0.2,
    customer_location_captured_at=timezone.now(), customer_location_accuracy=10)
print(json.dumps({"customer":c.pk, "mechanic":m.pk, "job":j.pk}))
`));
let browser, context, token;
try {
  browser = await chromium.launch({
    executablePath: "/repl/tools/bin/chromium", headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    geolocation: { latitude: 5.61, longitude: -0.18, accuracy: 7 },
    permissions: ["geolocation"],
  });
  const page = await context.newPage();
  const runtimeErrors = [];
  page.on("pageerror", error => runtimeErrors.push(error.message));
  await page.goto(`https://${process.env.REPLIT_EXPO_DEV_DOMAIN}/`, {
    waitUntil: "domcontentloaded", timeout: 90000,
  });
  await page.getByTestId("login-submit").waitFor({ timeout: 60000 });
  await page.getByLabel("Username or email", { exact: true }).fill(`${prefix}_mechanic`);
  await page.getByLabel("Password", { exact: true }).fill(password);
  const loginResponse = page.waitForResponse(r =>
    r.url().endsWith("/api/mobile/login/") && r.request().method() === "POST");
  await page.getByTestId("login-submit").click();
  const login = await loginResponse;
  assert.equal(login.status(), 200);
  token = (await login.json()).token;
  const card = page.getByText(problem, { exact: true }).locator("..");
  await card.getByRole("button", { name: "View request", exact: true }).click({ timeout: 30000 });
  const accept = page.getByRole("button", { name: "Accept request (share fresh GPS)", exact: true });
  await accept.waitFor({ state: "visible", timeout: 30000 });
  assert.equal(await page.getByRole("button", { name: "Start repair journey", exact: true }).count(), 0);
  console.log("PASS: Available mechanic sees Accept on an unassigned request, not later actions.");

  const actionResponse = page.waitForResponse(r =>
    r.url().endsWith(`/api/mobile/requests/${fixture.job}/action/`) && r.request().method() === "POST");
  await accept.click();
  const response = await actionResponse;
  assert.equal(response.status(), 200);
  const job = await response.json();
  assert.equal(job.status, "accepted");
  assert.equal(job.mechanic.id, fixture.mechanic);
  assert.equal(job.mechanic_position.latitude, 5.61);
  assert.equal(job.mechanic_position.longitude, -0.18);
  assert.equal(job.customer_position.latitude, 5.6);
  await page.getByRole("button", { name: "Start repair journey", exact: true })
    .waitFor({ state: "visible", timeout: 30000 });
  assert.equal(await accept.count(), 0);
  assert.deepEqual(runtimeErrors, []);
  console.log("PASS: Accept assigns this mechanic, captures fresh test GPS, preserves the customer pin, and reveals the next action.");
} finally {
  try {
    if (token && context) await context.request.post(
      `https://${process.env.REPLIT_DEV_DOMAIN}/api/mobile/logout/`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
  } finally {
    await browser?.close();
    console.log(django(`
from django.contrib.auth.models import User
from rescue.models import RescueRequest
q = User.objects.filter(pk__in=[${fixture.customer},${fixture.mechanic}], username__startswith="${prefix}_")
assert q.count() == 2, "Refusing cleanup without both exact synthetic identities"
q.delete()
assert not RescueRequest.objects.filter(pk=${fixture.job}).exists()
print("Synthetic customer, mechanic, request and notifications cleaned up.")
`));
  }
}
