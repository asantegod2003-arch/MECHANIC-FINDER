# Mechanic Finder Ghana

## Existing website

The production product is Django 6 on Python 3.12, with its original
server-rendered pages, custom account authentication, and Replit PostgreSQL.
It is preserved under `artifacts/mechanic-finder/`, served at `/` by the managed
`artifacts/mechanic-finder: web` workflow. The web artifact was bootstrapped from
a web template only for registration: its service runs Django, not the unused
React/Vite scaffold. Do not replace the website with those scaffold pages.

The original application remains in `.migration-backup/` as a local reference,
excluded from deployment. The original SQLite backup is not the active database
and must not be imported again. Preserve the existing `DATABASE_URL`, account
identities, profiles, requests, chat history, and private voice objects.

## Run and check

Use the managed workflow or the Run button to start the website. The artifact
supplies `PORT`; do not hardcode the old port 5000.

```sh
pnpm --filter @workspace/mechanic-finder run check
pnpm --filter @workspace/mechanic-finder run test
pnpm --filter @workspace/mechanic-finder run test:browser
```

Root `requirements.txt` pins Python dependencies. Do not use a virtual
environment. Post-merge setup installs the pnpm/Python dependencies and runs
Django checks without changing the database schema.

## Production and database safety

- Keep `[deployment] router = "application"`: production uses the artifact's
  Python build/run configuration, not a static Vite bundle.
- Production installs requirements and collects static assets at build time,
  then serves Django through Gunicorn with `DJANGO_DEBUG=False`.
- **Never add production startup/build migrations or run the scaffold's Drizzle
  schema push against this database.** Publish owns managed production schema
  changes. Django's production migration history can lag the real schema.
- Development migrations, when a later feature needs them, are a separate
  deliberate step. This preservation does not introduce schema changes.
- `artifacts/api-server/` retains the shared `/api/healthz` route. Native product
  operations are Django-backed at `/api/mobile/`; the Django artifact explicitly
  owns this more-specific route. Django remains authoritative for database and
  auth; the empty Drizzle schema must not be pushed over it.

## Configuration and existing behavior

- `SESSION_SECRET` remains required. All credentials stay in Replit Secrets.
- The existing App Storage default bucket remains configured in `.replit`.
  Private voice messages use the original bucket/object keys and participant
  authorization. FFmpeg/FFprobe remain system dependencies.
- `GOOGLE_MAPS_API_KEY` is optional: existing key-free embedded map behavior
  remains intact. Request and acceptance GPS are captured separately from live
  presence; never substitute later coordinates for those saved positions.
- Production trusts the HTTPS proxy, enables secure cookies, and defaults to
  Replit production hosts. Use existing host/CSRF configuration for custom
  domains, without weakening authentication or CSRF checks.
- Retain the ten-minute continuously-away re-login rule and three-hour idle
  safeguard. Background polling is not user activity.
- Account recovery never overwrites a valid role. Historical text/voice chats
  remain accessible to saved participants even when profiles are missing or
  current roles differ. New conversations still require a valid role pairing.
- Recovery email uses the private Resend key, but still needs a verified sender
  before delivery can be enabled. Do not advertise recovery delivery as working
  without that external configuration.

## Product and brand

Preserve both customer and mechanic journeys: directory/search, dashboards,
rescue requests and acceptance, maps/tracking, private text/voice messaging,
verification review, quotes, completed-job reviews, notifications, and admin.
Keep the existing templates, green visual identity, fonts, and image/icon assets.
Account menus remain visible on arrival and layouts fit phone screens.

## Native Android and iPhone app

The Expo Router app is `artifacts/mechanic-finder-mobile/`, managed workflow
`artifacts/mechanic-finder-mobile: expo`, preview `/mobile/` through the Expo
domain. The website stays at `/`. Its confirmed display name is
**Mechanic Finder -Ghana** and initial iOS/Android identifier is
`com.mechanicfinderghana.app`; do not change store identifiers after release.
Use the same Django users/data and existing green car icon, not another identity
store or a WebView wrapper. Store submission requires separate owner approvals.

Native API adapters live in `accounts/mobile_api/` under the Django artifact.
They reuse existing forms/models and private voice storage. Native tokens are
revocable, opaque Django-backed sessions with a separate namespace: never
authenticate them through website cookies or exempt original website forms from
CSRF. Password changes and disabled accounts invalidate native access. GET
polling and foreground journey updates do not renew idle sessions.

The contract is `lib/api-spec/openapi.yaml`. Update it first, run
`pnpm --filter @workspace/api-spec run codegen`, and consume generated
`@workspace/api-client-react` hooks/functions in Expo. Do not add a parallel
fetch client or push the Drizzle scaffold schema.

Mobile API browser CORS accepts the development Expo origin and explicit
`MOBILE_WEB_ORIGINS` for other web origins, never credentialed wildcard origins.
Native device requests use bearer headers, not cookies. The managed development
command injects `EXPO_PUBLIC_DOMAIN`; production uses the published Django host,
configured in production environment variables. Republish the backend before
shipping a production mobile build that needs these new endpoints.

Account deletion currently records a password-confirmed **manual request** as
private user/staff notifications. It does not claim automatic data erasure or
disable the account. The owner must establish the deletion/retention process and
privacy policy before store submission. See the mobile release checklist for
other owner-controlled and device-only verification requirements.
